﻿import json,hashlib,zipfile,subprocess,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]/'model-sync-starter';sys.path.insert(0,str(ROOT/'scripts'))
from run_evidence import current
run=current(ROOT);frozen=json.loads((BASE/'frozen-source.json').read_text())
assert run['source_sha']==frozen['source_sha'] and run['source_tree']==frozen['source_tree']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
for name,h in frozen['prior_archives'].items():assert sha((ROOT/name).read_bytes())==h
old=(ROOT/'QM.md').read_bytes();assert sha(old)==frozen['historical_qm_sha256']
full_dir=next(BASE.glob('full-*'));default_dir=next(BASE.glob('default-*'))
full=json.loads((full_dir/'result.json').read_text());default=json.loads((default_dir/'result.json').read_text())
default_manifest=json.loads((default_dir/'archive-manifest.json').read_text());inventory=json.loads((BASE/'full-inventory-results.json').read_text())
infra=json.loads((ROOT/'target/qm/oracle-container.json').read_text());evidence=json.loads((ROOT/'target/qm/evidence.json').read_text());e=evidence['evidence']
assert full['exit']==full['nested_maven_exit']==full['qualification_exit']==full['collector_exit']==0
assert default['exit']==default['qualification_exit']==default['execution_audit_exit']==default['collector_exit']==0
assert evidence['runs']['full']['status']=='PASS' and not e['rejected'] and not evidence['working_tree_dirty']
assert inventory['oracle_methods']==83 and inventory['oracle_suite_count']==18 and inventory['surefire_tests']==224
assert all(p['status']=='PASS' for p in inventory['worker_phases'])
cleanup=json.loads((BASE/'cleanup-and-preservation.json').read_text());assert cleanup['status']=='PASS' and cleanup['receipt_pids']==12
comparison=json.loads((BASE/'comparison-complete-observation.json').read_text());capacity=json.loads(next(BASE.glob('scoped-capacity-*.json')).read_text())
workload=e['oracle_workload'];worker=e['oracle_worker'];target=e['qualification_target']
assert target['status']=='PASS' and len(target['receipts'])==20
assert all(d['status']=='PASS' and d['http']['status']=='PASS' for d in e['gatling'].values())
http_requests=sum(d['http']['requests']['total'] for d in e['gatling'].values());http_errors=sum(d['http']['requests']['ko'] for d in e['gatling'].values())
assert http_requests==367 and http_errors==0
trace_props={p.get('name'):p.get('value') for p in ET.parse(ROOT/'model-sync-sample/target/failsafe-reports/TEST-io.modelsync.sample.OracleWorkerIT.xml').getroot().findall('properties/property')}
assert trace_props.get('modelsync.worker.trace','false')=='false'
summary=f'''# Integrated repaired named-target qualification - 2026-10-26

**Default PASS. Configured full PASS. Production NO-GO.**

Tested clean source **`{run['source_sha']}`**, tree **`{run['source_tree']}`**,
`Tobia5/model-sync-starter`, branch `review/layered-refactor-qm-20261020`.
The later report-only commit is not claimed as the tested source. No implementation,
criterion, policy, deadline, platform, resource cap or test selection changed.
Tested86488c4/reporta0f46d7, failed full reportb7f3cb5 and all20 earlier archives
remain immutable. Earlier QM sections below retain their historical results.

## Actual commands, identities and original exits

| Execution | Measured result | Original exits |
|---|---|---|
| `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml clean verify` | PASS; run `{default_manifest['run_id']}`; 222 JUnit /102 Python /41 XML; zero failures/errors/skips; {default['elapsed_seconds']:.3f}s build supervision | build0, qualification0, execution audit0, collection0 |
| Git Bash `scripts/test-triggers.sh` |86 core /43 trigger standalone assertions PASS, separately counted from JUnit |0|
| Archived `python capacity.py full`, after default build/collection/contracts | PASS; attempt `{capacity['attempt_id']}`; host21.316/21.266/21.334GiB >= unchanged18GiB; Docker19.487GiB available; C77.679/D1069.773GiB free |0|
| `python scripts/full-oracle-container.py` | PASS; full run `{run['run_id']}`; {full['elapsed_seconds']:.3f}s wrapper supervision / {infra['elapsed_seconds']:.2f}s infrastructure | wrapper0, nested Maven0, qualification0, collection0 |

Exactly one full attempt; no unchanged retry. Invocation-only acknowledgments:
`MODELSYNC_ORACLE_CONTAINER=EXPLICIT_DISPOSABLE`,
`MODELSYNC_FULL_ENV_ACK=DISPOSABLE_NONPRODUCTION`, and
`MODELSYNC_MAVEN_SETTINGS=.mvn/qualification-central.settings.xml`.
The wrapper's Maven command retained `-B -ntp -s <approved-project-settings>
-fae -Pfull clean verify`; no diagnostic selector, skip or test filter.
Settings SHA256 `ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.
Infrastructure attempt `{infra['attempt_id']}`.

The normal/default rune965 is not borrowed: its actual ID is c965b470 above,
with its own archived marker/reports before the full clean. The full run has a
new marker and fresh224 Surefire tests/43 XML reports, including2 full-only tests,
plus **83 Oracle methods across18 suites**, zero failures/errors/skips.
All83 method names match the mandatory inventory. All default/full architecture,
profile separation, runtime-policy, migration, atomicity, fencing, recovery,
shutdown, transport, quota, creation, accounting, mutation and load gates passed.
No rejected/stale evidence. The machine full report labels a separate default
command NOT_RUN in its own marker; the independent matching default is the
actual c965b470 run, not an attribution of old XML to the full marker.

## Named target and actual target fixture

Only **`oracle26-nowait-ledger-first-v1`** is qualified: Oracle26ai23.26.3 / JDBC23.26.3.0.0,
point-lock-policy ORACLE_NOWAIT, quota-lock-policy ORACLE_NOWAIT,
insert-policy ORACLE_26_NOWAIT, qualified JPA ORACLE_NOWAIT mapping,
DURABLE cooldown/schema-extension version1, supported ledger-first writers and
correctly enlisted local datasource/JpaTransactionManager.
Twenty fresh validated receipts cover all five required roles: starter-target,
nowait-atomicity, recovery-host, actual-worker and cooldown-worker. These verify
actual adapter settings, consumed mapping and datasource enlistment, not only
property values. Versioned migration and all current integration controls passed.
Compatibility controls remain; DEFAULT, older Oracle and arbitrary replacement
beans are not granted these bounded-wait guarantees by this result.

The repaired fixture executed in this full run: committed A/validatorA/revision0/
generation1, then changed-B/validatorB/revision1/generation2; both paired state
outcomes APPLIED/IDLE. Two owner reads, changed digest, validatorA propagated to
the second request; five changed-phase SQL statements and zero capture overflow.
Actual existing-row SQL included:

```sql
select ce1_0.storage_key from sample_customer ce1_0
where ce1_0.storage_key=? and ce1_0.local_version=?
for update of ce1_0.storage_key nowait
```

No historical diagnostic report substitutes for this current source/run proof.

## Original full worker method: all ten phases PASS

Actual auto-configured ReactorSyncWorker: four lanes, pool8, persistence4/owner8
threads, queue64 per thread, poll250ms, owner spacing20ms/latency5ms.
Fixed productive/max-idle250ms; adaptive productive5ms/max-idle1s. Original
**160 measured completions within20 seconds** retained for both productive phases,
with10 warmup each. Full JVM trace property absent/default false; this is the
original full method, not the traced four-cell diagnostic launcher.

| Phase | Result | Measured ms | Committed / owner calls | Ticks / empty | Wakeup upper ms |
|---|---|---:|---|---|---|
'''
for p in inventory['worker_phases']:
 wake=p.get('wakeup_latency_upper_ms')
 if p['name']=='cooldown-independent-owner-and-recovery':wake=f"other {p['other_owner_wakeup_ms']} / recovery {p['recovery_wakeup_upper_ms']}"
 summary+=f"| {p['name']} | PASS | {p['elapsed_ms']} | {p['completed_syncs']} / {p['owner_calls']} | {p['ticks']} / {p['empty']} | {wake if wake is not None else '-'} |\n"
summary+='''
All ten native counter intervals have VALID eight-session continuity. Empty/future
phases consumed no owner calls, grants or denials. Urgent/due/cooldown/recovery
wakeups remained within2500ms; unrelated-owner progress was observed.

**The historical worker timeout remains FAILED and unexplained.** This current
full regression PASS is not evidence of a repaired production cause. No pacing
change, deadline increase or provisional fixed-control criterion adoption occurred.
Prior virtual controls and the five focused diagnostic passes keep their original
source/scope. This full used its own83 methods and all ten worker phases.

## Mutation and load evidence

PIT1.25.9/provider1.2.3 on resolved JUnit6.0.3 completed in7s: **167 KILLED,
1 SURVIVED /168 generated =99.40% killed/generated**; NO_COVERAGE/TIMED_OUT/
RUN_ERROR/UNKNOWN all0. Existing85% gate, eight behavioral classes and four target
test classes unchanged. XML/HTML and scope/effective configuration retained.
The survivor removes `FreshnessPolicy.positive(maxAge)` at line19; source bytes
match b7f3cb5. Existing acceptance-equivalence review remains: positive refresh
plus refresh<=max rejects nonpositive max; null comparison rejects null. Exception
ordering/messages may differ. It stays SURVIVED and included, with no exclusion
or score adjustment; this is not a universal semantic-equivalence claim.

Six explicitly selected **in-memory semantic Gatling scenarios PASS**,367 HTTP
requests/0 errors, with owner/ledger assertions and raw HTML/logs. HTTP acceptance
is not synchronization completion. These short synthetic scenarios have0ms
reported warmup and are not Oracle-scale or production SLO qualification.
Per-scenario latency/dataset/counter tables are in the detailed report.

Oracle capacity: **1,000,000 seeded rows /100k due**, seed4,439,182ms; four direct
`runOne` workers with5ms loop sleep, pool8, controlled owner20ms spacing, ordinary5ms/
slow25ms latency and injected failures. **200 measured committed reconciliations
from220 physical owner calls in15,624ms** (210/230 with warmup);12.8008 syncs/s versus
14.0809 owner calls/s, not HTTP accepted-request rate or actual Reactor-worker
throughput. RunOne p50/p95/p99=5/62/78ms; claimed-only63/80/102ms. Lag p50/p95/p99=
4,465,922/4,471,492/4,472,018ms includes seed time: the common requested epoch is
recorded before seeding. It is not steady-state latency or a million completions.
Native session/cursor work, waits, plans, seed/warmup/measurement/drain/cleanup,
projection outcomes and bounded pool/queue observations remain raw artifacts.

OracleScaleIT passed all eight distributions:100k fixture, one ledger claim37ms,
persisted lease/token/generation/lockValid checks. This is not provider admission.
The eight controlled comparison variants passed with the same ORACLE_NOWAIT quota,
ORACLE_26_NOWAIT insert and DURABLE policies: **2916 observed acquisitions/claims =
1766 grants +712 denials +438 confirmed refusals**;0 active/unknown/uncertain outcomes,
1766 owner calls/1604 measured reconciliations. All32 lane runs ended normally.
104 logical cooldown requests reached APPLIED,104 durable accept commits;
115 physical materialization attempts =104 commits +11 refused rollbacks,0 unresolved
or logical publication failures. Historical unclassified55 and five earlier
publication failures remain unchanged; no arithmetic remainder relabelling.

## Environment, resources and independently verified cleanup

JDK21.0.12.1 / Maven3.9.9 / Wrapper3.3.4 / Python3.12.10 / Boot4.1.1 /
JUnit6.0.3 / Hibernate7.4.5.Final / Surefire-Failsafe3.5.3 / ArchUnit1.5.0 /
Gatling3.13.1/plugin4.11.0 / Docker29.8.2. Actual PIT execution verifies the pinned
provider/platform combination; no platform change was used to obtain PASS.
Pinned image `ghcr.io/gvenzl/oracle-free:23.26.3-slim@sha256:6d61d267a3b978c24c5ac1790e62e927416a0aec446bd86e4b3a1527562757bd`.
Oracle6GiB/4CPU cap, generated per-run credentials, separate runtime/migration
schemas, loopback-only publication and the18GiB admission were unchanged.

Runner reported16 available processors. Oracle test JVM observed maximum heap
16,944,988,160 bytes and used-heap snapshot289,356,592 bytes; that snapshot is not
peak usage or an enforced8GiB heap cap. Gatling maximum heap1,073,741,824 bytes.
The8GiB Maven/PIT/Gatling planning allowance in admission is not an assertion that
every ergonomic JVM maximum is capped there. Production memory/resource bounds
remain an operations gate; no global JVM/resource setting was changed here.

Wrapper cleanup PASS; independent checks confirm owned container
`msq-526fee3f3fe2`, volume `msq-526fee3f3fe2-data` and all12 JVM PIDs from20
current-run receipts absent. Docker inspect exit1 meant explicit no-such-object/
volume, not an ignored Docker-service error. All raw PIT13 files and Gatling192
files, including HTML assets, are archived. No unrelated resource was altered.
All20 earlier archives and the complete old QM suffix remain unchanged.

## Remaining production requirements

Configured full PASS is **not production acceptance**. Historical worker timeout
cause remains unknown. Independent plain-UPDATE cancellation remains historically
FAILED; its separate current characterization is NOT_RUN, with unchanged approved
applicability/body. No unsupported path or all-configuration guarantee is added.
Unrecorded-response/acceptance windows, uncertain outcomes, receipt retention and
maintenance, security, operations, consumer/supply-chain/provider integration and
real production capacity/SLO gates remain open under the known-ID owner-to-Oracle/
JPA first-release scope. No parent release gate is closed merely by this run.
No new features, merge, main change, workflow bootstrap or package publication.

[Detailed method/phase tables and raw evidence](validation/qualification/2026-10-26-integrated-repaired-target/README.md).
Historical root QM content follows unchanged.

---

'''
# Correct the short explanatory run label; preserve exact IDs above and in every raw marker.
summary=summary.replace('The normal/default rune965 is not borrowed: its actual ID is c965b470 above,','The normal/default run is not borrowed: its actual ID is c965b470 above,')
result={**run,'scope':'named-configuration-only','qualification_target':'oracle26-nowait-ledger-first-v1','default_run_id':default_manifest['run_id'],'default_status':'PASS','default_junit':222,'default_python':102,'default_xml':41,'full_status':'PASS','original_exits':{'default_build':0,'default_qualification':0,'default_audit':0,'default_collection':0,'full_wrapper':0,'full_maven':0,'full_qualification':0,'full_collection':0},'full_surefire_tests':224,'full_surefire_xml':43,'oracle_methods':83,'oracle_suites':18,'worker_phases':inventory['worker_phases'],'worker_trace_property':'ABSENT_DEFAULT_FALSE','historical_worker_timeout':'FAILED_UNEXPLAINED','pacing_or_criterion_change':False,'pit':e['mutation'],'gatling_requests':http_requests,'gatling_errors':http_errors,'gatling_scenarios':6,'cleanup':'INDEPENDENTLY_VERIFIED','production':'NO_GO','prior_archives_unchanged':20,'oracle_inventory':inventory['oracle_suites'],'historical_cancellation':'FAILED','current_characterization':'NOT_RUN'}
(BASE/'result-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
(BASE/'human-summary.md').write_text(summary,encoding='utf-8')
(BASE/'frozen-source-end.json').write_text(json.dumps({**run,'clean_through_build_and_collection':True,'prior_archives_unchanged':20,'historical_qm_unchanged':True},indent=2)+'\n',encoding='utf-8')
# Seal raw data without changing the original generated run-scoped QM/evidence.
dest=ROOT/'validation/qualification/2026-10-26-integrated-repaired-target';dest.mkdir(exist_ok=False)
files={p.relative_to(BASE).as_posix():sha(p.read_bytes()) for p in BASE.rglob('*') if p.is_file() and not p.name.startswith('pr-') and p.name!='raw-archive-manifest.json'}
pattern=re.compile(rb'(?<![0-9A-Za-z])[0-9a-f]{48}(?![0-9A-Za-z])')
hits=[name for name in files if pattern.search((BASE/name).read_bytes())]
assert not hits,hits
scan={'scope':'bounded ASCII generated-credential-format check, not a general secret detector','files_scanned':len(files),'matches':0}
(BASE/'nonsecret-artifact-check.json').write_text(json.dumps(scan,indent=2)+'\n',encoding='utf-8');files['nonsecret-artifact-check.json']=sha((BASE/'nonsecret-artifact-check.json').read_bytes())
manifest={**run,'scope':'CONFIGURED_FULL','qualification_target':result['qualification_target'],'full_status':'PASS','default_run_id':default_manifest['run_id'],'files_sha256':files}
(BASE/'raw-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
archive=dest/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name in sorted([*files,'raw-archive-manifest.json']):z.write(BASE/name,name)
digest=sha(archive.read_bytes());(dest/'SHA256SUMS').write_text(digest+'  raw-evidence.zip\n',encoding='utf-8')
seal=f"Archive SHA256 `{digest}`; {archive.stat().st_size:,} bytes / {len(files)+1} entries.\n\n"
readme=summary.replace('[Detailed method/phase tables and raw evidence](validation/qualification/2026-10-26-integrated-repaired-target/README.md).','[Root QM](../../../QM.md).').replace('Historical root QM content follows unchanged.','The root QM retains all prior historical content unchanged.')+seal
readme+='''## Current Oracle method inventory (all PASS)

Every method name below comes from the fresh current-run XML and matches the
unchanged mandatory manifest. No earlier focused result supplies a missing method.

| Suite | Required / passed | Methods |
|---|---:|---|
'''
for s in inventory['oracle_suites']:
 readme+=f"| {s['class']} | {s['tests']} / {s['tests']} | "+'<br>'.join('`'+m+'` PASS' for m in s['methods'])+' |\n'
readme+='''
## In-memory Gatling measurements (all PASS)

HTTP and owner/ledger counters remain separate.0ms warmup is the reported fixture
configuration. These are short semantic checks, not sustained capacity/SLO proof.
`completed_rows` enumerates the harness ledgerKeys list, populated by the leases
fixture; zero in other modes is not a census of single-key reconciliations.
Owner-call counters cover the fixture lifetime, including preparation; scenario
assertions separately prove fresh visits add no fetch and preserve age/retention.
No HTTP202/request count is counted as a completed synchronization.

| Mode | HTTP requests / errors | HTTP p50 / p95 / p99 ms | Accepted visits / job triggers | Raw owner calls | Synthetic ledgerKeys / ledger rows / reported completed_rows | Measurement+drain ms |
|---|---|---|---|---:|---|---:|
'''
for name,d in sorted(e['gatling'].items()):
 h=d['http'];t=h['http_response_time_ms'];readme+=f"| {name} | {h['requests']['total']} / {h['requests']['ko']} | {t['p50']} / {t['p95']} / {t['p99']} | {d['accepted_visits']} / {d['job_requests']} | {d['physical_owner_calls']} | {d['synthetic_rows']} / {d['ledger_rows']} / {d['completed_rows']} | {d['measurement_and_drain_ms']} |\n"
readme+='''
Leases accepted200 job triggers and reported101 completed ledgerKeys; this is not
200 completed synchronizations. All per-scenario projection/ledger assertions and
HTTP assertion XML passed. Oracle workload200 measured completions is a separate
real-Oracle measurement, not derived from these HTTP responses.

## Raw artifact inventory and provenance

- `frozen-source.json`, `frozen-source-end.json`, `qualification-target.json`, `full-inventory-results.json`: exact source/tree,20 prior archive seals, complete83-method mapping and actual ten phase results.
- `default-*/`: matching default c965b470 command/log, original exits, all95 fresh raw files, marker, XML, audit and generated QM. This is not borrowed into the full marker.
- `full-*/`: the single wrapper command and result, original30MB build log, separate qualification/collection logs, all417 fresh raw files and their manifest. Includes original run-scoped QM/evidence JSON,83 Oracle XML methods, current A/B SQL, all runtime receipts, faults, native plans/counters/waits and complete PIT/Gatling HTML assets. The generated full machine report is preserved verbatim, not overwritten by this human summary.
- `result-summary.json`, `human-summary.md`: compact current results/status; report-only commit is not falsely claimed as tested code.
- `comparison-complete-observation.json`: observed boundary acquisitions and committed claims reconciled independently; logical cooldown requests versus accept/apply commits/refusals; no arithmetic remainder classification.
- `full-partial-pit-observation.json`, `running-observation.json`, `run-health-observations.jsonl`: timestamped observations while the run was running. Their RUNNING/partial state is historical progress, not a final qualification claim.
- `survivor-review.json`, `toolchain-observation.json`: raw surviving mutation remains counted, source acceptance review unchanged, actual JDK/JUnit and pinned tool declarations; all later runtime reports remain present.
- `scoped-capacity-*.json`, `capacity-command.*`, `owned-infrastructure-observation.json`, `cleanup-and-preservation.json`: one18GiB admission, actual pinned container caps/mount/loopback,20 receipts/12 PIDs, explicit absent-resource responses and prior-evidence preservation.
- `session.py`, `capacity.py`, `publish-report.py`, `standalone-contracts.*`: exact external orchestration/reporting and86/43 offline assertions; no product implementation change.
- `nonsecret-artifact-check.json`, `raw-archive-manifest.json`, `SHA256SUMS`: bounded generated-credential-format check and all raw entry/archive hashes. This is not general security certification.

The normal/default and full runs have different fresh markers for the same clean
source. The full includes its own224 Surefire tests and all83 Oracle methods;
previous86488c4/c8b6153a diagnostic5/5 remains separate historical evidence.
Original failed b7f3cb5, unclassified55, earlier publication failures and all older
results retain their exact scope/status. Historical worker timeout is unexplained;
current regression PASS is not a causal fix. No new criterion proposal is adopted.

No source edit or concurrent build occurred during full verification/collection.
No additional full run, merge, main change, workflow bootstrap or publication.
'''
(dest/'README.md').write_text(readme,encoding='utf-8');(dest/'result-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert sha((ROOT/'QM.md').read_bytes())==frozen['historical_qm_sha256'];(ROOT/'QM.md').write_bytes((summary+seal).encode('utf-8')+old)
latest='''## Integrated repaired-target full result - 2026-10-26

Clean sourcea0f46d7/tree0382fbe passed matching default222 JUnit/102 Python,
then one unchanged18GiB admission and one complete configured full run751ea112.
Full PASS:224 Surefire /83 Oracle methods across18 suites,0 failures/errors/skips;
all ten original worker phases PASS, fixed160/16.381s and adaptive160/9.904s.
PIT167/168 killed, six in-memory Gatling scenarios/367 requests/0 errors, runtime
receipts, migrations, atomicity/recovery/I/O/quota/creation and all8 comparison
variants passed. Original wrapper/Maven/qualification/collection exits0.
Owned container/volume and12 recorded JVM PIDs independently absent.
Historical worker timeout remains FAILED and unexplained; no pacing/criterion
change. One million seeds produced200 measured completions, not a million syncs.
Configured PASS is not production acceptance: uncertainty/unrecorded responses,
receipt retention, security, operations and other parent gates remain open.
[QM]({qm}) / [raw report]({raw}). Earlier sections remain historical.

'''
for name,qm,raw in [('docs/PRODUCTION-READINESS.md','../QM.md','../validation/qualification/2026-10-26-integrated-repaired-target/README.md'),('docs/USER-HANDBOOK.md','../QM.md','../validation/qualification/2026-10-26-integrated-repaired-target/README.md')]:
 p=ROOT/name;p.write_bytes(latest.format(qm=qm,raw=raw).encode('utf-8')+p.read_bytes())
p=ROOT/'TODO.md';prefix='''## Integrated repaired-target qualification - 2026-10-26

- [x] Execute one matching clean-source default and configured full at sourcea0f46d7/tree0382fbe: defaultc965b470 PASS222 JUnit/102 Python; full751ea112 PASS224 Surefire/83 Oracle methods/18 suites, zero failures/errors/skips. All original worker productive/idle/wakeup/recovery phases passed with160/20s retained. [QM](QM.md) / [raw report](validation/qualification/2026-10-26-integrated-repaired-target/README.md).
- [x] Retain current actual A/B SQL/state/revision proof, all five runtime roles, migration/atomicity/recovery/shutdown/transport/accounting, PIT167/168, six Gatling scenarios and all8 comparison variants; original exits0 and owned cleanup independently verified. No historical diagnostic substitution or source implementation change.
- [ ] Explain historical worker timeout if required for release/reproducibility: it remains FAILED/unexplained; current regression PASS is not a causal repair. No provisional criterion change adopted.
- [ ] Complete production acceptance: uncertain/unrecorded outcomes, receipt retention/maintenance, security/operations, consumer/supply-chain/provider and real capacity/SLO gates remain open. The synthetic million-row seed completed200 measured syncs; JVM used snapshot is not peak/bounded-memory qualification. All parent release gates remain open; production NO-GO.

''';p.write_bytes(prefix.encode('utf-8')+p.read_bytes())
print(json.dumps({'source':run['source_sha'],'tree':run['source_tree'],'full_run':run['run_id'],'full':'PASS','production':'NO_GO','archive_sha256':digest,'archive_bytes':archive.stat().st_size,'entries':len(files)+1}))
