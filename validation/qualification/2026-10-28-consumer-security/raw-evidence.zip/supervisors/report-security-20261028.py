from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();base=root.parent/'qualification-evidence/security-consumers-20261028-r1'
w=base/'consumers-r1';out=root/'validation/qualification/2026-10-28-consumer-security'
sys.path.insert(0,str(root/'scripts'));import consumer_security as s;import consumer_artifacts as c
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
m=s.validate_inputs(root,w);source=m['fixture_source']['source_sha'];tree=m['fixture_source']['source_tree']
default=json.loads((base/'default-r1/raw/target/qm/evidence.json').read_text())
execution=json.loads((base/'default-r1/result.json').read_text())
default_id=default['evidence']['attribution']
assert default['runs']['default']['qualification_exit']==execution['exit']==execution['collection_exit']==0
assert execution['source_after']==m['fixture_source']
count=sum(v['surefire'].get('tests',0) for v in default['evidence']['modules'].values());assert count==222
sup=json.loads((base/'security-r1-supervision-result.json').read_text());infra=json.loads((base/'security-r1-infrastructure.json').read_text())
admission=json.loads(next(w.glob('admission-*.json')).read_text());cleanup=json.loads((base/'independent-cleanup.json').read_text())
assert infra['status']=='BLOCKED' and not infra['container_created'] and infra['maven_exit'] is None
assert sup['original_wrapper_exit']==2 and sup['source_after']==m['fixture_source']
assert not list(w.glob('consumer-run-*.json')) and cleanup['attempt_id']==infra['attempt_id']
assert all(v['exit']==0 and v['owned_resources']==[] for v in cleanup['checks'].values())
cheap={}
for mode in c.MODES:
 suites=[ET.parse(p).getroot() for p in (w/mode/'target/surefire-reports').glob('TEST-*.xml')]
 assert len(suites)==1 and all(int(v.get(k,0))==0 for v in suites for k in ('failures','errors','skipped'))
 cheap[mode]=sum(int(v.get('tests')) for v in suites)
 assert cheap[mode]==(5 if mode=='mvc' else 6) and m['consumers'][mode]['prepare_exit']==0
 assert not list((w/mode/'target/failsafe-reports').glob('TEST-*.xml'))
 assert not (w/mode/'target/consumer-evidence/security.json').exists()
prior=json.loads((base/'preserved-baselines.json').read_text())
assert all(c.digest(root/p)==h for p,h in prior['files'].items())
assert c.digest(root/'QM.md')==prior['qm_sha256']
out.mkdir(exist_ok=False)
c.write(out/'results.json',{'fixture_source':m['fixture_source'],'artifact_source':m['producer'],
 'artifact_files':39,'baseline_manifest_sha256':s.BASE_MANIFEST,'artifacts_unchanged':True,
 'fixture_unchanged_since':'8df8c949b8ddd570cf723e7f7ab522c9aab2e3f2',
 'default':default['runs']['default'],'default_run':default_id,'default_execution':execution,
 'default_counts':{'junit':count,'xml':41,'python':116},'cheap_security':cheap,
 'current_oracle':{mode:{'status':'NOT_RUN','maven_exit':None,'positive_outcomes':None,'negative_outcomes':None,'phase_results':None} for mode in c.MODES},
 'admission':admission,'infrastructure':infra,'supervision':sup,'independent_cleanup':cleanup,
 'collection_exit':0,'evidence_validation_exit':0,'combined_security':'BLOCKED',
 'full':'NOT_RUN','production':'NO_GO','historical_files_unchanged':len(prior['files'])})
shutil.copy2(w/'artifact-manifest.json',out/'artifact-manifest.json')
report=f'''# Final-source secured-consumer execution — 2026-10-28

**Default and cheap consumers PASS. Combined Oracle security qualification BLOCKED;
MVC and WebFlux Oracle journeys NOT_RUN. Production NO-GO.**

No fixture, library, security configuration or assertion was changed during this
attempt. The existing exact stack-specific status checks, CSRF/method authorization,
positive controls and full acceptance matrix remain intact. Historical 401/403
dispatcher behavior remains unexplained; this blocked attempt adds no runtime observation.

## Frozen source and immutable artifact set

- Repository `Tobia5/model-sync-starter`, PR #1, branch `review/layered-refactor-qm-20261020`.
- Fixture source **`{source}`**, tree **`{tree}`**, clean before/after execution.
  The fixture/tooling is unchanged from 8df8c94; intervening commit 5dd0381 contains reports.
- Artifact producer **551427bed4d021339fcc32fef8f633232ff8deb8**, tree
  `892daec99e12738607a9bfe736d8e98ee8218d0c`, original packaging run
  `b3db2e0f-e56a-420f-b379-0d1e73f15eb0`.
- All **39 staged files** and the copies in both new consumer repositories match
  the original hashes. Original manifest SHA-256:
  `{s.BASE_MANIFEST}`.
  No staged artifact was rebuilt or replaced. The required producer default build
  does not install/deploy into or alter this original artifact set.
- Fresh consumer sources were staged from this frozen checkout into
  `../qualification-evidence/security-consumers-20261028-r1/consumers-r1/{{mvc,webflux}}`.
  Their source hashes, separate repository paths, artifact coordinates, dependency
  trees/classpaths and exact commands are in [artifact-manifest.json](artifact-manifest.json)
  and the raw archive. No old consumer source/target directory was reused.
  Only public dependency cache files were copied from the previous task caches;
  `io/modelsync` was explicitly excluded from that copy.

## Execution record

| Stage | Identity / measured count | Original exit and result |
|---|---|---|
| Matching default | `{default_id}`; 222 JUnit / 41 XML / 116 Python | Build 0, qualification 0, collection 0; PASS |
| Standalone MVC preparation | 5 cheap authorization methods, no failures/errors/skips | Maven preparation 0, profile dependency resolution 0; PASS |
| Standalone WebFlux preparation | 6 cheap authorization methods, no failures/errors/skips | Maven preparation 0, profile dependency resolution 0; PASS |
| Core / trigger / recorded default audit | 86 / 43 contract assertions, separate from JUnit | 0 / 0 / 0; PASS |
| Consumer infrastructure attempt | `{infra['attempt_id']}` | Wrapper **2**; BLOCKED before provisioning |
| MVC Oracle journey | No current run ID, receipt, Failsafe XML or phase results | **NOT_RUN**, Maven exit absent |
| WebFlux Oracle journey | No current run ID, receipt, Failsafe XML or phase results | **NOT_RUN**, Maven exit absent |
| Diagnostic collection / validation | Fresh failed-admission receipt, source checks and independent absence checks | 0 / 0; does not override wrapper exit 2 |

Commands (exact argument arrays, working directories and timestamps are archived):

```text
mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml -Dmaven.repo.local=<task-owned-producer-cache> clean verify
python scripts/consumer_security.py stage <new-external-workspace> --artifacts <original-551427b-workspace>
python scripts/consumer_security.py prepare <new-external-workspace>
bash scripts/test-core.sh
bash scripts/test-triggers.sh
python scripts/check-default-log.py <current-default-log>
python scripts/full-oracle-container.py --consumer-diagnostic <new-external-workspace>
```

The staging/preparation commands were invoked through the same script functions by
the retained external supervisors. Each consumer preparation separately runs Maven
`clean test` plus dependency-tree/classpath/plugin resolution. The additional
`-Psecurity-oracle dependency:go-offline` resolves the opt-in plugin without executing
Oracle. Intended offline runtime `-Psecurity-oracle verify` commands were **not reached**.

Invocation-only settings remained `MODELSYNC_ORACLE_CONTAINER=EXPLICIT_DISPOSABLE`,
`MODELSYNC_FULL_ENV_ACK=DISPOSABLE_NONPRODUCTION` and
`MODELSYNC_MAVEN_SETTINGS=.mvn/qualification-central.settings.xml`.
Settings SHA-256 `ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.
No user/global settings or normal Maven cache changes. Java 21.0.12.1, Maven 3.9.9,
Python 3.12.10; Boot 4.1.1 / BOM-pinned Spring Security 7.1.1 remain unchanged.
No current Oracle/JDBC/Hibernate runtime version receipt exists because execution
did not start; prior runtime receipts remain attributed to their original runs.

One external supervisor launch initially exited 1 on a copied UTF-8 BOM decoded
with the locale encoding, before Maven ran. Its failure and bytes are retained.
Explicit UTF-8 decoding corrected only that task-local supervisor; the subsequent
actual default build/exits above are separate, and repository source was unchanged.

## One bounded admission and cleanup

Resource receipt **`{admission['attempt_id']}`** was collected after default build,
collection and both consumer preparations finished:

| Resource | Observation | Requirement / decision |
|---|---|---|
| Host available RAM | **6.246 / 6.251 / 6.259 GiB** | At least **12 GiB**; FAILED admission criterion |
| Docker available capacity | 19.441 GiB, 8 CPUs | Existing 6 GiB / 4 CPU Oracle allocation; PASS |
| C / D free disk | 59.651 / 1066.587 GiB | At least 20 GiB each; PASS |

The separate full budget remains **18 GiB**. No threshold reduction, additional
admission attempt, global setting change or unrelated workload termination occurred.
The pinned Oracle image and 6 GiB / 4 CPU limits were retained in configuration:
`ghcr.io/gvenzl/oracle-free:23.26.3-slim@sha256:6d61d267a3b978c24c5ac1790e62e927416a0aec446bd86e4b3a1527562757bd`.
No image/container/schema/credential provisioning or Oracle-journey JVM startup occurred.
Generated per-run credentials, separate runtime/migration schemas and loopback-only
ports remain required for an admitted execution.

Independent Docker container and volume queries filtered by the exact attempt
ownership label both exited 0 with empty results. No test-owned runtime resources
remain. New external source/build directories, caches and evidence are intentionally
retained; unrelated resources were not modified.

## Acceptance status and next prerequisite

All required live outcomes are **NOT_RUN for this source/attempt**: four committed
reconciliations per host, same subject in two tenants, all 30 denials per host,
expected/actual HTTP status and challenge observations, unchanged protected side
effects, direct-facade defenses, 32 concurrent WebFlux identities, authenticated/
CSRF-valid positive controls, rollback/enlistment, disabled mode and physical shutdown.
Cheap tests are not substitutes for these Oracle journeys. Earlier WebFlux passes
are historical evidence only; the combined milestone cannot be marked PASS.

The next prerequisite is **at least 12 GiB available host memory at the existing
post-preparation admission check**, with the Docker/disk checks also satisfied.
Any later attempt needs fresh source-matched default/consumer evidence; no marker
or report from this blocked attempt may be reused as runtime proof. An unexpected
status mismatch must retain bounded nonsecret handler/dispatcher evidence before
proposing a fixture change. No arbitrary-4xx acceptance is permitted.

Accepted full a0f46d7/report 8d07aa7, artifact consumers 551427b/report 50c9370,
security fixture 8df8c94/report 5dd0381 and all **91 prior qualification files**
were checked unchanged. The prior QM content is preserved. No R06.1/R06.3 runtime
leaf newly closes. Real identity-provider integration, revocation, provider transport,
retention, uncertainty, operations and distribution remain separate open gates.
No producer full, PIT, Gatling, million-row workload, merge, main/workflow change,
package publication or production approval occurred.

[Results](results.json), [artifact hashes](artifact-manifest.json),
[raw evidence](raw-evidence.zip), [raw inventory](raw-manifest.json),
[checksums](SHA256SUMS.txt). Run-scoped report and evidence copies are under
`target/qm/consumer-security/{infra['attempt_id']}/`.
'''
(out/'README.md').write_text(report,encoding='utf-8')
qm=f'''## Secured-consumer execution — 2026-10-28

**Default/cheap security PASS; Oracle admission BLOCKED; both Oracle journeys
NOT_RUN; producer full NOT_RUN; production NO-GO.**

Frozen source `{source}`, tree `{tree}`, clean before/after.
Fixture unchanged from 8df8c94; original 551427b artifact set (39 files) and both
new cache copies verified unchanged. No fixture/library/policy/assertion edits.

- Matching default `{default_id}`: 222 JUnit / 41 XML / 116 Python,
  build/qualification/collection **0/0/0**. Core 86 / trigger 43 assertions and
  default execution audit passed. Approved settings and task-owned Maven cache.
- Fresh external consumers: MVC **5** / WebFlux **6** cheap methods, preparation
  and profile-resolution exits **0**. No stale copied source or runtime report.
- `python scripts/full-oracle-container.py --consumer-diagnostic <workspace>`:
  attempt `{infra['attempt_id']}`, original wrapper exit **2**.
  Host availability **6.246 / 6.251 / 6.259 GiB** versus required **12 GiB**;
  Docker/disk checks passed. Full budget remains 18 GiB. No admission retry.
- Both Oracle journeys and their positive/negative/committed-outcome/identity/
  shutdown phases **NOT_RUN**; no runtime Maven exits or receipts. Earlier
  WebFlux successes and MVC failures are not substituted or relabelled.
- No container, volume, schema or Oracle-journey JVM was created. Independent exact-label
  container/volume checks confirm absence. Collection/validation exited 0,
  preserving the original wrapper failure. Local evidence/caches remain retained.

[Detailed report and raw evidence](validation/qualification/2026-10-28-consumer-security/README.md)
and [current acceptance matrix](docs/quality/ACCEPTANCE-MATRIX.md). All 91 prior
qualification files and the earlier QM content remain unchanged. Historical
401/403 dispatch behavior is still unexplained. Final-source combined security
requires both complete Oracle journeys after resource admission; no new R06 runtime
leaf closes. Identity-provider/revocation, transport, retention, uncertainty,
operations and distribution remain open. No full/PIT/Gatling/million-row repeat,
merge, main/workflow change or package publication.

---

'''
p=root/'QM.md';p.write_bytes(qm.encode()+p.read_bytes());assert p.read_bytes().endswith((base/'QM.original.md').read_bytes())
matrix=root/'docs/quality/ACCEPTANCE-MATRIX.md';text=matrix.read_text(encoding='utf-8')
text=text.replace('  cheap security methods PASS. Current Oracle attempt','  cheap security methods PASS. The 2026-10-26 Oracle attempt')
assert '- **H** —' in text
text=text.replace('- **H** —',f'''- **S2** — unchanged security fixture at clean `{source}`, tree `{tree}`,
  default `{default_id}` PASS (222 JUnit / 116 Python), fresh external
  MVC 5 / WebFlux 6 cheap methods PASS. Oracle attempt `{infra['attempt_id']}`
  BLOCKED at 6.246–6.259 GiB host availability versus 12 GiB; both journeys NOT_RUN,
  wrapper exit 2, no resources created. [2026-10-28 evidence](../../validation/qualification/2026-10-28-consumer-security/README.md).
- **H** —''')
text=text.replace('F library contracts; S actual filter-chain/method checks','F library contracts; S/S2 actual filter-chain/method checks')
text=text.replace('DONE for S cheap checks and source-bound WebFlux scenarios. OPEN: final-source two-stack Oracle verification (memory BLOCKED)', 'DONE for S/S2 cheap checks and S source-bound WebFlux scenarios. OPEN: final-source two-stack Oracle verification (S2 memory BLOCKED; both NOT_RUN)')
text=text.replace('F library/schema checks; S missing grants/unknown scope/fresh-cache denials;', 'F library/schema checks; S/S2 missing grants/unknown scope/fresh-cache denials;')
text=text.replace('DONE for declared F and executed S checks. OPEN: final-source two-stack Oracle verification,', 'DONE for declared F and executed S/S2 checks. OPEN: final-source two-stack Oracle verification (S2 NOT_RUN),')
matrix.write_text(text,encoding='utf-8')
p=root/'TODO.md';text=p.read_text(encoding='utf-8')
old='''- [ ] Final-source MVC/WebFlux Oracle security journeys: attempt `47b66c3c-6d1e-425e-bedb-ebd7d1438ec2`
  BLOCKED at 9.458–9.699 GiB host availability versus 12 GiB; both NOT_RUN. Prior MVC
  response-status assertion failures are preserved; correction awaits Oracle execution.
  [Scoped evidence](validation/qualification/2026-10-26-consumer-security/README.md).
  Real identity-provider/production authorization and broader R06 gates remain open.'''
assert old in text
text=text.replace(old,f'''- [ ] Final-source MVC/WebFlux Oracle security journeys: source `{source[:7]}` passed
  matching default (222 JUnit / 116 Python) and fresh cheap consumers (5 / 6).
  Attempt `{infra['attempt_id']}` on 2026-10-28 BLOCKED at 6.246–6.259 GiB
  host availability versus 12 GiB; both journeys NOT_RUN, wrapper exit 2, no resources created.
  [Current evidence](validation/qualification/2026-10-28-consumer-security/README.md).
  The 2026-10-26 blocked attempt and earlier MVC assertion failures remain
  [unchanged history](validation/qualification/2026-10-26-consumer-security/README.md).
  No status/CSRF/authorization assertion changed; historical dispatcher cause is unresolved.
  Real identity-provider/production authorization and broader R06 gates remain open.''')
p.write_text(text,encoding='utf-8')
handbook=f'''## Current secured-consumer execution — 2026-10-28

Clean fixture `{source[:7]}` (unchanged from 8df8c94) passed fresh default and
independent cheap MVC/WebFlux checks using the original 39-file 551427b artifact
set. Oracle execution was **BLOCKED** at 6.246–6.259 GiB available host memory
against the unchanged 12 GiB requirement; both live journeys are **NOT_RUN**.
No assertion, CSRF/method-security configuration or integration boundary changed.
Earlier WebFlux results and MVC failures remain source-bound history; the combined
milestone is still open. [Exact commands, resources and evidence](../validation/qualification/2026-10-28-consumer-security/README.md).

The next execution needs fresh source-matched preparation and successful existing
resource admission. Historical 401/403 dispatch behavior is not diagnosed by this
attempt. Production remains NO-GO; the tested boundary and wider limits below apply.

---

'''
p=root/'docs/USER-HANDBOOK.md';p.write_bytes(handbook.encode()+p.read_bytes())
checks=[]
for name,cmd in [('docs',[sys.executable,'scripts/check-docs.py']),('architecture',[sys.executable,'scripts/check-architecture.py']),('diff',['git','diff','--check'])]:
 with (base/f'report-{name}.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 checks.append({'command':cmd,'exit':code});assert code==0
c.write(base/'report-checks.json',checks)
files={};excluded={'m2-mvc','m2-webflux','staged','classes','test-classes','__pycache__','.git'}
allowed={'.md','.json','.xml','.txt','.log','.java','.py','.properties'}
for directory,dirs,names in os.walk(base):
 dirs[:]=[d for d in dirs if d not in excluded]
 for name in names:
  p=Path(directory)/name
  if p.suffix in allowed:files['attempt/'+p.relative_to(base).as_posix()]=p
for p in root.parent.glob('*security-20261028.py'):files['supervisors/'+p.name]=p
for p in [out/'README.md',out/'results.json',out/'artifact-manifest.json',root/'.mvn/qualification-central.settings.xml']:
 files['current/'+p.name]=p
entries=[];patterns=[rb'(?<![0-9a-fA-F])[0-9a-fA-F]{48}(?![0-9a-fA-F])',rb'Authorization[^\r\n]{0,30}Basic [A-Za-z0-9+/=]{16,}',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}']
for name,p in sorted(files.items()):
 data=p.read_bytes();assert not any(re.search(pattern,data) for pattern in patterns),'Credential pattern in '+name
 entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
c.write(out/'raw-manifest.json',{'files':entries,'credential_pattern_scan':'PASS','historical_file_hashes_verified':prior['files'],'excluded':'Caches, staged binaries, classes; immutable original artifacts remain local'})
archive=out/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.write(out/'raw-manifest.json','raw-manifest.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
(out/'SHA256SUMS.txt').write_text(''.join(f'{c.digest(out/n)}  {n}\n' for n in ['raw-evidence.zip','raw-manifest.json','results.json','artifact-manifest.json']))
scoped=root/'target/qm/consumer-security'/infra['attempt_id'];scoped.mkdir(parents=True,exist_ok=False)
for n in ['README.md','results.json','artifact-manifest.json','raw-manifest.json','raw-evidence.zip','SHA256SUMS.txt']:
 shutil.copy2(out/n,scoped/('QM.md' if n=='README.md' else n))
print(json.dumps({'source':source,'tree':tree,'attempt':infra['attempt_id'],'status':'BLOCKED','original_wrapper_exit':2,'collection_exit':0,'evidence_validation_exit':0,'zip_bytes':archive.stat().st_size,'zip_entries':len(entries)+1,'sha256':c.digest(archive),'historical_files_unchanged':len(prior['files'])}))
