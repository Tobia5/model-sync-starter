"""Local qualification supervisor/archiver for the authorized Model Sync session only."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1] / 'model-sync-starter'
sys.path.insert(0, str(ROOT / 'scripts'))
from run_evidence import current, identity, fresh, reactor_modules, invalidate

mode = sys.argv[1]
assert mode in {'default', 'diagnostic', 'full'}
directory = BASE / (mode + '-' + str(uuid.uuid4()))
directory.mkdir()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip(), 'Clean source required'
if mode != 'diagnostic': invalidate(ROOT)
environment = dict(os.environ, MODELSYNC_MAVEN_SETTINGS='.mvn/qualification-central.settings.xml')
for key in ('MODELSYNC_ORACLE_URL', 'MODELSYNC_ORACLE_USER', 'MODELSYNC_ORACLE_PASSWORD',
            'MODELSYNC_ORACLE_MIGRATION_URL', 'MODELSYNC_ORACLE_MIGRATION_USER', 'MODELSYNC_ORACLE_MIGRATION_PASSWORD'):
    environment.pop(key, None)
if mode != 'default':
    environment.update(MODELSYNC_ORACLE_CONTAINER='EXPLICIT_DISPOSABLE',
                       MODELSYNC_FULL_ENV_ACK='DISPOSABLE_NONPRODUCTION')
command = ([str(ROOT / 'mvnw.cmd'), '-B', '-ntp', '-s', '.mvn/qualification-central.settings.xml', 'clean', 'verify']
           if mode == 'default' else [sys.executable, '-u', 'scripts/full-oracle-container.py', *(['--comparison-accounting-diagnostic'] if mode == 'diagnostic' else [])])
bound = 10800 if mode == 'full' else 1800 if mode == 'diagnostic' else 600
launch = {**identity(ROOT), 'supervisor_launch_ns': time.time_ns(),
          'supervisor_launch_utc': datetime.now(timezone.utc).isoformat(), 'bound_seconds': bound,
          'bound_basis': 'manual workflow 180 minutes' if mode == 'full' else 'scoped local diagnostic/default budget',
          'command': command, 'maven_settings': environment['MODELSYNC_MAVEN_SETTINGS'],
          'external_oracle_variables_cleared': True}
(directory / 'launch.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps({'attempt_directory': str(directory), **launch}), flush=True)
with (directory / 'build.log').open('w', encoding='utf-8') as output:
    child = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=output, stderr=subprocess.STDOUT,
                             creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0)
    # On timeout stop only this owned subprocess tree; wrapper finally performs labelled cleanup.
    try:
        code = child.wait(timeout=bound)
    except subprocess.TimeoutExpired:
        import signal
        child.send_signal(signal.CTRL_BREAK_EVENT if os.name == 'nt' else signal.SIGINT)
        try: code = child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            raise RuntimeError('Owned wrapper did not stop; preserve resources for explicit scoped cleanup')
        launch['supervisor_timeout'] = True
        if code == 0: code = 124
launch.update(exit=code, elapsed_seconds=round((time.time_ns() - launch['supervisor_launch_ns']) / 1e9, 3))
(directory / 'result.json').write_text(json.dumps(launch, indent=2) + '\n')
log = ROOT / 'target/qm' / (mode + '-build.log')
log.parent.mkdir(parents=True, exist_ok=True)
raw_log = (directory / 'build.log').read_bytes()
try:
    decoded_log = raw_log.decode('utf-8')
    launch['log_decode'] = 'utf-8'
except UnicodeDecodeError:
    # Verified JVM stdout.encoding/native.encoding=Cp1252 in this Windows build's XML.
    decoded_log = raw_log.decode('cp1252')
    launch['log_decode'] = 'cp1252; normalized to UTF-8; original build.log retained'
log.write_text(decoded_log, encoding='utf-8')
if mode == 'diagnostic':
    with (directory / 'qualification.log').open('w',encoding='utf-8') as output:
        checked = subprocess.run([sys.executable,'-c',
            "import sys;from pathlib import Path;sys.path.insert(0,'scripts');from queue_evidence import optimization;optimization(Path('.').resolve());print('ACCOUNTING DIAGNOSTIC EVIDENCE PASS')"],cwd=ROOT,env=environment,stdout=output,stderr=subprocess.STDOUT)
    launch['diagnostic_evidence_exit']=checked.returncode
    infrastructure=json.loads((ROOT/'target/qm/oracle-container.json').read_text(encoding='utf-8'))
    launch.update(nested_maven_exit=infrastructure.get('maven_exit'),diagnostic_exit=infrastructure.get('diagnostic_exit'),owned_cleanup_verified=infrastructure.get('cleanup_verified'))
if mode in {'default','full'}:
    gate = 'check-test-reports.py' if mode == 'default' else 'check-full-reports.py'
    with (directory / 'qualification.log').open('w',encoding='utf-8') as output:
        checked = subprocess.run([sys.executable,'scripts/'+gate],cwd=ROOT,env=environment,stdout=output,stderr=subprocess.STDOUT)
    launch['qualification_exit'] = checked.returncode
    if mode == 'default':
        with (directory / 'execution-audit.log').open('w',encoding='utf-8') as output:
            audited = subprocess.run([sys.executable,'scripts/check-default-log.py',str(log)],cwd=ROOT,env=environment,stdout=output,stderr=subprocess.STDOUT)
        launch['execution_audit_exit'] = audited.returncode
    if mode == 'full' and (ROOT/'target/qm/oracle-container.json').is_file():
        infrastructure=json.loads((ROOT/'target/qm/oracle-container.json').read_text(encoding='utf-8'))
        launch['nested_maven_exit']=infrastructure.get('maven_exit')
        launch['infrastructure_attempt_id']=infrastructure.get('attempt_id')
        launch['owned_cleanup_verified']=infrastructure.get('cleanup_verified')
    args = [sys.executable, 'scripts/qm-report.py', '--' + mode + '-command', subprocess.list2cmdline(command),
            '--' + mode + '-exit', str(code), '--' + mode + '-status', 'PASS' if code == 0 and launch['qualification_exit']==0 else 'BLOCKED' if 'BLOCKED full preflight' in decoded_log and code else 'FAILED']
    with (directory / 'collector.log').open('w', encoding='utf-8') as output:
        collected = subprocess.run(args, cwd=ROOT, env=environment, stdout=output, stderr=subprocess.STDOUT)
    launch['collector_exit'] = collected.returncode
try:
    context = current(ROOT)
except ValueError as error:
    context = {**launch, 'run_id': None, 'started_ns': launch['supervisor_launch_ns'],
               'evidence_attribution': 'NONE', 'reason': str(error)}
files = {}
for module in reactor_modules(ROOT, True):
    for lane in ('surefire-reports', 'failsafe-reports', 'qm', 'gatling', 'pit-reports'):
        for path in (module / 'target' / lane).rglob('*'):
            if context['run_id'] and path.is_file() and path.stat().st_mtime_ns >= context['started_ns']:
                files[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
for path in (ROOT / 'target/qm').glob('*'):
    if path.is_file() and path.stat().st_mtime_ns >= context['started_ns'] and (
            context['run_id'] or path.name in {'oracle-container.json','QM.md','evidence.json'}):
        files[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
for name, digest in files.items():
    target = directory / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / name, target)
if context['run_id']:
    assert current(ROOT) == context, 'Source/run changed during evidence collection'
(directory / 'archive-manifest.json').write_text(json.dumps({**context, 'scope': mode,
    'command_exit': code, 'qualification': 'DIAGNOSTIC_ONLY' if mode == 'diagnostic' else mode.upper(),
    'files_sha256': files}, indent=2) + '\n')
(directory / 'result.json').write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps({'attempt_directory': str(directory), 'run_id': context['run_id'],
                  'exit': code, 'raw_files': len(files), 'elapsed_seconds': launch['elapsed_seconds']}), flush=True)
raise SystemExit(code)
