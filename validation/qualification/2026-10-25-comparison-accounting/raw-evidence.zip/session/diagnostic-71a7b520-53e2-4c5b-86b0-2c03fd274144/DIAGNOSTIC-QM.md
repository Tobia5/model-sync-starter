# Run-scoped diagnostic QM

**FAILED. Full NOT_RUN. Production NO-GO.**

Tested source `36ec8cac6cb5143d8f6f0a2e5a0818114652f724`, tree `fd6d1bf049ed00b5116684240fd1a8c728815ff5`, clean source-change digest
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`; run `1451f5ce-a4c4-4654-ba9a-947dc493ccc6`, infrastructure `55abb83c-50da-4c2c-b0ec-05807248c4da`.
Command: `python scripts/full-oracle-container.py --comparison-accounting-diagnostic`.
Approved project settings `.mvn/qualification-central.settings.xml`; SHA-256
`ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`. Generated credentials and isolated runtime/migration
schemas; pinned Oracle image, 6 GiB / 4 CPU, loopback port. No external database.

Nested Maven full-preflight exit0; selected JUnit launcher1; wrapper1; supervisor1;
strict comparison evidence gate1. One OracleOptimizationIT method found/started/failed,
zero skipped/aborted. All eight variants ran. Post-run collection/parser check exit0
preserves failures: six variants accepted, two rejected for failed cooldown publication.
Original reports, exits and manifests remain unchanged.

| Round | Variant | Committed claims | Grants | Denials | Acquisition refusals | Owner entries | Committed syncs | Cooldowns published | Cooldown failures | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| 0 | baseline | 363 | 221 | 120 | 22 | 221 | 201 | 13 | 0 | PASS |
| 0 | selector-only | 460 | 220 | 231 | 9 | 220 | 200 | 10 | 3 | FAILED |
| 0 | admission-only | 220 | 220 | 0 | 0 | 220 | 200 | 13 | 0 | PASS |
| 0 | combined | 224 | 220 | 4 | 0 | 220 | 200 | 13 | 0 | PASS |
| 1 | combined | 224 | 220 | 3 | 1 | 220 | 200 | 13 | 0 | PASS |
| 1 | admission-only | 220 | 220 | 0 | 0 | 220 | 200 | 13 | 0 | PASS |
| 1 | selector-only | 711 | 220 | 447 | 44 | 220 | 200 | 11 | 2 | FAILED |
| 1 | baseline | 382 | 223 | 133 | 26 | 223 | 202 | 13 | 0 | PASS |

Measured totals: 2,804 independently observed acquisitions =1,764 returned grants +938
returned denials +102 thrown refusals. All102 acquisition faults are LocalContention,
SQLState61000, vendor54. Zero other known acquisition failures, unknown/uncertain outcomes,
active operations or unclassified attempts. These current facts do not classify historical55.
Claims partition into1,603 reconciled,938 denied,102 acquisition refusals,156 owner failures
with committed retry metadata, and5 post-grant cooldown-publication failures before retry
metadata. Every owner entry has exactly one committed grant/use; no refund capability exists.

Cooldowns:104 actual attempts,99 publications,5 thrown failures. The5 refused extensions
are not persisted. They are separate from acquisition failures and from retry-metadata SQL
failures (none observed here). Owner failures:104 synthetic429 and57 timeouts. No grant
or physical owner call is forgotten after its later failure. Both selector-only measurements
lost worker lanes after their failures; their performance values cannot qualify an equivalent
four-lane comparison. Completion floors and denial/native-work assertions remain in source;
aggregate qualification requires all eight PASS and remains failed.

Small probe: held acquisition returned in110ms; held publication in11ms. Actual SQL is
`select spacing_ms,next_allowed_ms from MS_QUOTA where quota_group=:1 for update nowait`
and `select next_allowed_ms from MS_QUOTA where quota_group=:1 for update nowait`.
Both sessions had LOCK_WAIT0/TX_ACTIVE1 before rollback, LOCK_WAIT0/TX_ACTIVE0 afterward
while the competing lock remained held; the guard write rolled back. No owner without
admission, failed extension unchanged, later recovery grant/owner/success1 each, monotonic
publication, pool active0 and owned executor terminated. Cleanup release earns no refusal credit.

100,000 seeded/due records, seed92,581ms; configured4 coordinator workers, pool8,
20ms owner spacing,5/25ms latency,429 every17th call, timeout every29th. All variants use
ORACLE_NOWAIT quota and ORACLE_26_NOWAIT insertion; original table/index statistics,
forward/reverse order, warmups and cache/history caveats are in raw evidence. Measurement
is direct runOne with5ms sleep, not the auto-configured Reactor worker. Warmup is separate:
1,844 owner entries /1,683 committed syncs including warmup versus1,764/1,603 measured.
Probe recovery adds one owner entry outside these comparison counts. No million-row seed.
Latency percentiles exclude escaped failed ticks; lag covers completed warmup and measurement
rows. No capacity or production-SLO claim follows from these failed comparisons.

All eight physical drain snapshots show terminated worker pools and0 owner operations,
pool connections, other active server requests and server transactions. Fixture rows remaining0;
only this run's owned container `msq-3f0c315fc9e8` and volume `msq-3f0c315fc9e8-data`
were removed. Wrapper cleanup and independent Docker absence inspections PASS.

Full entry point was not launched: the complete focused comparison is an unmet prerequisite.
The unchanged77-method full inventory, JPA runtime-policy receipts, PIT and Gatling are NOT_RUN
for this attempt. Named target oracle26-nowait-ledger-first-v1 and applicability are unchanged.
Historical full25297fd remains FAILED; historical independent cancellation remains FAILED,
current characterization NOT_RUN. Provider cooldown publication/recovery, other budget,
security, operations and consumer release gates remain open. No merge/publication/production approval.
