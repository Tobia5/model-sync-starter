# Model Sync quality evidence

Generated: 2026-10-25T08:03:37.616907+00:00
Source at report generation: `09f371cc013641a7723e7c355cb58cc86e04b666`; tree: `43135c799934192b8a3b5b14da6f3fc4b01cba89`.
Evidence attribution: NONE.
Working tree dirty at report generation: false.
Environment: openjdk version "21.0.12.1" 2026-08-18 LTS; Apache Maven 3.9.9 (8e8579a9e76f7d015ee5ec7bfcdc97d260186937); Python 3.12.10.

## Commands and outcome

| Lane | Exact command | Exit | Status |
|---|---|---:|---|
| default | `NOT_RUN` | NOT_RUN | NOT_RUN |
| full | `python ../qualification-evidence/integrated-named-target-20261025/full_capacity.py` | 2 | BLOCKED |

## Measured evidence

Surefire: 0 tests, 0 failures, 0 errors, 0 skipped across 0 XML files.
Failsafe: 0 tests, 0 failures, 0 errors, 0 skipped across 0 XML files.
Named configuration: oracle26-nowait-ledger-first-v1; NOT_RUN; never DEFAULT/all-configuration qualification.
Independent plain-UPDATE cancellation: {"applicability": "driver characterization; not mandatory for the named protected paths", "current_status": "NOT_RUN", "historical_capability": "FAILED", "historical_report": "43040e7", "historical_source": "2c39b75"}
PIT: NOT_RUN.
Gatling: NOT_RUN; no latency percentiles or completed-throughput measurement.
Oracle scale: NOT_RUN.
Oracle reconciliation workload: NOT_RUN.
Actual Reactor worker: NOT_RUN.

## Scope and blockers

A default PASS does not qualify full release behavior. Full requires Oracle migration/concurrency/scale/capacity and seven starter JPA/JDBC atomicity tests, actual claim plans/counters, selected PIT scope at 85% killed/generated, and all six Gatling reports. See `scripts/check-full-reports.py`.
The local Gatling harness uses an in-memory test store; its data is not Oracle capacity evidence.
No package publication or production deployment is authorized by this report.

Rejected evidence: Run identity marker absent
- Host available11.115/11.224/11.046 GiB below unchanged18 GiB full planning budget; no resource-admission retry
- Full wrapper/Maven/Oracle/PIT/Gatling/current characterization NOT_RUN. Fresh default remains separately archived under its own marker.
