"""Read archived completed attempts only; never execute or qualify a build."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1] / 'model-sync-starter'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def attempt(directory):
    result = read(directory / 'result.json')
    manifest = read(directory / 'archive-manifest.json')
    evidence = read(directory / 'target/qm/evidence.json')
    assert result['source_sha'] == manifest['source_sha'] == evidence['source_sha']
    assert result['source_tree'] == manifest['source_tree'] == evidence['source_tree']
    assert manifest['run_id'] == evidence['evidence']['attribution']
    for name, expected in manifest['files_sha256'].items():
        assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == expected, name
    junit = {}
    cases = {}
    for lane in ('surefire-reports', 'failsafe-reports'):
        total = Counter()
        suites = []
        for path in sorted(directory.glob('*/target/' + lane + '/TEST-*.xml')):
            suite = ET.parse(path).getroot()
            assert suite.tag == 'testsuite', path
            values = {key: int(suite.attrib[key]) for key in ('tests', 'failures', 'errors', 'skipped')}
            total.update(values)
            suites.append({'name': suite.get('name'), **values, 'seconds': float(suite.get('time', '0'))})
            if lane == 'failsafe-reports':
                cases[suite.get('name').rsplit('.', 1)[-1]] = sorted(
                    case.get('name', '').removesuffix('()') for case in suite.findall('testcase'))
        junit[lane] = {**total, 'files': len(suites), 'suites': suites}
    log = (directory / 'build.log').read_bytes().decode('cp1252')
    python = re.findall(r'Ran (\d+) tests in ([\d.]+)s', log)
    return {'directory': directory.name, 'result': result, 'run_id': manifest['run_id'],
            'raw_files': len(manifest['files_sha256']), 'junit': junit,
            'oracle_methods': cases, 'python_checks': python, 'evidence': evidence}

default = attempt(next(BASE.glob('default-*')))
full = attempt(next(BASE.glob('full-*')))
inventory = read(ROOT / 'docs/quality/qualification-target.json')
required = {suite: sorted(methods) for module in inventory['mandatory'].values()
            for suite, methods in module.items()}
inventory_match = full['oracle_methods'] == required
pit_path = BASE / full['directory'] / 'model-sync-testkit/target/pit-reports/mutations.xml'
pit = Counter(m.get('status') for m in ET.parse(pit_path).getroot().iter('mutation')) if pit_path.is_file() else Counter()
summary = {'source_sha': default['result']['source_sha'], 'source_tree': default['result']['source_tree'],
           'qualification_target': inventory['target'], 'claim_scope': 'named-configuration-only',
           'default': default, 'full': full, 'oracle_inventory_exact_match': inventory_match,
           'required_oracle_methods': sum(map(len, required.values())),
           'required_oracle_suites': len(required), 'pit_raw_counts': dict(pit),
           'pit_killed_all_generated_percent': 100 * pit['KILLED'] / sum(pit.values()) if pit else None,
           'production_readiness': 'NO_GO', 'historical_cancellation': 'FAILED',
           'current_characterization': 'NOT_RUN'}
(BASE / 'analysis-complete.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'source': summary['source_sha'], 'default_run': default['run_id'],
                  'full_run': full['run_id'], 'inventory_exact': inventory_match,
                  'default_exits': default['result'], 'full_exits': full['result'],
                  'pit': dict(pit)}, indent=2))
