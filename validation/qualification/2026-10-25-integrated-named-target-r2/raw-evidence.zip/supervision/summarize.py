"""Produce a compact review index from the completed, hash-verified raw attempts."""
from pathlib import Path
from collections import Counter
import json
import re
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
a = json.loads((BASE / 'analysis-complete.json').read_text(encoding='utf-8'))
full = BASE / a['full']['directory']
default = BASE / a['default']['directory']
def read(path):
    return json.loads(path.read_text(encoding='utf-8'))
def totals(lane):
    return {k:v for k,v in lane.items() if k != 'suites'}
def intervals(work):
    return dict(Counter(x['attribution'] for x in work['cursor_intervals']))

work = read(full / 'model-sync-persistence-jdbc/target/qm/oracle-workload.json')
phases = read(full / 'model-sync-persistence-jdbc/target/qm/oracle-workload-phases.json')
comparison = read(full / 'model-sync-persistence-jdbc/target/qm/oracle-optimization.json')
scale = read(full / 'model-sync-persistence-jdbc/target/qm/oracle-scale.json')
first = comparison['results'][0]
quota_interval = next(x for x in first['measurement_work']['cursor_intervals']
    if (x.get('after') or x.get('before') or {}).get('SQL_TEXT','').startswith(
        'select spacing_ms,next_allowed_ms from MS_QUOTA'))
assert quota_interval['attribution'] == 'VALID'
assert quota_interval['counter_deltas']['EXECUTIONS'] == 426
assert quota_interval['counter_deltas']['FETCHES'] == 371
assert first['ledger_attempts'] == 426 and first['quota_grants'] == 220 and first['quota_denials'] == 151
identity = {k:a[k] for k in ('source_sha','source_tree','qualification_target','claim_scope')}
failure = {**identity, 'run_id':a['full']['run_id'], 'status':'FAILED',
    'test':'io.modelsync.jdbc.OracleOptimizationIT.comparesIndependentChangesOnTheSameOraclePopulation',
    'source_line':212, 'assertion':'ledger_attempts == quota_grants + quota_denials',
    'ledger_attempts':426, 'quota_grants':220, 'quota_denials':151, 'unaccounted_returned_decisions':55,
    'measured_owner_calls':220, 'measured_completed_syncs':200,
    'quota_sql_interval':quota_interval,
    'session_rollbacks':first['measurement_work']['session_statistics']['user rollbacks'],
    'demonstrated':'The assertion omits executions that do not return a grant/deny decision. MeasuredQuotaGate increments only after delegate.acquire returns; SyncCoordinator.runOne returns true for a claimed attempt whose preparation later fails.',
    'classification_limit':'426 continuous quota-lock SQL executions, 371 fetches and 55 transaction rollbacks are retained. Per-attempt exception codes were not captured, so the 55 are not all asserted to be ORA-00054 or assigned to a production safety regression.',
    'comparison_scope':'Only baseline round0 reached measurement; the other seven variant/round measurements did not execute. No before/after comparison PASS or speedup is claimed.',
    'next_focused_work':'Instrument returned decisions, acquisition exceptions and any pre-admission terminal outcomes separately, with deterministic counter regressions and a complete accounting identity. Keep committed-admission/physical-call controls and all existing thresholds.',
    'unchanged_rerun':False, 'production_source_changed':False}
(BASE / 'failure-analysis.json').write_text(json.dumps(failure,indent=2)+'\n',encoding='utf-8')

pit = read(full / 'target/qm/evidence.json')['evidence']['mutation']
counts = {k:pit['counts'].get(k,0) for k in ('KILLED','SURVIVED','NO_COVERAGE','TIMED_OUT','RUN_ERROR','UNKNOWN')}
mutations = list(ET.parse(full / 'model-sync-testkit/target/pit-reports/mutations.xml').getroot().iter('mutation'))
survivors = [x for x in mutations if x.get('status') != 'KILLED']
assert len(survivors) == 1 and survivors[0].get('status') == 'SURVIVED'
review = {**identity, 'run_id':a['full']['run_id'], 'pit_version':'1.25.9',
    'junit_provider':'pitest-junit5-plugin 1.2.3', 'junit_platform':'6.0.3',
    'threshold_percent':85, 'score_definition':'100 * KILLED / all generated mutations',
    'counts':counts, 'generated':sum(counts.values()),
    'score_percent':100*counts['KILLED']/sum(counts.values()), 'exclusions':[],
    'scope_manifest':'source-contracts/model-sync-testkit/pom.xml',
    'reviews':[{'status':'SURVIVED','class':survivors[0].findtext('mutatedClass'),
        'method':survivors[0].findtext('mutatedMethod'),'line':int(survivors[0].findtext('lineNumber')),
        'mutator':survivors[0].findtext('mutator'),'description':survivors[0].findtext('description'),
        'reason':'Rechecked current source line19: removing positive(maxAge) retains the positive(refreshAfter) and refreshAfter <= maxAge constraints. Nonpositive maxAge still fails that ordering; null still throws NullPointerException in compareTo. This is the previously reviewed equivalent constructor validation, not an exclusion. It remains in the denominator.'}],
    'mutation_status':'PASS', 'full_qualification':'FAILED'}
(BASE / 'mutation-review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')

inventory = read(BASE / 'source-contracts/docs/quality/qualification-target.json')
missing = {name:methods for module in inventory['mandatory'].values() for name,methods in module.items()
           if name not in a['full']['oracle_methods']}
e = a['full']['evidence']['evidence']
summary = {**identity, 'default':{
        'run_id':a['default']['run_id'], 'result':a['default']['result'],
        'junit':totals(a['default']['junit']['surefire-reports']),
        'python_tests':int(a['default']['python_checks'][0][0]),
        'python_seconds':float(a['default']['python_checks'][0][1]), 'recorded_nonexpensive_goals':102},
    'full':{'run_id':a['full']['run_id'],'status':'FAILED','result':a['full']['result'],
        'junit':totals(a['full']['junit']['surefire-reports']),
        'oracle':a['full']['junit']['failsafe-reports'],
        'python_tests':int(a['full']['python_checks'][0][0]),
        'python_seconds':float(a['full']['python_checks'][0][1]),
        'required_oracle_methods':77,'required_oracle_suites':16,
        'oracle_methods_not_run':sum(map(len,missing.values())),'oracle_suites_not_run':missing,
        'target_runtime_receipt_status':e['qualification_target']['status'],
        'target_runtime_receipt_count':len(e['qualification_target']['receipts'])},
    'admission':read(next(BASE.glob('scoped-capacity-*.json'))),
    'cleanup':read(BASE/'cleanup-independent.json'), 'mutation':review,
    'gatling':e['gatling'], 'oracle_capacity':{k:v for k,v in work.items() if k!='phase_diagnostics'},
    'capacity_measurement_native_session_statistics':phases['measurement_work']['session_statistics'],
    'capacity_measurement_cursor_attribution':intervals(phases['measurement_work']),
    'capacity_seed_waits':phases['seed_work']['nonidle_session_waits'],
    'capacity_cleanup_ms':phases['cleanup_ms'],
    'comparison_failure':{k:v for k,v in failure.items() if k!='quota_sql_interval'},
    'oracle_scale':{'rows':scale['rows'],'ledger_claims':scale['ledger_claims'],
        'distributions':[{'distribution':x['distribution'],'samples':len(x['samples']),
                          'legacy_samples':len(x['legacy_samples'])} for x in scale['distributions']]},
    'standalone':read(BASE/'standalone-triggers.json'),
    'historical_cancellation':'FAILED','current_characterization':'NOT_RUN',
    'production_readiness':'NO_GO','prior_archives_unchanged':14,
    'product_or_tooling_source_changed':False}
(BASE/'execution-analysis.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'full_oracle':summary['full']['oracle']['tests'],
    'not_run_oracle':summary['full']['oracle_methods_not_run'],
    'receipt_status':summary['full']['target_runtime_receipt_status'],
    'capacity_cursor_attribution':summary['capacity_measurement_cursor_attribution'],
    'gatling_http_requests':sum(x['http']['requests']['total'] for x in e['gatling'].values()),
    'cleanup':summary['cleanup']['cleanup_verified']}))
