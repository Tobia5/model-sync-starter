"""Package only this completed session's nonsecret evidence; preserve prior archives."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1] / 'model-sync-starter'
DEST = ROOT / 'validation/qualification/2026-10-25-integrated-named-target-r2'
frozen = json.loads((BASE / 'frozen-source.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == frozen['source_sha']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True).strip()
for name, prior in frozen['prior_archives'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == prior['sha256'], name

inputs = {}
for prefix in ('default-', 'full-'):
    directory = next(path for path in BASE.glob(prefix + '*') if path.is_dir())
    result = json.loads((directory / 'result.json').read_text(encoding='utf-8'))
    assert 'collector_exit' in result, 'Cannot package an executing or uncollected attempt'
    assert result['source_sha'] == frozen['source_sha']
    for path in directory.rglob('*'):
        if path.is_file():
            inputs['attempts/' + path.relative_to(BASE).as_posix()] = path
for path in (BASE / 'source-contracts').rglob('*'):
    if path.is_file():
        inputs[path.relative_to(BASE).as_posix()] = path
fixed = ('frozen-source.json', 'source-contracts-manifest.json', 'admission.log',
         'admission-command.json', 'standalone-triggers.log', 'standalone-triggers.json',
         'seed-resource-observation.json', 'analysis-complete.json', 'cleanup-independent.json',
         'session.py', 'full_capacity.py', 'analyze.py', 'package.py', 'summarize.py',
         'execution-analysis.json', 'failure-analysis.json', 'mutation-review.json')
for name in fixed:
    path = BASE / name
    assert path.is_file(), name
    inputs['supervision/' + name] = path
for path in BASE.glob('scoped-capacity-*.json'):
    inputs['supervision/' + path.name] = path

# Bounded checks for the generated credential format and nonempty XML secret properties.
# Do not print matching values or pretend this is a universal secret audit.
hex_credential = re.compile(rb'(?<![0-9a-fA-F])[0-9a-fA-F]{48}(?![0-9a-fA-F])')
xml_property = re.compile(rb'<property\b[^>]*\bname=["\'][^"\']*(?:password|secret)[^"\']*["\'][^>]*\bvalue=["\']([^"\']*)["\']', re.I)
manifest = {}
for name, path in sorted(inputs.items()):
    content = path.read_bytes()
    assert not hex_credential.search(content), 'Generated credential pattern in ' + name
    assert all(not value.strip() for value in xml_property.findall(content)), 'Nonempty secret XML property in ' + name
    manifest[name] = {'sha256': hashlib.sha256(content).hexdigest(), 'bytes': len(content)}
payload = {'source_sha': frozen['source_sha'], 'source_tree': frozen['source_tree'],
           'files_sha256_and_size': manifest}
(BASE / 'package-manifest.json').write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')
DEST.mkdir(parents=True, exist_ok=False)
target = DEST / 'raw-evidence.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, path in sorted(inputs.items()):
        archive.write(path, name)
    archive.write(BASE / 'package-manifest.json', 'package-manifest.json')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(inputs) + 1
    for name, record in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == record['sha256'], name
receipt = {'source_sha': frozen['source_sha'], 'source_tree': frozen['source_tree'],
           'archive_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
           'bytes': target.stat().st_size, 'entries': len(inputs) + 1,
           'crc_verified': True, 'every_input_hash_verified': True,
           'bounded_nonsecret_checks_passed': True,
           'prior_archives_unchanged': len(frozen['prior_archives'])}
(DEST / 'package-verification.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2))
