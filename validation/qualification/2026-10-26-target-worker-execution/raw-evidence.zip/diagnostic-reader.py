from pathlib import Path
import json,sys
ROOT=Path.cwd();BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from run_evidence import current,fresh
from qualification_target import validate_projection, collect
run=current(ROOT);errors=[]
def load(name):
 p=ROOT/name;fresh(p,ROOT);d=json.loads(p.read_text(encoding='utf-8'))
 assert all(d.get(k)==run[k] for k in ('run_id','started_ns','source_sha','source_tree','source_change_digest')),name
 return d
projection=load('model-sync-sample/target/qm/oracle-target-projection.json')
try:validate_projection(projection)
except ValueError as error:errors.append(str(error))
matrix=load('model-sync-sample/target/qm/oracle-worker-diagnostic.json')
expected=['fresh-fixed','fresh-adaptive','statistics-fixed','statistics-adaptive']
assert [c['name'] for c in matrix['cells']]==expected
assert matrix['condition_ms']==20000 and matrix['measured_completions']==160
assert (matrix['workers'],matrix['pool'],matrix['persistence_threads'],matrix['owner_threads'])==(4,8,4,8)
hosts=collect(ROOT);roles={r['role'] for r in hosts['receipts']};assert {'starter-target','actual-worker'}<=roles
summary=[]
for c in matrix['cells']:
 assert c['status'] in ('PASS','FAILED'),c['name']
 trace=c['trace'];events=trace['events']
 assert trace['dropped']==0 and trace['unattributed_coordinator_calls']==0,c['name']
 assert 1<=len(events)<=40000 and all(isinstance(e.get('ns'),int) and -1<=e.get('lane',-2)<=3 for e in events)
 lanes={e['lane'] for e in events if e['event']=='coordinator-claim'};assert lanes=={0,1,2,3},(c['name'],lanes)
 assert c['pool_closed'] is True and c['physical_after_close']==0,c['name']
 summary.append({'name':c['name'],'status':c['status'],'events':len(events),'lanes':sorted(lanes),'pool_closed':c['pool_closed'],'remaining':c['after']['eligible_remaining']})
result={**run,'scope':'DIAGNOSTIC_ONLY','full_qualification':'NOT_RUN','collection_status':'COLLECTED_WITH_FAILURES' if matrix['status']=='FAILED' or errors else 'COLLECTED','projection_status':projection['status'],'runtime_receipt_roles':sorted(roles),'cells':summary,'errors':errors}
(BASE/'diagnostic-integrity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
if errors:raise SystemExit(1)
