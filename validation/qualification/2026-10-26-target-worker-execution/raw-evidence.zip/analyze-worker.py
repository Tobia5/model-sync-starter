import json,math,collections
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]/'model-sync-starter'
path=ROOT/'model-sync-sample/target/qm/oracle-worker-diagnostic.json'
report=json.loads(path.read_text(encoding='utf-8'))
def stats(values):
 v=sorted(values)
 if not v:return {'n':0}
 return {'n':len(v),'min':round(v[0],3),'p50':round(v[math.ceil(.5*len(v))-1],3),'p95':round(v[math.ceil(.95*len(v))-1],3),'p99':round(v[math.ceil(.99*len(v))-1],3),'max':round(v[-1],3)}
result={k:report[k] for k in ['source_sha','source_tree','source_change_digest','run_id','started_ns']}
result.update(scope='derived diagnostic observations only',full_qualification='NOT_RUN',percentiles='nearest rank; milliseconds unless specified',measurement_interval='phase.started_ns through started_ns+elapsed_ms*1e6; end reconstructed from rounded duration, <=1ms uncertainty',scheduler_wakeup_definition='schedule-hook creation to task invocation; includes intended timer delay, not pure scheduler lateness',cells=[])
for c in report['cells']:
 p=c['phases'][0];events=c['trace']['events'];start=p['started_ns'];end=start+p['elapsed_ms']*1000000
 measure=[e for e in events if start<=e['ns']<=end]
 rows=[]
 for lane in range(4):
  all_lane=[e for e in events if e['lane']==lane];lane_events=[e for e in measure if e['lane']==lane]
  claims=[e for e in lane_events if e['event']=='coordinator-claim']
  finish=[e for e in lane_events if e['event']=='coordinator-finish']
  reasons=collections.Counter();main_schedules=[e for e in lane_events if e['event']=='reservation-schedule']
  for e in main_schedules:reasons.update([e.get('reasons',{}).get('worker-main','HINT_NOT_RECORDED')])
  empty=collections.Counter()
  for claim in claims:
   if claim.get('present') is False:
    schedule=next((e for e in reversed(all_lane) if e['event']=='reservation-schedule' and claim['began_ns']<=e['began_ns']<=claim['ns']),None)
    empty.update([schedule.get('reasons',{}).get('worker-main','NO_SCHEDULE_REASON') if schedule else 'NO_SCHEDULE_EVENT'])
  after_productive=[]
  for f in finish:
   following=next((e for e in all_lane if e['event']=='coordinator-claim' and e['began_ns']>f['ns']),None)
   if following and following['began_ns']<=end:after_productive.append((following['began_ns']-f['ns'])/1e6-p['productive_interval_ms'])
  rows.append({'lane':lane,'claim_calls':len(claims),'claims_returned':sum(e.get('present') is True for e in claims),'empty_claims':sum(e.get('present') is False for e in claims),'finish_returns':sum(e.get('transaction_returned') is True and 'failure_type' not in e for e in finish),'claim_duration_ms':stats([e['duration_ns']/1e6 for e in claims]),'prepare_duration_ms':stats([e['duration_ns']/1e6 for e in lane_events if e['event']=='coordinator-prepare']),'tick_start_gap_ms':stats([(b['began_ns']-a['began_ns'])/1e6 for a,b in zip(claims,claims[1:])]),'wakeup_scheduled_to_invoked_ms':stats([(e['ns']-e['scheduled_ns'])/1e6 for e in lane_events if e['event']=='scheduler-wakeup']),'after_productive_delay_residual_ms':stats(after_productive),'main_schedule_reasons':dict(reasons),'empty_claim_main_reason':dict(empty)})
 # A reservation changes from a schedule token to its lease token at claimed().
 pending={};leases={};life=[];emptylife=[];missing=[]
 for e in sorted(events,key=lambda x:x['ns']):
  if e['event']=='reservation-schedule' and e.get('reasons',{}).get('worker-main')=='LOCALLY_RESERVED':
   slot=e['after']['worker-main'];pending[e['lane']]={'start_lower_ns':e['began_ns'],'start_upper_ns':e['ns'],'schedule_token':slot['token']}
  elif e['event']=='reservation-claimed':
   item=pending.pop(e['lane'],None)
   if item is not None:
    before=e['before']['worker-main'];after=e['after']['worker-main']
    if before.get('token')!=item['schedule_token']:missing.append('claimed_token_mismatch')
    elif after.get('occupied'):leases[after['token']]={**item,'lane':e['lane'],'lease_until_ms':after['until_ms']}
    else:emptylife.append((e['ns']-item['start_lower_ns'])/1e6)
  elif e['event']=='reservation-release':
   before=e['before']['worker-main'];after=e['after']['worker-main'];token=before.get('token');item=leases.pop(token,None)
   if item is not None:
    if after.get('token')==token:missing.append('release_token_remained')
    life.append({'lane':item['lane'],'released_ns':e['ns'],'min_ms':max(0,(e['began_ns']-item['start_upper_ns'])/1e6),'max_ms':(e['ns']-item['start_lower_ns'])/1e6,'headroom_ms_at_release':item['lease_until_ms']-e['clock_ms']})
 measured_life=[x for x in life if start<=x['released_ns']<=end]
 hints=[e['hint_ms']-e['clock_ms'] for e in measure if e['event']=='quota-nextAdmission' and e.get('group')=='worker-main' and e.get('present')]
 failed=[e for e in events if 'failure_type' in e]
 cell={'name':c['name'],'status':c['status'],'elapsed_ms':p['elapsed_ms'],'scheduling':p['scheduling_delta'],'native_session_delta':p['session_delta'],'session_attribution':p['session_attribution'],'remaining_eligible':c['after']['eligible_remaining'],'pool_active_after':c['after']['pool_active'],'pool_closed':c['pool_closed'],'shutdown':c['shutdown'],'physical_after_close':c['physical_after_close'],'lanes':rows,'trace_events':len(events),'measurement_trace_events':len(measure),'trace_dropped':c['trace']['dropped'],'unattributed_claims':c['trace']['unattributed_coordinator_calls'],'measured_hint_minus_observation_wall_ms':stats(hints),'measured_reservation_lifetime_lower_ms':stats([x['min_ms'] for x in measured_life]),'measured_reservation_lifetime_upper_ms':stats([x['max_ms'] for x in measured_life]),'all_reservation_lifetimes_count':len(life),'empty_main_reservation_lifetimes_ms':stats(emptylife),'reservation_tracking_errors':missing,'unreleased_lease_tokens':len(leases),'unresolved_schedule_tokens':len(pending),'trace_failure_events':len(failed),'first_tick_spread_ms':round((max(min(e['began_ns'] for e in measure if e['event']=='coordinator-claim' and e['lane']==lane) for lane in range(4))-min(e['began_ns'] for e in measure if e['event']=='coordinator-claim'))/1e6,3),'before_work_stats':next(s for s in c['before']['table_statistics'] if s['TABLE_NAME']=='MS_WORK'),'postproductive_residual_caution':'includes Reactor signal propagation, observer overhead and scheduling/dispatch; not a pure OS scheduler metric'}
 result['cells'].append(cell)
for c in result['cells']:
 p=next(x for x in report['cells'] if x['name']==c['name'])['phases'][0]
 assert sum(l['claim_calls'] for l in c['lanes'])==p['scheduling_delta']['ticks']
 assert sum(l['claims_returned'] for l in c['lanes'])==160
 assert sum(l['finish_returns'] for l in c['lanes'])==160
 assert sum(l['empty_claims'] for l in c['lanes'])==p['scheduling_delta']['empty']
 assert all(sum(l['empty_claim_main_reason'].values())==l['empty_claims'] for l in c['lanes'])
 assert c['measured_reservation_lifetime_upper_ms']['n']==160
 assert not c['reservation_tracking_errors'] and c['unreleased_lease_tokens']==c['unresolved_schedule_tokens']==0
 assert c['trace_dropped']==c['unattributed_claims']==c['trace_failure_events']==0
 assert c['remaining_eligible']==c['pool_active_after']==c['physical_after_close']==0
 assert c['pool_closed'] and c['shutdown']['status']=='DRAINED'
 c['attribution_assertions']='PASS'
(BASE/'worker-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for c in result['cells']:
 print(json.dumps({k:v for k,v in c.items() if k not in ['lanes','native_session_delta','shutdown','scheduling']}))
 print(json.dumps({'cell':c['name'],'lanes':[{'lane':l['lane'],'claims':l['claim_calls'],'claimed':l['claims_returned'],'finish':l['finish_returns'],'empty_reasons':l['empty_claim_main_reason'],'claim_ms':l['claim_duration_ms'],'prepare_ms':l['prepare_duration_ms'],'postproductive_residual_ms':l['after_productive_delay_residual_ms']} for l in c['lanes']]}))
