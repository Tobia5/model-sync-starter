import json,os,subprocess,sys,time,hashlib,shutil
from pathlib import Path
root=Path.cwd();base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1';ws=base/'execution-r3'
sys.path.insert(0,str(root/'scripts'));from run_evidence import identity
source=identity(root);assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
command=[sys.executable,'scripts/full-oracle-container.py','--consumer-diagnostic',str(ws)]
env=dict(os.environ,MODELSYNC_ORACLE_CONTAINER='EXPLICIT_DISPOSABLE',MODELSYNC_FULL_ENV_ACK='DISPOSABLE_NONPRODUCTION',MODELSYNC_MAVEN_SETTINGS='.mvn/qualification-central.settings.xml')
env['MAVEN_OPTS']=env.get('MAVEN_OPTS','')+' -Xmx512m -XX:MaxDirectMemorySize=128m'
record={**source,'command':command,'cwd':str(root),'started_ns':time.time_ns(),'maven_parent_heap_mib':512,'maven_parent_direct_mib':128,'full_status':'NOT_RUN'}
(base/'consumer-r2-supervision-start.json').write_text(json.dumps(record,indent=2))
observed=False
with (base/'consumer-r2-wrapper.log').open('w',encoding='utf-8') as log:
 process=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 while process.poll() is None:
  if not observed:
   for p in ws.glob('consumer-run-*.json'):
    data=json.loads(p.read_text());run=data['run_id']
    names=subprocess.run(['docker','ps','--filter','label=io.modelsync.qualification.attempt='+run,'--format','{{.Names}}'],capture_output=True,text=True,check=True).stdout.strip().splitlines()
    if len(names)==1:
     fmt='{"memory_bytes":{{.HostConfig.Memory}},"nano_cpus":{{.HostConfig.NanoCpus}},"bindings":{{json .HostConfig.PortBindings}},"mounts":{{json .Mounts}},"image":"{{.Config.Image}}"}'
     result=subprocess.run(['docker','inspect','--format',fmt,names[0]],capture_output=True,text=True,check=True)
     value=json.loads(result.stdout);value.update(attempt_id=run,container=names[0],observed_ns=time.time_ns())
     (base/'consumer-r2-runtime-resources.json').write_text(json.dumps(value,indent=2));observed=True
  time.sleep(3)
 code=process.wait()
record.update(original_wrapper_exit=code,ended_ns=time.time_ns(),source_after=identity(root))
infra=root/'target/qm/oracle-container.json'
if infra.exists():
 data=json.loads(infra.read_text());shutil.copy2(infra,base/'consumer-r2-infrastructure.json')
 cleanup={}
 for kind,name in [('container',data.get('container_name')),('volume',data.get('volume_name'))]:
  if not name:continue
  args=['docker','inspect',name] if kind=='container' else ['docker','volume','inspect',name]
  result=subprocess.run(args,capture_output=True,text=True)
  cleanup[kind]={'name':name,'inspection_exit':result.returncode,'absent':result.returncode==1 and 'no such' in result.stderr.lower()}
 record['independent_cleanup']=cleanup
 pids=[]
 for p in ws.glob('consumer-run-*.json'):
  for mode,value in json.loads(p.read_text()).get('modes',{}).items():
   pid=value.get('receipt',{}).get('pid')
   if pid:
    probe=subprocess.run(['powershell.exe','-NoProfile','-Command',f'if (Get-Process -Id {int(pid)} -ErrorAction SilentlyContinue) {{ exit 1 }} else {{ exit 0 }}'],capture_output=True,text=True)
    pids.append({'mode':mode,'pid':pid,'absent':probe.returncode==0})
 record['consumer_jvms']=pids
(base/'consumer-r2-supervision-result.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True);sys.exit(code)
