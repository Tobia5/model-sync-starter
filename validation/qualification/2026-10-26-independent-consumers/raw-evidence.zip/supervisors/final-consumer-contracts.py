﻿import json, subprocess, sys
from pathlib import Path
root=Path.cwd(); base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1'
sys.path.insert(0,str(root/'scripts')); from run_evidence import identity
commands=[['C:/Program Files/Git/bin/bash.exe','scripts/test-core.sh'],['C:/Program Files/Git/bin/bash.exe','scripts/test-triggers.sh'],[sys.executable,'scripts/check-default-log.py',str(base/'packaging-r5/build.log')]]
results=[]
for n,command in enumerate(commands):
 with (base/f'final-r5-contract-{n}.log').open('w') as log: code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'command':command,'exit':code})
(base/'final-r5-contracts.json').write_text(json.dumps({'source':identity(root),'checks':results},indent=2))
print(json.dumps(results)); sys.exit(max(r['exit'] for r in results))
