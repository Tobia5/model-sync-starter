﻿import hashlib,json,os,subprocess,sys,time,uuid,shutil
from pathlib import Path
root=Path.cwd(); base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1'
base.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(root/'scripts'))
from run_evidence import identity
source=identity(root); assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
(base/'source.json').write_text(json.dumps(source,indent=2))
archives={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'validation/qualification').rglob('raw-evidence.zip')}
(base/'preserved-baselines.json').write_text(json.dumps({'archives':archives,'qm_sha256':hashlib.sha256((root/'QM.md').read_bytes()).hexdigest()},indent=2))
repo=base/'m2'; repo.mkdir(); wrapper=str(root/'mvnw.cmd'); settings=str(root/'.mvn/qualification-central.settings.xml')
command=[wrapper,'-B','-ntp','-s',settings,'-Dmaven.repo.local='+str(repo),'-Plibrary-artifacts','clean','install']
record={'run_id':str(uuid.uuid4()),**source,'command':command,'cwd':str(root),'repository_initially_empty':True,'started_ns':time.time_ns(),'settings_sha256':hashlib.sha256(Path(settings).read_bytes()).hexdigest()}
(base/'packaging-start.json').write_text(json.dumps(record,indent=2))
with (base/'packaging.log').open('w',encoding='utf-8') as log:
 code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
record.update(exit=code,ended_ns=time.time_ns(),source_after=identity(root))
(base/'packaging-result.json').write_text(json.dumps(record,indent=2))
with (base/'packaging-collection.log').open('w',encoding='utf-8') as log:
 collection=subprocess.run([sys.executable,'scripts/qm-report.py','--default-command',subprocess.list2cmdline(command),'--default-exit',str(code),'--default-status','PASS' if code==0 else 'FAILED'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
record['collection_exit']=collection
for name in ['target/qm','model-sync-architecture-tests/target/surefire-reports']:
 if (root/name).exists():shutil.copytree(root/name,base/'packaging-raw'/name,dirs_exist_ok=True)
for p in root.glob('*/target/surefire-reports'):
 shutil.copytree(p,base/'packaging-raw'/p.relative_to(root),dirs_exist_ok=True)
(base/'packaging-result.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
sys.exit(code or collection)
