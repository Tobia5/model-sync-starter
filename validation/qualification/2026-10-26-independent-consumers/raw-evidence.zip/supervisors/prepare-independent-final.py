﻿import json,sys,subprocess
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import consumer_artifacts as c
base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1';workspace=base/'execution-r2';workspace.mkdir(exist_ok=False)
c.stage(root,workspace,base/'m2');code=c.prepare(root,workspace)
if code:raise SystemExit(code)
manifest=json.loads((workspace/'artifact-manifest.json').read_text());receipts=[]
for mode in c.MODES:
 command=[*c.maven(root,Path(manifest['consumers'][mode]['repository'])),'org.apache.maven.plugins:maven-dependency-plugin:3.8.1:get','-Dartifact=org.apache.maven.surefire:surefire-junit-platform:3.5.3']
 with (workspace/(mode+'-provider-resolution.log')).open('w',encoding='utf-8') as log:code=subprocess.run(command,cwd=workspace/mode,stdout=log,stderr=subprocess.STDOUT).returncode
 receipts.append({'mode':mode,'command':command,'exit':code});c.write(workspace/'provider-resolution.json',receipts)
 if code:raise SystemExit(code)
print('PASS independent compilation, dependency trees and explicit pinned JUnit provider resolution')
