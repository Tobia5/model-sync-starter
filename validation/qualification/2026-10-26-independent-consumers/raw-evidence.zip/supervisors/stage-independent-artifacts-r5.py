﻿import hashlib,json,subprocess,sys,time,uuid,shutil,os
from pathlib import Path
root=Path.cwd();base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1';out=base/'packaging-r5';out.mkdir(exist_ok=False)
sys.path.insert(0,str(root/'scripts'));from run_evidence import identity
source=identity(root);assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
command=[str(root/'mvnw.cmd'),'-B','-ntp','-s',str(root/'.mvn/qualification-central.settings.xml'),'-Dmaven.repo.local='+str(base/'m2'),'-Plibrary-artifacts','clean','install']
env=dict(os.environ,MODELSYNC_MAVEN_SETTINGS='.mvn/qualification-central.settings.xml')
env['MAVEN_OPTS']=env.get('MAVEN_OPTS','')+' -Dmaven.repo.local='+str(base/'m2')
record={'run_id':str(uuid.uuid4()),**source,'command':command,'started_ns':time.time_ns(),'cwd':str(root),'repository':'task-owned, initially empty at attempt 1; only this task populates it'}
with (out/'build.log').open('w',encoding='utf-8') as log:code=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
record.update(exit=code,ended_ns=time.time_ns(),source_after=identity(root));(out/'result.json').write_text(json.dumps(record,indent=2))
with (out/'collection.log').open('w',encoding='utf-8') as log:collect=subprocess.run([sys.executable,'scripts/qm-report.py','--default-command',subprocess.list2cmdline(command),'--default-exit',str(code),'--default-status','PASS' if code==0 else 'FAILED'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
record['collection_exit']=collect
record['nested_maven_repository']=str(base/'m2')
record['nested_maven_settings']=env['MODELSYNC_MAVEN_SETTINGS']
for p in [root/'target/qm',*root.glob('*/target/surefire-reports')]:
 if p.exists():shutil.copytree(p,out/'raw'/p.relative_to(root),dirs_exist_ok=True)
(out/'result.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));sys.exit(code or collect)

