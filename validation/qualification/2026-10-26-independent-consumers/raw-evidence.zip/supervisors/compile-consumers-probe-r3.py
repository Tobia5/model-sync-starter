﻿import sys,json,shutil
from pathlib import Path
root=Path.cwd(); sys.path.insert(0,str(root/'scripts')); import consumer_artifacts as c
base=root.parent/'qualification-evidence'/'independent-consumers-20261026-r1'
old=base/'execution-r1'; new=base/'compile-probe-r3'; new.mkdir(exist_ok=False)
manifest=json.loads((old/'artifact-manifest.json').read_text())
shutil.copytree(old/'staged',new/'staged')
for mode in c.MODES:
 project=new/mode
 shutil.copytree(root/'validation/consumers/common',project)
 shutil.copy2(root/'validation/consumers'/mode/'pom.xml',project/'pom.xml')
 shutil.copy2(root/'validation/consumers'/mode/'ConsumerController.java',project/'src/main/java/example/consumer/ConsumerController.java')
 manifest['consumers'][mode]['sources']=c.source_manifest(project)
 manifest['consumers'][mode]['prepare_exit']=None
from run_evidence import identity
manifest['template_probe_identity']=identity(root)
c.write(new/'artifact-manifest.json',manifest)
raise SystemExit(c.prepare(root,new))

