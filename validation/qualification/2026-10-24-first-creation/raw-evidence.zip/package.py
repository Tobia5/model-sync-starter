import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]/'model-sync-starter'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
SOURCE=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain').strip()
sys.path.insert(0,str(ROOT/'scripts'))
from creation_evidence import qualify
data=qualify(ROOT)
assert data['source_sha']==SOURCE
checks={}
for archive in BASE.glob('diagnostic-*/target/qm/oracle-container.json'):
    infra=json.loads(archive.read_text())
    for kind,key in (('container','container_name'),('volume','volume_name')):
        name=infra[key]
        command=['docker','inspect','--format','{{.Id}}',name] if kind=='container' else ['docker','volume','inspect','--format','{{.Name}}',name]
        result=subprocess.run(command,capture_output=True,text=True)
        assert result.returncode!=0 and ('no such object' in result.stderr.lower() or 'no such volume' in result.stderr.lower())
        checks[name]={'run_id':infra['run_id'],'source_sha':infra['source_sha'],'command':command,'exit':result.returncode,'stderr':result.stderr.strip(),'absent':True}
(BASE/'independent-cleanup-final.json').write_text(json.dumps(checks,indent=2)+'\n')
preservation={}
for name in git('ls-tree','-r','--name-only','b280af4','validation/qualification').decode().splitlines():
    if name.endswith('.zip'):
        digest=hashlib.sha256(git('show','b280af4:'+name)).hexdigest();assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest;preservation[name]=digest
for name in ('OracleIoIT.java','OracleCancellationDiagnostic.java','OracleNowaitDiagnostic.java','OracleLockPolicyIT.java','OracleQuotaContentionIT.java','OracleAtomicityIT.java'):
    path='model-sync-sample/src/test/java/io/modelsync/sample/'+name
    assert not git('diff','b280af4','--',path).strip();preservation[path]=hashlib.sha256(git('show','b280af4:'+path)).hexdigest()
def method(source,signature):
    start=source.index(signature);opening=source.index('{',start);depth=1;end=opening+1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}');end+=1
    return source[start:end]
for path,signatures in {
    'model-sync-persistence-jdbc/src/main/java/io/modelsync/jdbc/JdbcWorkStore.java':['private Optional<JdbcWorkRow> locked(', 'private Optional<JdbcWorkRow> select('],
    'model-sync-persistence-jdbc/src/main/java/io/modelsync/jdbc/JdbcQuotaGate.java':['public QuotaAdmission acquire(', 'public void cooldown(']}.items():
    before=git('show','b280af4:'+path).decode();after=git('show','HEAD:'+path).decode()
    for signature in signatures:
        assert method(before,signature)==method(after,signature);preservation[path+'#'+signature]=hashlib.sha256(method(before,signature).encode()).hexdigest()
(BASE/'baseline-preservation.json').write_text(json.dumps(preservation,indent=2)+'\n')
(BASE/'strict-first-creation.json').write_text(json.dumps({'status':'PASS','scope':'DIAGNOSTIC_ONLY','full':'NOT_RUN',**{k:data[k] for k in ('source_sha','source_tree','run_id','started_ns','source_change_digest')},'cases':len(data['cases'])},indent=2)+'\n')
attempts=[]
for manifest in sorted(BASE.glob('*/archive-manifest.json')):
    context=json.loads(manifest.read_text());result=json.loads((manifest.parent/'result.json').read_text())
    suites=[ET.parse(manifest.parent/name).getroot() for name in context['files_sha256'] if '/surefire-reports/TEST-' in name and name.endswith('.xml')]
    attempts.append({'directory':manifest.parent.name,'context':context,'result':result,'junit':{k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')},'xml_suites':len(suites)})
out=ROOT/'validation/qualification/2026-10-24-first-creation';out.mkdir(exist_ok=False)
(out/'execution-analysis.json').write_text(json.dumps({'source_sha':SOURCE,'source_tree':data['source_tree'],'attempts':attempts,'final_measurements':data,'cleanup':checks,'full':'NOT_RUN','production':'NO-GO','original_gate':'unchanged; no applicability waiver from INSERT evidence','provider_gap':'failed cooldown extension remains unpublished'},indent=2)+'\n',encoding='utf-8')
files=[p for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='packaging-receipt.json']
archive=out/'raw-evidence.zip';manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for file in sorted(files):
        name=file.relative_to(BASE).as_posix();raw=file.read_bytes()
        if file.suffix in {'.xml','.json','.log'}:assert not re.search(rb'(?<![0-9a-f])[0-9a-f]{48}(?![0-9a-f])',raw),'Possible generated credential:'+name
        if file.suffix=='.xml':
            for p in ET.fromstring(raw).findall('properties/property'):
                if 'password' in p.get('name','').lower():assert not p.get('value','')
        manifest[name]=hashlib.sha256(raw).hexdigest();z.writestr(name,raw)
    z.writestr('packaged-files-sha256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
receipt={'source_sha':SOURCE,'source_tree':data['source_tree'],'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(manifest)+1,'crc_and_input_bytes_verified':True,'bounded_secret_scan':'48-hex tokens / nonempty XML password values:0 findings; not a universal audit'}
(BASE/'packaging-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
