# First-creation scoped run evidence

Source cfcc53d9bb7a90e20bbd67f4255d8322c1fc0d99
Tree 1a900bb8845c912793fb5136118222a1fac84c8e
Diagnostic run 16a9d2a6-3581-4715-a9d5-895875d3e34e

Default run73cbe204-8173-4287-a77c-d294ff1623d8: PASS, exit0; 155 JUnit/33 XML suites,79 Python guards.

Diagnostic command: python scripts/full-oracle-container.py --creation-diagnostic
Preflight/launcher/wrapper exit0;12 JUnit tests passed, no failures/skips.
Six native INSERT refusals with A unresolved; two projection/state work-fence cases; four deliberately observed default waits. Default completion after A resolution is not cancellation evidence.

Full/PIT/Gatling/large seed: NOT_RUN. Original UPDATE failure/gate and failed-cooldown publication gap unchanged. Production NO-GO.

Raw run markers, SQL/session/transaction/pool observations and cleanup are in the archived JSON/logs. This Markdown was collected after execution on the same clean source; earlier default QM remains in its own immutable attempt archive.
