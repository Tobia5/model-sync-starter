# Model Sync quality evidence

Generated: 2026-10-25T23:04:16.181236+00:00
Source at report generation: `baa8d265f94bb38e7baee93c0dbb999d8e4afde6`; tree: `3f27d8290820022c4a07514b14113defc9ce3667`.
Evidence attribution: 9bb0a407-7bf4-43e4-ba50-eb7c0f6ef7ea.
Working tree dirty at report generation: false.
Environment: openjdk version "21.0.12.1" 2026-08-18 LTS; Apache Maven 3.9.9 (8e8579a9e76f7d015ee5ec7bfcdc97d260186937); Python 3.12.10.

## Commands and outcome

| Lane | Exact command | Exit | Status |
|---|---|---:|---|
| default | `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml clean verify` | 0 | PASS |
| full | `NOT_RUN` | NOT_RUN | NOT_RUN |

## Measured evidence

Surefire: 222 tests, 0 failures, 0 errors, 0 skipped across 41 XML files.
Failsafe: 0 tests, 0 failures, 0 errors, 0 skipped across 0 XML files.
Named configuration: oracle26-nowait-ledger-first-v1; NOT_RUN; never DEFAULT/all-configuration qualification.
Independent plain-UPDATE cancellation: {"applicability": "driver characterization; not mandatory for the named protected paths", "current_status": "NOT_RUN", "historical_capability": "FAILED", "historical_report": "43040e7", "historical_source": "2c39b75"}
PIT: NOT_RUN.
Gatling: NOT_RUN; no latency percentiles or completed-throughput measurement.
Oracle scale: NOT_RUN.
Oracle reconciliation workload: NOT_RUN.
Actual Reactor worker: NOT_RUN.

## Scope and blockers

A default PASS does not qualify full release behavior. Full requires Oracle migration/concurrency/scale/capacity and seven starter JPA/JDBC atomicity tests, actual claim plans/counters, selected PIT scope at 85% killed/generated, and all six Gatling reports. See `scripts/check-full-reports.py`.
The local Gatling harness uses an in-memory test store; its data is not Oracle capacity evidence.
No package publication or production deployment is authorized by this report.

- Host available memory10.951-11.004GiB below unchanged12GiB diagnostic admission; Docker/disk checks passed; no resource retry; target/worker Oracle diagnostic not launched; current full NOT_RUN.
