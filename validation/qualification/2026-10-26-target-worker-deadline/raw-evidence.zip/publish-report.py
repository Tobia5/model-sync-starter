﻿from pathlib import Path
import json,hashlib,zipfile,subprocess,re
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]/'model-sync-starter'
source='baa8d265f94bb38e7baee93c0dbb999d8e4afde6';tree='3f27d8290820022c4a07514b14113defc9ce3667';run='9bb0a407-7bf4-43e4-ba50-eb7c0f6ef7ea'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
destination=ROOT/'validation/qualification/2026-10-26-target-worker-deadline';destination.mkdir(exist_ok=False)
# No Oracle attempt was launched. The evidence seal contains default runs and the admission denial.
files=[p for p in BASE.rglob('*') if p.is_file() and not p.name.startswith('pr-') and p.name!='raw-archive-manifest.json']
pattern=re.compile(rb'(?<![0-9a-fA-F])[0-9a-fA-F]{48}(?![0-9a-fA-F])')
hits=[p.relative_to(BASE).as_posix() for p in files if pattern.search(p.read_bytes())]
assert not hits,'Credential-format review required; values not exported'
(BASE/'nonsecret-artifact-check.json').write_text(json.dumps({'generated_credential_format_matches':0,'scope':'bounded48-hex format check only; no Oracle credentials were generated','files_scanned':len(files)},indent=2)+'\n');files.append(BASE/'nonsecret-artifact-check.json')
manifest={'source_sha':source,'source_tree':tree,'matching_default_run':run,'oracle_run_id':None,'diagnostic_status':'BLOCKED','oracle_execution':'NOT_RUN','full':'NOT_RUN','files_sha256':{p.relative_to(BASE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}}
(BASE/'raw-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(BASE/'raw-archive-manifest.json')
archive=destination/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(BASE).as_posix())
digest=hashlib.sha256(archive.read_bytes()).hexdigest();(destination/'SHA256SUMS').write_text(digest+'  raw-evidence.zip\n')
summary=f'''# Target fixture repair and worker deadline diagnostic - 2026-10-26

**Default PASS. Focused Oracle admission BLOCKED. Current full NOT_RUN. Production NO-GO.**

Tested clean source **`{source}`**, tree **`{tree}`**,
branch `review/layered-refactor-qm-20261020`, repository `Tobia5/model-sync-starter`.
The later report-only commit is not claimed as tested source. Source7c1abe5,
reportb7f3cb5, the failed integrated run and all18 earlier archives are preserved.

## Executed checks and exact blocker

- `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml clean verify`:
  PASS, run `{run}`,222 JUnit tests/102 Python guards/41 XML reports,
  zero failures/errors/skips; build/qualification/execution-audit/collection exits0.
  Supervisor build runtime349.441s. The five virtual-time controls and27 semantic
  SQL matcher cases are included in222, not extra tests.
- Git Bash `scripts/test-triggers.sh`:86 core/43 trigger assertions, exit0;
  these are separate standalone assertions, not JUnit counts.
- After build and collection, `python capacity.py diagnostic` (archived helper):
  **BLOCKED, original Python exit2**. Host available10.985/11.004/10.951GiB,
  below unchanged12GiB. Docker19.349GiB available; C66.800/D1069.775GiB free;
  those checks passed. One bounded three-sample admission; no retry/resource change.
- `python scripts/full-oracle-container.py --target-worker-diagnostic`:
  **NOT_EXECUTED**. Wrapper, preflight Maven and JUnit launcher exits are null /
  NOT_RUN. Target fixture and all four runtime cells are NOT_RUN. No new Oracle
  run ID, generated credentials, container, volume or schema exists for this block.
- The blocked receipt has attribution NONE for Oracle. Separate collection of
  the actual matching default plus the admission blocker exited0; it retains
  default run attribution and full NOT_RUN. No leftover Oracle/PIT/Gatling report
  is attributed to this attempt.

JDK21.0.12.1, Maven3.9.9, Python3.12.10 and Docker29.8.2 were observed.
Boot4.1.1/JUnit6.0.3/Hibernate7.4.5.Final remain pinned/resolved by compilation.
Approved settings SHA256:
`ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.
The target remains `oracle26-nowait-ledger-first-v1`: point/quota/JPA NOWAIT,
Oracle26 INSERT NOWAIT, DURABLE extension1 and qualified ledger-first/JPA mapping.
Actual Oracle platform, policy/mapping/enlistment and migration receipts on this
source are **NOT_RUN**, not inferred from properties or earlier receipts.
The pinned image, Oracle6GiB/4CPU, small JVM512MiB/128MiB direct and full18GiB
admission remain unchanged. No full, scale, comparison, PIT or Gatling execution
occurred during this diagnosis.

## Implemented fixture correction (Oracle proof still pending)

The synthetic owner is controllable: A/validator A, then changed-B/validator B.
Both requests use the actual public gateway/coordinator. Independent observer
connections assert committed projection/state pairs, generations1/2, APPLIED/IDLE,
validator propagation and local revision increment. Capture resets before the
changed-existing-row phase and is bounded to256 statements of8192 characters;
phase/SQL/overflow/failure-type evidence is written even on assertion failure.

A test-only lexer recognizes the relevant projection SELECT with terminal
`FOR UPDATE [OF column-list] NOWAIT`. It rejects plain locks, WAIT, SKIP LOCKED,
unrelated statements and comment/literal-only matches, including literals used
as OF columns.27 parameterized cases passed. These SQL strings are unit fixtures;
**no new Hibernate-generated Oracle SQL was observed**. Full validation now also
requires the fresh, source/run-bound two-phase SQL proof. Production locking was
not changed to satisfy the fixture.

## Worker observations: measured versus unknown

The only production worker change tags existing lanes in Reactor context for
identity across scheduler hops; delays, reservations, quotas and cancellation
semantics are unchanged. A default test proves all four lane IDs survive real
persistence/owner scheduler hops. Oracle tracing is test-scoped and bounded:
40,000 events/cell, explicit overflow/unattributed counts, tick/claim/prepare/
finish and scheduler-wakeup times, reservation before/after snapshots, actual
hint/claim clocks, provider-filter/selector reasons and detached failure codes.
No entity-bearing exceptions, connections or credentials are retained in traces.

| Virtual-time control | Known hints | Owner ms | Completions at20s | Grants | Ticks | Late unapplied |
|---|---|---:|---:|---:|---:|---:|
| fixed250ms | yes |5|80|80|320|0|
| adaptive5ms | yes |5|160|160|365|0|
| fixed250ms | no |5|80|80|320|0|
| adaptive5ms | no |5|160|160|365|0|
| fixed250ms | no |0|81|81|324|0|

All use four synchronized lanes,160 offered items and authoritative20ms admission;
known-hint cases use real scheduling reservations and assert zero deferred
admission races. Unknown-hint controls are explicitly separate. These executable
counterexamples disprove a universal160/20s guarantee for fixed-delay mode. They
**do not establish the actual Oracle failure's cause**. Earlier7c1abe5 measured
84/160 completions remains a failed observation, not proof inferred from4.2/s.

The declared Oracle matrix is fresh-data/fresh-host fixed/adaptive and recorded-
statistics fixed/adaptive; all four are **NOT_RUN**. It retains four lanes,
pool8/persistence4/owner8 threads,160 completions and the20s condition. Each cell
executes independently, retaining failures. The history model sets only the
recorded MS_WORK estimates100000 rows/2260 blocks; it does not claim to reproduce
physical segment, index or cache history. Actual snapshots and residue observations
are implemented but unexecuted. No production scheduling correction is justified
yet; synchronization, reservation timing and predecessor-state effects remain
runtime hypotheses.

## Narrow criterion candidate - provisional, not adopted

For explicit review after the Oracle matrix: preserve the fixed250ms compatibility
behavior and its20s observation window as a measured control, recording completed
and still-durable work without claiming160/20s performance. Keep160/20s mandatory
for the configured adaptive worker. Preserve every concurrency, provider-admission,
idle/wakeup, atomicity, fencing, recovery, shutdown, mutation and load requirement.
This is a proposed change to one fixed-control throughput criterion, not an
implemented waiver. The current test and QM validator still require160/20s in
both productive phases. No deadline/resource increase or qualification selection
change was made. No full run is justified while this applicable gate is unresolved.

## Evidence and remaining work

Current full inventory is unchanged:83 methods/18 suites. None executed on this
source; the separately retained7c1abe5 full remains FAILED (81/83, target SQL proof
and fixed worker timeout). Historical cancellation remains FAILED/current
characterization NOT_RUN. Accepted NOWAIT/cooldown/accounting milestones remain
within their earlier measured scopes and are not reopened by these unit results.

Next concrete prerequisite: at least12GiB available host memory, with the same
Docker/disk checks and matching default, to launch the declared small matrix once.
No additional generic Docker approval is required within the existing scope.
Only after focused requirements are resolved, or the exact replacement criterion
is explicitly reviewed, may final clean-source full qualification proceed at18GiB.
Unrecorded responses, uncertain outcomes, receipt retention, security, operations
and all other incomplete parent release gates remain open. No merge, main change,
workflow bootstrap, package publication or unrelated-resource mutation occurred.

[Detailed evidence and all attempts](validation/qualification/2026-10-26-target-worker-deadline/README.md).
Raw archive SHA256: `{digest}`.
No owned Oracle resources were created, so no cleanup action or successful Oracle
drain is claimed. Earlier root QM content follows byte-for-byte.

---

'''
old=(ROOT/'QM.md').read_bytes();(ROOT/'QM.md').write_bytes(summary.encode('utf-8')+old)
readme=summary.replace('[Detailed evidence and all attempts](validation/qualification/2026-10-26-target-worker-deadline/README.md).','[Root QM](../../../QM.md).').replace('Earlier root QM content follows byte-for-byte.','The root QM retains the prior content byte-for-byte.')
readme+='''## Attempt inventory

| Source / attempt | Scope | Original exits | Outcome |
|---|---|---|---|
| Unsealed development1 | tests with static exec guards intentionally not selected |1|AsyncOwner builder compile error; no qualification claim|
| Unsealed development2 | same development command |1|CooldownRequest test-instrumentation package compile error|
| Unsealed development3 | same development command |0|Development Java tests passed; not clean default evidence|
| ef292db / default-7e379101 | clean default |build1, qualification1, audit0, collector0|102 Python guards/one cap-condition textual guard failed; no current JUnit marker|
| 2af72dc / default-58224e98 | clean default |all0|218 JUnit/102 Python PASS, run11d6415e-d76a-4c14-a531-dc0b9cd55734; no Oracle execution|
| baa8d26 / default-a6f7a27f | final clean default |all0|222 JUnit/102 Python PASS, run9bb0a407-7bf4-43e4-ba50-eb7c0f6ef7ea|
| baa8d26 / cd0117b8-f7fa-49cd-b50c-3d6fef693899 | small diagnostic admission |Python2|Host memory blocked; wrapper/Oracle NOT_RUN|
| baa8d26 / blocked-collection | actual default collection plus separate blocker |0|No new Oracle attribution; full NOT_RUN|

Development commands were `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml
-Dexec.skip=true -pl model-sync-sample -am test`. They did not select full or skip
JUnit, but did not run the static exec guards and are not normal/default qualification.
Their working trees were unsealed; no exact tested source identity is fabricated.
Later clean default runs bind the actual final code. A separate Python negative-test
setup failure was corrected to keep the same run marker while corrupting only the
projection proof; final102 guards passed. The ef292db cap guard was extended to
include the additional small mode, retaining512MiB/128MiB for every prior mode.
No cancellation reproducer/assertion/applicability was changed.

## Archive contents and integrity

- `source-commits.txt`, `review-changes.patch`, `frozen-source-end.json`: exact final source/tree, clean state and proposed review changes; intermediate commits are not claimed Oracle-tested.
- `default-*/`: raw Maven logs, original result JSON, separate audit/qualification/collector outputs and fresh report hashes. The marker-less failed source is explicitly unqualified.
- `diagnostic-blocked.json`, `capacity-command.json/log`, `scoped-capacity-*.json`: original bounded admission, Python exit2, all five selected Oracle methods/cells NOT_RUN, no generated infrastructure and no invented runtime identity.
- `blocked-admission/QM.md`, `evidence.json`, `raw-manifest.json`: actual run-scoped default evidence with the separate blocker, not a failed/unexecuted Oracle report.
- `standalone-contracts.*`:86/43 assertion result, exit0, separate from JUnit.
- `session.py`, `capacity.py`, `diagnostic-reader.py`: exact local orchestration/collection. The reader was prepared but NOT_RUN because no Oracle reports exist.
- `preservation.json`: hashes of all18 earlier archives and b7f3cb5 root-QM git content. The historical unclassified55 and previous failures are untouched.
- `raw-archive-manifest.json` and `SHA256SUMS`: entry and archive seals. The credential-format scan has zero matches; it is a bounded check, not a general secret detector.

The target fixture and independent four-cell diagnostic are executable through the
new explicit CLI only; the ordinary build compiles these classes without Oracle.
Full selection remains additive/manual with the original83 methods and all PIT/
Gatling gates. The proposed criterion is not reflected in test selection or green
qualification. There is no current Oracle SQL/plan/wait/cleanup result to substitute
with earlier reports. Expected SQL examples and virtual-time controls are labelled
as such. Release qualification remains incomplete.
'''
(destination/'README.md').write_text(readme,encoding='utf-8')
append='''
## 2026-10-26 recorded result and unadopted criterion candidate

Sourcebaa8d26/tree3f27d829 passed default222 JUnit/102 Python. Known-hint virtual
controls measured80 fixed versus160 adaptive completions in20s; this is a
counterexample to a universal fixed-mode guarantee, not an actual Oracle cause.
The Oracle matrix was NOT_RUN: resource admissioncd0117b8 measured10.951-11.004GiB
versus unchanged12GiB. Docker/disk passed. No resource retry or wrapper launch.

Candidate for explicit review after runtime measurement: fixed250ms remains a
measured20s compatibility control; configured adaptive retains160/20s. All other
requirements remain. This candidate is **not adopted**. OracleWorkerIT and the
full report validator still enforce160/20s for both modes. No full execution may
be substituted with these controls. Actual SQL, per-lane Oracle observations,
predecessor state and cleanup are still NOT_RUN. [Current QM](../../QM.md).
'''
p=ROOT/'docs/quality/TARGET-WORKER-DIAGNOSTIC.md';p.write_bytes(p.read_bytes()+append.encode('utf-8'))
latest='''## Latest target/worker work - 2026-10-26

Sourcebaa8d26/tree3f27d829 passed matching default222 JUnit/102 Python, all exits0.
The A/B target fixture, semantic lock matcher and bounded independent worker
matrix are implemented; actual Oracle proof is NOT_RUN. Small admission BLOCKED
at10.951-11.004GiB host available versus12GiB, with Docker/disk PASS. No wrapper,
container or schema was created. Known-hint virtual controls measured80 fixed /
160 adaptive completions at20s; the actual Oracle cause remains unqualified.
The original20s gate is unchanged; a narrow criterion candidate is unadopted.
[QM]({qm}) / [raw attempts]({raw}). Historical7c1abe5 full remains FAILED;
current full NOT_RUN, production NO-GO. Earlier sections below are historical.

'''
for name,qm,raw in [('docs/PRODUCTION-READINESS.md','../QM.md','../validation/qualification/2026-10-26-target-worker-deadline/README.md'),('docs/USER-HANDBOOK.md','../QM.md','../validation/qualification/2026-10-26-target-worker-deadline/README.md')]:
 p=ROOT/name;p.write_bytes(latest.format(qm=qm,raw=raw).encode('utf-8')+p.read_bytes())
p=ROOT/'TODO.md';prefix='''## Target fixture / worker follow-up - 2026-10-26

- [x] Implement A/validatorA then changed-B/validatorB through actual gateway/coordinator, fresh committed pair/revision checks, bounded failure-safe SQL proof and semantic FOR UPDATE [OF columns] NOWAIT matcher. Sourcebaa8d26 default222 JUnit/102 Python PASS; actual Oracle proof remains open.
- [x] Implement independent four-cell worker probe with bounded per-lane context across real scheduler hops, reservation/hint/claim/prepare clocks and reasons, committed/eligible work and owned-resource checks. Known-hint deterministic controls measure80 fixed/160 adaptive at20s. No production pacing correction or runtime cause is claimed.
- [ ] Run target fixture and all four cells after matching default and the existing12GiB admission. Attemptcd0117b8 BLOCKED at10.951-11.004GiB; Docker/disk PASS, no wrapper/resource creation or retry. [QM](QM.md) / [raw attempts](validation/qualification/2026-10-26-target-worker-deadline/README.md).
- [ ] Resolve the Oracle worker cause or explicitly review the narrow fixed-control criterion candidate after runtime evidence. Current160/20s requirements and all83 Oracle methods remain unchanged; current full NOT_RUN, historical full FAILED and production NO-GO. No parent gate is closed by this source/default milestone.

''';p.write_bytes(prefix.encode('utf-8')+p.read_bytes())
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':len(files),'sha256':digest,'qm_prefix_bytes':len(summary.encode('utf-8')),'source':source,'diagnostic':'BLOCKED','full':'NOT_RUN'}))
