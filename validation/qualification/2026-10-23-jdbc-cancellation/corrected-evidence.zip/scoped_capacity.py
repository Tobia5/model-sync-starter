import json,subprocess,time,sys,uuid,re
from pathlib import Path
from datetime import datetime,timezone
base=Path(__file__).resolve().parent
root=base.parents[1]/'model-sync-starter'
sys.path.insert(0,str(root/'scripts'))
from run_evidence import identity
record={**identity(root),'attempt_id':str(uuid.uuid4()),'observed_utc':datetime.now(timezone.utc).isoformat(),'scope':'six one-row locked-DML probes only','oracle_budget_gib':6,'diagnostic_runtime_budget_gib':2,'reserve_gib':4,'required_host_available_gib':12,'full_pipeline_required_host_available_gib':18,'jvm_heap_mib':512,'jvm_direct_mib':128,'no_pit_gatling_large_seed':True,'oracle_cpu_cap':4,'resource_change':'no cap increase, unrelated resource or global setting change','samples':[]}
for attempt in range(3):
    sample=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',"$m=Get-CimInstance Win32_OperatingSystem; [ordered]@{observed_utc=(Get-Date).ToUniversalTime().ToString('o');host_available_gib=[math]::Round($m.FreePhysicalMemory/1MB,3)} | ConvertTo-Json -Compress"],text=True))
    record['samples'].append(sample)
    if attempt<2:time.sleep(3)
record['docker']=json.loads(subprocess.check_output(['docker','info','--format','{"server":"{{.ServerVersion}}","cpu":{{.NCPU}},"memory_bytes":{{.MemTotal}},"running_containers":{{.ContainersRunning}}}'],text=True))
stats=subprocess.check_output(['docker','stats','--no-stream','--format','{{.MemUsage}}'],text=True,timeout=20).strip().splitlines()
units={'B':1,'kB':1000,'KB':1000,'KiB':1024,'MB':1000**2,'MiB':1024**2,'GB':1000**3,'GiB':1024**3}
def amount(value):
    m=re.fullmatch(r'([0-9.]+)\s*([A-Za-z]+)',value.strip())
    assert m and m[2] in units,value
    return float(m[1])*units[m[2]]
used=sum(amount(v.partition('/')[0]) for v in stats)
record['docker']['observed_container_memory_gib']=round(used/1024**3,3)
record['docker']['unallocated_container_capacity_gib']=round((record['docker']['memory_bytes']-used)/1024**3,3)
record['disk_free_gib']=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',"Get-PSDrive -Name C,D | ForEach-Object { [ordered]@{drive=$_.Name;free_gib=[math]::Round($_.Free/1GB,3)} } | ConvertTo-Json -Compress"],text=True))
record['status']='PASS' if min(s['host_available_gib'] for s in record['samples'])>=12 and record['docker']['unallocated_container_capacity_gib']>=6 and min(d['free_gib'] for d in record['disk_free_gib'])>=20 else 'BLOCKED'
record['exit']=0 if record['status']=='PASS' else 2
with (base/('scoped-capacity-'+record['source_sha'][:7]+'.json')).open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record),flush=True)
sys.exit(record['exit'])
