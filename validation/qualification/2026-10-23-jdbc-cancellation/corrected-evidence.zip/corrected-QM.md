# Focused JDBC diagnostic ? 31f8e5ee-aa5f-4ec3-920d-4b952f90c089

Source `2c39b759cd9295c35eeddf6587094816950ccdf3`, tree `03f1aa3e069863207151b28f2389f899f089e7fb`, clean change digest `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

Default PASS: `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml clean verify`, exit0/113.698s, run `2ceaca58-96aa-4e1b-984d-5be4869b1d84`;121 JUnit/26 suites,64 Python, zero failures/errors/skips;collector0.

Explicit diagnostic: `python scripts/full-oracle-container.py --cancellation-diagnostic`; preflight `-Pfull -N initialize`0, launcher/wrapper/supervisor0;175.557s;6/6 JUnit evidence checks passed,0 failed/skipped. This is **DIAGNOSTIC_ONLY**. **Independent cancellation FAILED; full NOT_RUN; production NO-GO.**

| Operation | Direct JDBC client exit | Spring/Hikari client exit |
|---|---|---|
| A query2s/read10s/observe5s |10007ms, FAILED |10013ms, FAILED |
| B same + cancel once |10017ms;cancel0ms |10008ms;cancel0ms |
| C same + network3s |3007ms, client I/O bound |3016ms, client I/O bound |

All six produced recoverable18730/socket-timeout and disposed connections. Oracle's exact SID/serial remained ACTIVE/WAITING on the row lock after client exit in6/6. The wait was no longer observed4?9ms after the fixture released the blocker: this is release-assisted cleanup, not cancellation or independent server-exit proof. Fresh committed row stayed `before` in6/6; subsequent healthy-connection update/commit succeeded in6/6. All owned executors/pools closed;table removed. Independent Docker absence receipt verifies `msq-f6dafe3a2248` and `msq-f6dafe3a2248-data` removed. No emergency unlock earned credit.

Pinned JDK21.0.12.1+1-LTS, Boot4.1.1, Spring JDBC7.0.9, Hikari7.0.2, ojdbc11/Oracle Free23.26.3.0.0;in-band cancellation unchanged. JVM512MiB heap/128MiB direct;Oracle6GiB/4CPU. Scoped planning12GiB (6+2+4), full18GiB unchanged. Generated runtime/migration schemas and loopback-only ports. Central settings SHA256 `ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.

Exact root cause in driver/server/forwarding remains unknown; direct reproduction excludes Spring/Hikari as necessary. Network timeout demonstrates client containment, not bounded server termination. The original failing gate remains unchanged. Contract draft is unapproved/unimplemented; no full rerun, merge, main change or publication.
