import hashlib, json, os, shutil
from pathlib import Path

base = Path(__file__).resolve().parent
source = {'source_sha': 'fad6874c9fa0e0a16ed7d542cace11ea89a991e1',
          'source_tree': 'a530a260738510da84ed7f68fd26a8a75b803d67'}
offline = base / 'offline-final-fad6874.log'
(base / 'offline-final-fad6874.json').write_text(json.dumps({**source, 'command': 'bash scripts/test-triggers.sh',
    'exit': 0, 'scope': 'OFFLINE_ASSERTIONS_NOT_JUNIT', 'core_assertions': 86, 'trigger_assertions': 43,
    'log_sha256': hashlib.sha256(offline.read_bytes()).hexdigest()}, indent=2) + '\n')
folder = base / 'development-unattributed'
folder.mkdir(exist_ok=False)
files = {}
for name in ('modelsync-worker-focused.log', 'modelsync-worker-development-default.log'):
    path = Path(os.environ['TEMP']) / name
    if path.is_file():
        shutil.copy2(path, folder / name)
        files[name] = hashlib.sha256(path.read_bytes()).hexdigest()
(folder / 'archive-manifest.json').write_text(json.dumps({'run_id': None,
    'scope': 'UNATTRIBUTED_DEVELOPMENT_LOGS', 'qualification': 'NOT_QUALIFICATION',
    'reason': 'CLI quoting error before tests; dirty development StepVerifier fixture failure/source changed during run',
    'source_sha': None, 'source_tree': None, 'command_exit': 1, 'files_sha256': files}, indent=2) + '\n')
blocked = base / 'diagnostic-2e3c177c-bcb0-49d8-a85c-3074f8f7badb'
(blocked / 'review-annotation.json').write_text(json.dumps({'scope': 'REVIEW_ANNOTATION_NOT_NEW_EXECUTION',
    'wrapper_exit': 2, 'observed_supervisor_exit': 1, 'qualification': 'BLOCKED', 'required_suites': 'NOT_RUN',
    'reason': 'Cp1252 default log was decoded as UTF8 before container provisioning; wrapper invalidated marker. Original supervisor then raised missing-marker error. Original result/log/infra retained.',
    'earlier_success_not_attributed': True}, indent=2) + '\n')
print('Extra failure/offline evidence retained; no test-count substitution')
