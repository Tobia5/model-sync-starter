import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

directory = Path(sys.argv[1]).resolve()
observation = json.loads((directory / 'infrastructure-observation.json').read_text())
name = observation['container']
expected = observation['labels']['io.modelsync.qualification.attempt']
actual = subprocess.check_output(['docker', 'inspect', '--format',
    '{{index .Config.Labels "io.modelsync.qualification.attempt"}}', name], text=True).strip()
assert actual == expected and name.startswith('msq-')
sql = """set pagesize 0 feedback off heading off linesize 200
select name || '=' || value from v$parameter where name in
('cpu_count','sga_target','pga_aggregate_target','db_writer_processes') order by name;
select 'redo_group=' || group# || ',bytes=' || bytes from v$log order by group#;
exit
"""
result = subprocess.run(['docker', 'exec', '-i', name, 'sqlplus', '-s', '/', 'as', 'sysdba'],
    input=sql, capture_output=True, text=True, timeout=20)
assert len(result.stdout) < 4000 and len(result.stderr) < 1000
record = {'utc': datetime.now(timezone.utc).isoformat(), 'attempt_id': expected,
    'scope': 'owned-container nonsecret resource settings; SYS excluded from runtime counters',
    'exit': result.returncode, 'output': result.stdout.strip(), 'stderr': result.stderr.strip()}
(directory / 'database-resources.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
assert result.returncode == 0 and 'ORA-' not in result.stdout
