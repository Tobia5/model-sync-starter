import hashlib, json
from pathlib import Path

base = Path(__file__).resolve().parent
directory = base / 'ci-default-39682007724'
context = json.loads((directory / 'target/qm/run-context.json').read_text())
evidence = json.loads((directory / 'target/qm/evidence.json').read_text())
raw = json.loads((directory / 'target/qm/raw-manifest.json').read_text())
assert context['source_sha'] == '33e114c25bd42eeaaa0214c6b34d294259955739'
assert context['source_tree'] == 'a530a260738510da84ed7f68fd26a8a75b803d67'
assert evidence['runs']['default']['status'] == 'PASS' and evidence['runs']['default']['exit'] == 0
assert evidence['evidence']['attribution'] == context['run_id'] == raw['run_id']
for name, digest in raw['files_sha256'].items():
    assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == digest
counts = {key: sum(module['surefire'].get(key, 0) for module in evidence['evidence']['modules'].values())
          for key in ('tests','errors','failures','skipped')}
assert counts == dict(tests=111, errors=0, failures=0, skipped=0)
files = {p.relative_to(directory).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in directory.rglob('*') if p.is_file() and p.name != 'archive-manifest.json'}
record = {**context, 'scope': 'default-ci', 'qualification': 'DEFAULT_ONLY', 'status': 'PASS',
    'run_url': 'https://github.com/Tobia5/model-sync-starter/actions/runs/39682007724',
    'github_artifact_id': 12385410076, 'branch_source_sha': 'fad6874c9fa0e0a16ed7d542cace11ea89a991e1',
    'merge_tree_equals_branch_source': True, 'junit': counts, 'files_sha256': files}
path = directory / 'archive-manifest.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'files_sha256'}))
