"""Derive only labelled phase/session observations; never sum ambiguous cursor counters."""
import collections, json
from pathlib import Path
import sys

directory = Path(sys.argv[1]).resolve()
context = json.loads((directory / 'target/qm/run-context.json').read_text())
scale = directory / 'model-sync-persistence-jdbc/target/qm/oracle-scale.json'
phases = directory / 'model-sync-persistence-jdbc/target/qm/oracle-workload-phases.json'
comparison = directory / 'model-sync-persistence-jdbc/target/qm/oracle-optimization.json'
worker = directory / 'model-sync-sample/target/qm/oracle-worker.json'
result = {**context, 'scope': 'DERIVED_REVIEW_SUMMARY_NOT_NEW_EXECUTION',
          'cursor_scope': 'selected OracleMeasurements statement families; interval record counts are not all SQL or worker execution totals',
          'worker': [], 'cursor_windows': []}

def interval(label, value):
    if not isinstance(value, dict) or 'cursor_intervals' not in value: return
    counts = collections.Counter(i['attribution'] for i in value['cursor_intervals'])
    reasons = collections.Counter(i['reason'] for i in value['cursor_intervals'] if i['attribution'] == 'UNATTRIBUTABLE')
    for row in value['cursor_intervals']:
        if row['attribution'] == 'UNATTRIBUTABLE':
            assert row.get('window_executions') is None and row.get('counter_deltas') is None
        else:
            assert row['window_executions'] >= 0 and row.get('before') is not None and row.get('after') is not None
    result['cursor_windows'].append({'label': label, 'interval_records': dict(counts),
        'unattributable_reasons': dict(reasons),
        'definition': 'per-child interval records, including valid zero deltas; not distinct cursors, callbacks, or complete execution totals'})

if scale.exists():
    data = json.loads(scale.read_text())
    for distribution in data.get('distributions', []):
        for lane in ('samples', 'legacy_samples'):
            for number, sample in enumerate(distribution[lane]):
                interval('scale/' + distribution['distribution'] + '/' + lane + '/' + str(number), sample['claim_work'])
if phases.exists():
    data = json.loads(phases.read_text())
    for name in ('seed_work', 'warmup_work', 'measurement_work', 'cleanup_work'):
        interval('million/' + name, data[name])
if comparison.exists():
    data = json.loads(comparison.read_text())
    for case in data['results']:
        interval('comparison/' + str(case['round']) + '/' + case['variant'], case['measurement_work'])
if worker.exists():
    data = json.loads(worker.read_text())
    for phase in data['phases']:
        counts = phase['scheduling_delta']; native = phase['session_delta']
        result['worker'].append({
            'phase': phase['name'], 'status': phase['status'], 'elapsed_ms': phase['elapsed_ms'],
            'scheduling': counts, 'native_session': native, 'session_attribution': phase['session_attribution'],
            'polls_per_second': phase['polls_per_second'], 'logical_gets_per_second': phase['logical_gets_per_second'],
            'completed_per_second': phase['completed_syncs_per_second'],
            **{k: v for k, v in phase.items() if 'wakeup' in k or k.endswith('_interval_ms')}})
result['cursor_classification_counts'] = dict(sum((collections.Counter(w['interval_records'])
    for w in result['cursor_windows']), collections.Counter()))
result['cursor_reason_counts'] = dict(sum((collections.Counter(w['unattributable_reasons'])
    for w in result['cursor_windows']), collections.Counter()))
out = directory / 'reviewed-summary.json'
assert not out.exists()
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'source_sha': context['source_sha'], 'run_id': context['run_id'],
                  'worker_phases': len(result['worker']), 'cursor_windows': len(result['cursor_windows']),
                  'cursor_interval_records': result['cursor_classification_counts']}))
