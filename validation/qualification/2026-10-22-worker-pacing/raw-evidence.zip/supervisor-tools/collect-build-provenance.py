﻿"""Collect configuration/build hashes only after successful source-bound full reporting."""
import argparse,hashlib,json,pathlib,shutil,sys,xml.etree.ElementTree as ET
base=pathlib.Path(__file__).resolve().parent; root=base.parents[1]/'model-sync-starter'
sys.path.insert(0,str(root/'scripts'))
from run_evidence import current, fresh, reactor_modules
parser=argparse.ArgumentParser(); parser.add_argument('--run-id',required=True); args=parser.parse_args()
ctx=current(root); assert ctx['run_id']==args.run_id
report=json.loads((root/'target/qm/evidence.json').read_text(encoding='utf-8'))
infra=json.loads((root/'target/qm/oracle-container.json').read_text(encoding='utf-8'))
assert report['runs']['full']['status']=='PASS' and report['runs']['full']['exit']==0
assert report['evidence']['attribution']==ctx['run_id'] and infra['run_id']==ctx['run_id']
assert infra['maven_exit']==0 and infra['wrapper_exit']==0 and infra['cleanup_verified'] is True
launch=json.loads((base/(ctx['source_sha'][:7]+'-full-launch.json')).read_text(encoding='utf-8'))
assert launch['source_sha']==ctx['source_sha'] and launch['source_tree']==ctx['source_tree']
ns={'m':'http://maven.apache.org/POM/4.0.0'}; version=ET.parse(root/'pom.xml').find('m:version',ns).text
out=base/('build-provenance-'+ctx['run_id']); out.mkdir(exist_ok=False)
files={}; sources={}
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(source,destination):
    assert source.resolve().is_relative_to(root.resolve())
    target=out/destination; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,target)
    files[destination]=digest(target)
for name in ['pom.xml','mvnw','mvnw.cmd','.mvn/wrapper/maven-wrapper.properties','.mvn/qualification-central.settings.xml','.github/workflows/model-sync-verify.yml','.github/workflows/model-sync-full-verify.yml']:
    source=root/name; copy(source,'source/'+name); sources[name]=digest(source)
for module in reactor_modules(root,True):
    name=module.relative_to(root).as_posix()+'/pom.xml'; copy(module/'pom.xml','source/'+name); sources[name]=digest(module/'pom.xml')
for folder in [root/'scripts',root/'model-sync-persistence-jdbc/src/main/resources/model-sync/schema',root/'model-sync-persistence-jdbc/src/main/resources/model-sync/migration']:
    for source in sorted(folder.glob('*')):
        if source.suffix in ('.py','.sql'):
            name=source.relative_to(root).as_posix(); copy(source,'source/'+name); sources[name]=digest(source)
assert digest(root/'.mvn/qualification-central.settings.xml')==infra['maven_settings_sha256']
effective={}
for name in ('effective-default.xml','effective-full.xml','effective-full-sample.xml'):
    source=root/'target/qm'/name
    assert source.stat().st_mtime_ns>=launch['supervisor_launch_ns'],name
    copy(source,'effective/'+name)
    effective[name]={'sha256':digest(source),'mtime_ns':source.stat().st_mtime_ns,'scope':'validate-phase configuration output after supervisor launch; may precede JUnit run marker, not a test report'}
excluded={'model-sync-testkit','model-sync-sample','model-sync-architecture-tests','model-sync-performance'}
outputs={}
for module in reactor_modules(root,True):
    if module.name in excluded: continue
    artifact=ET.parse(module/'pom.xml').find('m:artifactId',ns).text
    jar=module/'target'/(artifact+'-'+version+'.jar'); fresh(jar,root)
    outputs[jar.relative_to(root).as_posix()]={'sha256':digest(jar),'bytes':jar.stat().st_size}
assert len(outputs)==11
jars=set(); runtime={}
for module in reactor_modules(root,True):
    for runner in ('surefire-reports','failsafe-reports'):
        for xml in (module/'target'/runner).glob('TEST-*.xml'):
            fresh(xml,root); props={p.get('name'):p.get('value') for p in ET.parse(xml).getroot().findall('properties/property')}
            for key in ('java.runtime.version','java.vendor','os.name','os.arch'):
                if key in props: runtime.setdefault(key,set()).add(props[key])
            for item in props.get('java.class.path','').split(';'):
                name=pathlib.Path(item).name
                if name.endswith('.jar') and name.startswith(('spring-boot-','spring-core-','hibernate-core-','junit-jupiter-','junit-platform-','archunit-','ojdbc11-','h2-','reactor-core-')): jars.add(name)
metadata={**ctx,'scope':'BUILD_CONFIGURATION_AND_ARTIFACT_HASHES_NOT_NEW_TEST_EXECUTION','environment':report['environment'],'runtime_properties':{k:sorted(v) for k,v in runtime.items()},'resolved_test_classpath_artifacts':sorted(jars),'source_configuration_sha256':sources,'effective_poms':effective,'library_build_outputs':outputs,'binary_policy':'Hashes only; no JARs copied/published; testkit/demo/architecture/performance artifacts excluded'}
(out/'provenance.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8'); files['provenance.json']=digest(out/'provenance.json')
manifest={**ctx,'scope':'build-provenance','qualification':'CONFIGURATION_NOT_TEST_EXECUTION','status':'OBSERVED','files_sha256':files}
(out/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'folder':out.name,'configuration_files':len(files),'library_build_hashes':len(outputs),'source_sha':ctx['source_sha'],'run_id':ctx['run_id']}))
