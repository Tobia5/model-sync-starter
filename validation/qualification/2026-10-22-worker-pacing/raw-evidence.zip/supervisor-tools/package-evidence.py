"""Publish reviewed, hash-bound reports only; no JARs or release operation."""
import argparse, hashlib, io, json, re, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
root = base.parents[1] / 'model-sync-starter'
parser = argparse.ArgumentParser()
parser.add_argument('--full-directory', required=True)
parser.add_argument('--output', required=True)
args = parser.parse_args()
full = Path(args.full_directory).resolve()
context = json.loads((full / 'target/qm/run-context.json').read_text())
result = json.loads((full / 'result.json').read_text())
qm = json.loads((full / 'target/qm/evidence.json').read_text())
infra = json.loads((full / 'target/qm/oracle-container.json').read_text())
assert result['exit'] == result['collector_exit'] == 0
assert qm['runs']['full']['status'] == 'PASS' and qm['runs']['full']['exit'] == 0
assert qm['evidence']['attribution'] == infra['run_id'] == context['run_id']
assert infra['cleanup_verified'] is True and infra['maven_exit'] == infra['wrapper_exit'] == 0
out = Path(args.output).resolve()
assert out.is_relative_to(base) and not out.exists()
files = {}; records = []

def digest(raw): return hashlib.sha256(raw).hexdigest()
def add(name, path):
    assert not path.name.lower().endswith(('.jar', '.class')), path
    assert name not in files, name
    files[name] = path.read_bytes()

def component(directory, prefix=None):
    manifest = json.loads((directory / 'archive-manifest.json').read_text())
    for name, expected in manifest['files_sha256'].items():
        path = (directory / name).resolve()
        assert path.is_relative_to(directory.resolve()) and digest(path.read_bytes()) == expected, path
    name = prefix or directory.name
    records.append({'component': name, **{k: v for k, v in manifest.items() if k != 'files_sha256'}})
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('attempts/' + name + '/' + path.relative_to(directory).as_posix(), path)

for manifest in sorted(base.glob('*/archive-manifest.json')):
    component(manifest.parent)
for name, prefix in [
    ('default-21a37d92-2a4d-4466-8a95-a2d1767564a3', 'initial-head-default'),
    ('default-2369841a-c924-4d53-aea2-49396a0ecf27', 'development-architecture-failure')]:
    component(base.parent / 'queue-optimization' / name, prefix)
# The earliest blocked diagnostic predates the supervisor's missing-marker repair.
blocked = base / 'diagnostic-2e3c177c-bcb0-49d8-a85c-3074f8f7badb'
for path in blocked.iterdir():
    if path.is_file(): add('nonqualifying-blocked-preflight/' + path.name, path)
for name in ('resource-preflight-full-fad6874.json', 'resource-preflight-verified.json',
             'fad6874-full-launch.json', 'offline-final-fad6874.json', 'offline-final-fad6874.log'):
    add('observations/' + name, base / name)
for path in sorted(base.glob('*.py')):
    add('supervisor-tools/' + path.name, path)

baselines = {
    '2026-10-20': 'ab7ff892a1d8ceafab878deb977d1eacb7becf53bdca5f3dab71ef06eebbf92c',
    '2026-10-21-atomicity-queue': '4805e6f2a1aa111cd280f29ccdcc06a106f1112d473b11ff08b470c8230343cd',
    '2026-10-21-queue-optimization': 'e4c2878e674a9331dfda4d6dd89dd8bc97b8f5b5d42554869611323cfed5c4ff'}
for name, expected in baselines.items():
    assert digest((root / 'validation/qualification' / name / 'raw-evidence.zip').read_bytes()) == expected
files['immutable-baseline-hashes.json'] = (json.dumps(baselines, indent=2) + '\n').encode()

findings = []; scanned = 0
credential = re.compile(r'(?<![0-9a-fA-F])[0-9a-fA-F]{48}(?![0-9a-fA-F])')
sensitive = re.compile(r'(?:password|secret|authorization|credential|api[._-]?key)', re.I)
def scan(name, raw, depth=0):
    global scanned
    scanned += 1
    assert depth <= 3
    if name.lower().endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            assert sum(p.file_size for p in archive.infolist()) <= 256 * 1024 ** 2
            for item in archive.namelist():
                if not item.endswith('/'): scan(name + '!' + item, archive.read(item), depth + 1)
        return
    text = raw.decode('utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8', errors='replace')
    if credential.search(text): findings.append({'file': name, 'reason': 'generated-credential-shaped value'})
    if name.lower().endswith('.xml'):
        try: document = ET.fromstring(text)
        except ET.ParseError: return
        for prop in document.iter('property'):
            key = prop.get('name', ''); value = prop.get('value', '')
            if sensitive.search(key) and value and '${' not in value and value not in ('REDACTED', '[REDACTED]'):
                findings.append({'file': name, 'reason': 'sensitive XML property', 'key': key})
for name, raw in files.items(): scan(name, raw)
assert not findings, json.dumps(findings) # filenames/reasons only, never values
scan_report = {'definition': 'UTF8/UTF16/nested ZIP generated48hex and nonempty sensitive XML properties',
               'scanned': scanned, 'findings': findings}
files['publication-scan.json'] = (json.dumps(scan_report, indent=2) + '\n').encode()
index = {'source': context, 'full_result': {k: v for k, v in result.items() if k not in ('command',)},
    'scope': 'Current full plus separately classified historical/default/diagnostic attempts; no Maven packages',
    'components': records, 'files_sha256': {n: digest(v) for n, v in files.items()}}
files['artifact-index.json'] = (json.dumps(index, indent=2) + '\n').encode()
out.mkdir()
archive_path = out / 'raw-evidence.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, raw in sorted(files.items()): archive.writestr(name, raw)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and set(archive.namelist()) == files.keys()
    for name, raw in files.items(): assert digest(archive.read(name)) == digest(raw)
artifact = {'source': context, 'sha256': digest(archive_path.read_bytes()), 'bytes': archive_path.stat().st_size,
    'files': len(files), 'components': len(records), 'secret_scan': scan_report, 'baseline_hashes': baselines}
(out / 'artifact.json').write_text(json.dumps(artifact, indent=2) + '\n')
(out / 'artifact-index.json').write_bytes(files['artifact-index.json'])
print(json.dumps(artifact))
