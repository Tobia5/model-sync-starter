"""Bounded liveness snapshot; deliberately no aggregate V$SQL progress attribution."""
import json, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

directory = Path(sys.argv[1]).resolve()
record = json.loads((directory / 'infrastructure-observation.json').read_text())
name = record['container']; attempt = record['labels']['io.modelsync.qualification.attempt']
actual = subprocess.check_output(['docker', 'inspect', '--format',
    '{{index .Config.Labels "io.modelsync.qualification.attempt"}}', name], text=True, timeout=15).strip()
assert actual == attempt and name.startswith('msq-')
sql = """whenever sqlerror exit failure rollback
set pagesize 0 feedback off heading off echo off linesize 200 trimspool on
alter session set container=FREEPDB1;
select status||'|'||event||'|'||wait_class||'|'||seconds_in_wait
 from v$session where username='MS_TEST_RUNTIME' and rownum<=12;
exit
"""
result = subprocess.run(['docker','exec','-i',name,'sqlplus','-s','/','as','sysdba'],
    input=sql, capture_output=True, text=True, timeout=20)
assert len(result.stdout) < 6000 and len(result.stderr) < 1000
observation = {'utc': datetime.now(timezone.utc).isoformat(), 'attempt_id': attempt,
    'scope': 'bounded runtime-session liveness only; no statement/cursor progress totals; SYS observer',
    'exit': result.returncode, 'output': result.stdout.strip(), 'stderr': result.stderr.strip()}
with (directory / 'runtime-liveness.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(observation) + '\n')
print(json.dumps(observation))
