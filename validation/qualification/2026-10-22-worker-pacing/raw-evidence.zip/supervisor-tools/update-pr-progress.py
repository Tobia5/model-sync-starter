import json
from pathlib import Path
import subprocess

base = Path(__file__).resolve().parent
pr = json.loads(subprocess.check_output(['gh','pr','view','1','--repo','Tobia5/model-sync-starter',
    '--json','body,headRefOid,state,mergedAt'], encoding='utf-8'))
assert pr['headRefOid'] == 'fad6874c9fa0e0a16ed7d542cace11ea89a991e1'
assert pr['state'] == 'OPEN' and pr['mergedAt'] is None
prior = base / 'pr-description-before-worker.md'
if not prior.exists(): prior.write_text(pr['body'], encoding='utf-8')
body = '''## Current continuation: continuous worker pacing and cursor attribution

Code: [`fad6874`](https://github.com/Tobia5/model-sync-starter/commit/fad6874c9fa0e0a16ed7d542cace11ea89a991e1), tree `a530a260738510da84ed7f68fd26a8a75b803d67`.

- **Default PASS:** approved project Central settings, exit 0, 111 JUnit tests; run `4285d942-bb2c-4cd0-b1f0-6ba62e9b1203`. [Current default CI](https://github.com/Tobia5/model-sync-starter/actions/runs/39682007724) is separate.
- **Targeted worker diagnostic PASS, not full qualification:** run `5e90ca7c-540f-411f-965d-6108c76b6d2c`, ten phases, unchanged 6 GiB/4 CPU disposable Oracle. Actual auto-configured worker/JPA/JDBC, four lanes/pool eight, 160 measured completions per pacing variant. Fixed 250 ms: 18131 ms; productive 5 ms / bounded idle 250-1000 ms: 9518 ms. Every native interval retained eight SID/serial pairs. Urgent local/independent-process work, future deadlines, cooldown expiry and lease recovery met the predeclared local budgets. No production SLO is inferred.
- **Final local full RUNNING**, started 2026-10-21 21:50:47 UTC through the existing container entry point; all PIT, million-row, atomicity, priority/quota, Oracle and six Gatling requirements retained. No qualification result yet. Workflow remains unregistered on main; no bootstrap, merge or CI dispatch was performed.
- Reload/reset/missing/disappeared cursor intervals are explicitly UNATTRIBUTABLE with null deltas and retained raw snapshots. Callback, session and cursor counters remain separate. The earlier correction is preserved.
- Earlier blocked/failed development and diagnostic attempts are retained separately. The first diagnostic failed quota-deferral attribution and showed interrupted JDBC reads at fixture stop boundaries; it is not promoted to PASS. Measurement endpoints now precede cancellation and require physical-session continuity. Production graceful-drain/hung-call proof remains open.

**Production remains NO-GO.** The accepted `ede199a` selector/atomicity baseline and [immutable report/artifacts](https://github.com/Tobia5/model-sync-starter/blob/c21d6daa2c8c1197000f31982b2c1d28cb12cb3f/QM.md) are unchanged. No main changes, merge or package publication.

---

## Previous source-bound qualification record (preserved)

'''
path = base / 'pr-description-progress.md'
path.write_text(body + prior.read_text(encoding='utf-8'), encoding='utf-8')
subprocess.run(['gh','pr','edit','1','--repo','Tobia5/model-sync-starter','--body-file',str(path)], check=True)
