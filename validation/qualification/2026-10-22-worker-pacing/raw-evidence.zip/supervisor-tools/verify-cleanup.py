import json, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

directory = Path(sys.argv[1]).resolve()
infra = json.loads((directory / 'target/qm/oracle-container.json').read_text())
record = {k: infra[k] for k in ('source_sha', 'source_tree', 'run_id', 'attempt_id', 'container_name', 'volume_name')}
assert record['container_name'].startswith('msq-') and record['volume_name'] == record['container_name'] + '-data'
for kind, name in [('container', record['container_name']), ('volume', record['volume_name'])]:
    result = subprocess.run(['docker', kind, 'inspect', '--format', '{{.Name}}', name],
        capture_output=True, text=True, timeout=20)
    missing = ('No such container' in result.stderr if kind == 'container' else 'no such volume' in result.stderr)
    record[kind + '_inspect_exit'] = result.returncode
    record[kind + '_independently_absent'] = result.returncode != 0 and missing
record.update(utc=datetime.now(timezone.utc).isoformat(), scope='read-only fixed owned resource absence; no resource mutations')
path = directory / 'independent-cleanup.json'
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
assert record['container_independently_absent'] and record['volume_independently_absent']
