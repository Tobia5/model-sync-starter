import json, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone

directory = Path(sys.argv[1]).resolve()
launch = json.loads((directory / 'launch.json').read_text())
observation = json.loads((directory / 'infrastructure-observation.json').read_text())
name = observation['container']
expected = observation['labels']['io.modelsync.qualification.attempt']
label = subprocess.check_output(['docker', 'inspect', '--format',
    '{{index .Config.Labels "io.modelsync.qualification.attempt"}}', name], text=True, timeout=15).strip()
assert label == expected
sample = subprocess.run(['docker', 'stats', '--no-stream', '--format', '{{json .}}', name],
    capture_output=True, text=True, timeout=15, check=True)
assert len(sample.stdout) < 4000
memory = subprocess.check_output(['powershell', '-NoProfile', '-Command',
    '(Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory'], text=True, timeout=15).strip()
record = {'utc': datetime.now(timezone.utc).isoformat(), 'source_sha': launch['source_sha'],
    'attempt_id': expected, 'host_free_gib': int(memory) / 1024 ** 2, 'container': json.loads(sample.stdout),
    'scope': 'point observations only, not peak-resource proof'}
with (directory / 'resource-samples.jsonl').open('a', encoding='utf-8') as output:
    output.write(json.dumps(record) + '\n')
print(json.dumps({'utc': record['utc'], 'host_free_gib': record['host_free_gib'],
                  'memory': record['container']['MemUsage'], 'cpu': record['container']['CPUPerc']}))
