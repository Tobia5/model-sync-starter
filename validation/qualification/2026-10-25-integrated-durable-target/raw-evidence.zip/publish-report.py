﻿from pathlib import Path
import json,hashlib,zipfile,collections,re,xml.etree.ElementTree as ET
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]/'model-sync-starter'
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
facts=read(BASE/'measured-summary.json');e=read(ROOT/'target/qm/evidence.json');default=next(BASE.glob('default-*'));full=next(BASE.glob('full-*'))
default_result=read(default/'result.json');full_result=read(full/'result.json');capacity=read(next(BASE.glob('scoped-capacity-*.json')))
run=facts['run_id'];sha=facts['source_sha'];tree=facts['source_tree'];default_run=read(default/'archive-manifest.json')['run_id']
report_dir=ROOT/'validation/qualification/2026-10-25-integrated-durable-target';report_dir.mkdir(exist_ok=False)
# An additional manifest seals the external session contents; previous session folders are untouched.
files=[p for p in BASE.rglob('*') if p.is_file() and not p.name.startswith('pr-') and p.name!='raw-archive-manifest.json']
(BASE/'raw-archive-manifest.json').write_text(json.dumps({'source_sha':sha,'source_tree':tree,'default_run':default_run,'full_run':run,'overall_full':'FAILED','files_sha256':{p.relative_to(BASE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}},indent=2)+'\n')
files.append(BASE/'raw-archive-manifest.json')
archive=report_dir/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(BASE).as_posix())
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(report_dir/'SHA256SUMS').write_text(digest+'  raw-evidence.zip\n')
load=read(ROOT/'model-sync-persistence-jdbc/target/qm/oracle-workload.json')
worker=read(ROOT/'model-sync-sample/target/qm/oracle-worker.json')['phases'][0]
comparison=read(ROOT/'model-sync-persistence-jdbc/target/qm/oracle-optimization.json')
cooldown_worker=read(ROOT/'model-sync-sample/target/qm/oracle-cooldown-worker.json')
ns={'m':'http://maven.apache.org/POM/4.0.0'};pom=ET.parse(ROOT/'model-sync-testkit/pom.xml')
mutated=[p.text for p in pom.findall('.//m:targetClasses/m:param',ns)]
mutation_scope=', '.join('`'+p+'`' for p in mutated)
source_url='https://github.com/Tobia5/model-sync-starter/blob/'+sha+'/'
summary=f'''# Integrated DURABLE named-target qualification - 2026-10-25

**Default PASS. Configured full FAILED. Production NO-GO.**

Tested clean source **`{sha}`**, tree **`{tree}`**, branch
`review/layered-refactor-qm-20261020` in `Tobia5/model-sync-starter`.
The later report-only commit is not claimed as tested code. No production code,
locking, scheduling, applicability, workload, threshold or resource setting changed.
Sources5b96b47/1cfbefb, report7c1abe5 and all17 earlier raw archives remain unchanged;
the seven-method diagnostic stays attributed to5b96b47.

## Commands, identities and exits

Approved Maven settings: `.mvn/qualification-central.settings.xml`, SHA-256
`ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.

| Execution | Current evidence | Original exits |
|---|---|---|
| `mvnw.cmd -B -ntp -s .mvn/qualification-central.settings.xml clean verify` | PASS; run `{default_run}`;189 JUnit/98 Python/38 XML,0 bad;216.100s supervisor runtime | build0, report0, execution audit0, collection0 |
| Git Bash `scripts/test-triggers.sh` |86 core/43 trigger assertions PASS; separate from JUnit |0 |
| Post-collection `python capacity.py full` (archived helper) | PASS; host21.563/21.648/21.564GiB >=18; Docker19.969GiB available; C83.048/D1069.891GiB free |0 |
| `python scripts/full-oracle-container.py` | FAILED; run `{run}`;5976.738s wrapper runtime;191 Surefire PASS,83 Oracle/18 suites:81 PASS,2 FAILED,0 errors/skips | wrapper1, Maven1, qualification1, collection0 |

The full wrapper used invocation-only `MODELSYNC_ORACLE_CONTAINER=EXPLICIT_DISPOSABLE`,
`MODELSYNC_FULL_ENV_ACK=DISPOSABLE_NONPRODUCTION` and the same
`MODELSYNC_MAVEN_SETTINGS`. Nested Maven retained `-B -ntp -s <approved-settings>
-fae -Pfull clean verify`. No diagnostic selector or unchanged retry ran.

## Required failures retained

1. **OracleQualificationTargetIT FAILED**, line42: no captured Hibernate SQL
   contained `for update nowait`. Adapter/platform/mapping/enlistment receipts
   passed; they do not satisfy this separate SQL assertion. The fixture owner
   returns the same replica value twice: first creation then the equal-value
   `MATCH` path, which skips projection CAS. This source inspection explains a
   missing existing-row exercise; the failing fixture did not persist its SQL
   list, so no replacement SQL observation is invented. Separate lock-policy
   cases passed and are not reopened. Follow-up: exercise the actual existing-row
   lookup/refresh in this fixture, retaining the assertion and all policies.
2. **OracleWorkerIT FAILED**, fixed-mode productive phase: the20,000ms condition
   timed out at20,003ms. Four lanes,250ms poll/productive/maximum-idle delays,
   persistence4/owner8 threads, pool8, owner20ms spacing/5ms latency.
   Completions94 total (10 warmup +84 measured),76 WAITING/94 IDLE.
   Interval deltas:295 ticks,211 empty,84 owner calls/grants/completions,
   0 failed ticks,1670 selector callbacks; stable eight-session interval,
   416334 consistent gets,7753 block gets,1 physical read.
   Worker running=true and physical/logical0 at the failure snapshot do not
   prove lane health or successful drain. Cause remains unestablished; no pacing
   redesign, deadline extension or arbitrary error acceptance was made.
   Bounded/adaptive, idle, wakeup and recovery phases in this method are NOT_RUN.

## Passing partial evidence

- All83 mandatory Oracle method names matched the current83/18 inventory.
  Both seven-case atomicity modes, six process-recovery cases, eleven applicable
  I/O cases, seven lock-policy, six quota, twelve first-creation and six new
  cooldown methods executed. All except the two methods above passed.
- Runtime receipts verified actual point/quota/JPA `ORACLE_NOWAIT`,
  `ORACLE_26_NOWAIT`, `DURABLE`, qualified mappings and shared datasource/
  `JpaTransactionManager`. All five required host roles are present. Oracle
  migration consumed extension version1; schema/runtime receipts are retained.
  The SQL-proof failure still prevents target qualification.
- PIT1.25.9/provider1.2.3:167 KILLED/1 SURVIVED/168 generated,**99.40% killed/generated**,
  0 NO_COVERAGE/TIMED_OUT/RUN_ERROR.85% gate unchanged. The surviving
  `FreshnessPolicy.positive(maxAge)` removal remains counted; positive refresh
  plus refresh<=max rejects nonpositive max, and null comparison rejects null.
  Existing equivalence review does not equate exception messages.
- Eight comparison variants PASS:3425 claims/acquisitions =1765 grants +1138
  denials +522 captured LocalContention refusals (SQLState61000/vendor54).
  1765 measured owner calls,1603 committed reconciliations; no unknown/uncertain
  acquisition outcomes, escaped lanes or active operations.104 logical cooldowns,
  104 acceptance commits,119 apply attempts =104 commits +15 refused rollbacks;
  all104 final APPLIED,0 unresolved/logical failures.32/32 lanes finished normally.
- Oracle capacity:1,000,000 seeded (100,000 due/900,000 future),100 hot requests,
  seed4,327,625ms. Four direct coordinator workers/pool8:200 measured completions
  from220 measured owner calls in9584ms (20.868 syncs/s);210 completions/230 calls
  with warmup.13 synthetic429s/7 timeouts.338.191 summed DB work units per measured
  owner call; individual counters retained. Claimed runOne p50/p95/p99=37/59/62ms;
  lag4340740/4345255/4345702ms includes seeding. This is not actual-worker capacity,
  a production SLO or a million completed synchronizations.
- Separate actual cooldown worker PASS:2 owner calls/2 committed admissions,
  unrelated-provider completion, shared pending proof with blocker held, recovery
  without another read; DRAINED11ms, physical/owner/pool0. This does not replace the
  failed pacing method. Six in-memory Gatling scenarios and their HTTP assertions
  PASS:367 requests,0 HTTP errors; not Oracle capacity evidence.

Environment: JDK21.0.12.1, Maven3.9.9, Python3.12.10, Docker29.8.2,
Boot4.1.1, JUnit/launcher6.0.3, Hibernate7.4.5.Final, Oracle26ai23.26.3.0.0/
JDBC23.26.3.0.0, Surefire/Failsafe3.5.3, Gatling3.13.1/plugin4.11.0.
Pinned Oracle image and unchanged6GiB/4CPU caps are in the infrastructure receipt.

## Cleanup, applicability and remaining gates

Container `msq-f84fcf0a6e32` and volume `msq-f84fcf0a6e32-data` removed; wrapper
checks and independent exact-name inspections agree. All12 PIDs from current-run
host receipts are absent. No residual owned infrastructure was observed.
Historical independent cancellation remains FAILED (`2c39b75`/`43040e7`);
current characterization NOT_RUN. DEFAULT, older Oracle and arbitrary replacement
beans have no named bounded-persistence qualification.

The two current failures prevent configured full acceptance. Unrecorded provider
response/failed acceptance windows, uncertain outcomes, receipt retention and
maintenance, compliant rollout, security, operations and other parent release
gates remain open. Even a future configured full PASS is not production acceptance.

[Detailed current evidence](validation/qualification/2026-10-25-integrated-durable-target/README.md)
includes inventory, comparison/Gatling tables and raw reports. Archive SHA-256:
`{digest}`. Original run-scoped `target/qm/QM.md`, logs, partial checks and raw
reports are inside the archive. No merge, main change, workflow bootstrap or
package publication occurred. Earlier QM content below is preserved byte-for-byte.

---

'''
old=(ROOT/'QM.md').read_bytes();(ROOT/'QM.md').write_bytes(summary.encode('utf-8')+old)
readme=summary.replace('[Detailed current evidence](validation/qualification/2026-10-25-integrated-durable-target/README.md)','[Root QM](../../../QM.md)').replace('Earlier QM content below is preserved byte-for-byte.','The root QM retains earlier history byte-for-byte.').replace('No merge, main change, workflow bootstrap or\npackage publication occurred.','No merge, main change, workflow bootstrap or\npackage publication occurred.')
readme+='## Required Oracle suite inventory\n\nThe archived `qualification-target.json` names all83 methods. Fresh XML method names\nwere compared exactly, including both failed methods; none was substituted or skipped.\n\n| Suite | Methods | Failures | Seconds |\n|---|---:|---:|---:|\n'
for r in facts['inventory']:readme+=f"| {r['suite']} | {r['tests']} | {r['failures']} | {r['seconds']:.3f} |\n"
readme+='\n## Controlled comparison (current integrated run only)\n\nSame100k all-due fixture, four direct workers/pool8, owner20ms spacing/5-or25ms\nlatency,429 every17/timeouts every29. Same NOWAIT quota/Oracle26 insert/DURABLE\npolicy across variants. Forward/reverse order, original completion floors and\nphase/cursor/session assertions retained. Statistics/cache/table history and\nsetup/cleanup work are in raw reports; timing differences from older runs are\nnot isolated causal measurements. No logical-get share is called wall-time share.\n\n| Round / variant | ms | Claims | Grants / denials / refusals | Owner calls | Syncs | Cooldowns / logical failures | Native logical gets/sync |\n|---|---:|---:|---|---:|---:|---|---:|\n'
for r in facts['variants']:
 readme+=f"| {r['round']} / {r['variant']} | {r['measurement_ms']} | {r['ledger_attempts']} | {r['quota_grants']} / {r['quota_denials']} / {r['quota_refusals']} | {r['measured_owner_calls']} | {r['measured_completed_syncs']} | {r['cooldown_attempts']} / {r['cooldown_failures']} | {r['logical_gets_per_completed']:.3f} |\n"
readme+='\nWarmup is separate (10 owner reads/completions per variant,80 total). Raw per-attempt\ncorrelation and detached failures establish the522 current refusals; historical55\nremain unclassified and historical five publication failures remain FAILED.\nNo arithmetic remainder has been relabelled as a measured failure.\n\n## Gatling semantics (in-memory test harness)\n\n| Scenario | HTTP requests / errors | HTTP p50/p95/p99 ms | Accepted visits | Owner calls (incl fixture setup) | Completed-row counter | Measurement+drain ms |\n|---|---|---|---:|---:|---:|---:|\n'
for name,r in sorted(e['evidence']['gatling'].items()):
 h=r['http'];p=h['http_response_time_ms'];readme+=f"| {name} | {h['requests']['total']} / {h['requests']['ko']} | {p['p50']}/{p['p95']}/{p['p99']} | {r['accepted_visits']} | {r['physical_owner_calls']} | {r['completed_rows']} | {r['measurement_and_drain_ms']} |\n"
readme+='\nFresh-cache setup performs one initial owner read; fresh visits add none. The raw\ncompleted-row counter is not synthesized from accepted visits/HTTP202. Harness\nprojection/ledger assertions remain the semantic checks. This tiny local load is\nnot Oracle throughput, production provider capacity or long-duration qualification.\nEach Gatling JVM uses1GiB heap; leases has200 synthetic records/200 job requests.\nOther concurrency, startup/drain behavior and selected Java simulations remain\nsource-linked in `model-sync-performance` and raw logs; thresholds were unchanged.\n\n## Mutation scope and investigation\n\n'+mutation_scope+'\n\nFour test classes: CoreContractsTest, TriggerContractsTest, AdmissionHintsTest,\nContentionPolicyTest. XML, HTML and executed plugin/configuration logs are retained.\nNo business exclusions/threshold changes were added for this run. The sole\nsurvivor is still in the denominator. See the root historical equivalence review\nand FreshnessPolicy constructor at this exact source.\n\n## Evidence layout and collection\n\n- `default-fa3c9458-ab18-48fc-ab37-794fb823c341/`: original default build, report/audit/collector outputs,89 raw files and hashes.\n- `full-547b1a99-e0da-436b-85df-8c44d4f2e89a/`: original failed build and qualification logs, collector0,408 current raw files and hashes, including run-scoped QM and67MB detailed evidence JSON.\n- `baseline.json`, `frozen-source-end.json`, `preservation-during-run.json`: clean-source identity and preserved17 historical archive/root-QM hashes.\n- `scoped-capacity-*.json`, `capacity-command.json/log`: post-default bounded admission and original exit0. No unbounded wait/retry or budget change.\n- `independent-cleanup.json`, `owned-processes.json`: bounded exact-owned-resource observations and original query exits.\n- `measured-summary.json`, `summarize.py`: read-only partial validation. Collection exit0 records component statuses; actual-worker validation remains FAILED/1 and overall full FAILED. These are no new test executions or substitute full gates.\n- `session.py`, `capacity.py`, `publish-report.py`: exact local orchestration and report derivation. No credentials/settings overrides outside the approved project file.\n- `nonsecret-artifact-check.json`: bounded48-hex credential-format scan found no matching file; not a general secret-detection guarantee. No complete container environment was exported.\n- `raw-archive-manifest.json`: entry hashes; `SHA256SUMS` seals the zip.\n\nThe full collector has default lane NOT_RUN because that collection belongs to\nthe full run only. The separately archived fresh default is PASS at its own run\nidentity; no marker/reports were borrowed. Report generation preserved Maven1,\nqualification1 and fresh failing measurements. Full gate rejected the two failed\nsuites; the performance module evidence-gate failure is consequential, not an\nadditional Gatling scenario failure. No unchanged qualification rerun occurred.\n'
(report_dir/'README.md').write_text(readme,encoding='utf-8')
latest='''## Latest integrated execution - 2026-10-25

Clean source7c1abe5/treec604e462 passed fresh default189 JUnit/98 Python.
Named full d7fd02b7 executed all83 Oracle methods/18 suites:81 PASS,2 FAILED
(target fixture missing observed NOWAIT SQL; fixed-mode worker backlog timeout).
PIT167/168 and six in-memory Gatling scenarios passed. All eight comparison
variants passed,104 cooldowns APPLIED/0 logical failures. One million seeded rows
produced200 measured reconciliations, not a million completions. Maven/wrapper/
qualification1, collection0; owned container/volume and12 receipt PIDs absent.
[Current QM]({qm}) / [raw report]({report}). Production remains NO-GO;
accepted scoped milestones and applicability are unchanged. Earlier sections
below describe historical evidence, not this integrated run.

'''
for name,qmlink,reportlink in [('docs/PRODUCTION-READINESS.md','../QM.md','../validation/qualification/2026-10-25-integrated-durable-target/README.md'),('docs/USER-HANDBOOK.md','../QM.md','../validation/qualification/2026-10-25-integrated-durable-target/README.md'),('docs/quality/COOLDOWN-PUBLICATION.md','../../QM.md','../../validation/qualification/2026-10-25-integrated-durable-target/README.md')]:
 p=ROOT/name;original=p.read_bytes();p.write_bytes(latest.format(qm=qmlink,report=reportlink).encode('utf-8')+original)
p=ROOT/'TODO.md';original=p.read_bytes();prefix='''## Integrated execution follow-up - 2026-10-25

- [x] Execute the complete named DURABLE target once on clean source7c1abe5/treec604e462, full run d7fd02b7-1d9d-430c-a8ef-dfa883e8add6:83 methods/18 suites,81 PASS/2 FAILED,0 skipped. Default189 JUnit/98 Python, PIT167/168, six Gatling scenarios and all eight comparison variants passed;104 cooldowns all APPLIED. [QM](QM.md) / [raw evidence](validation/qualification/2026-10-25-integrated-durable-target/README.md). This closes execution only, not qualification.
- [ ] Make OracleQualificationTargetIT actually exercise the existing-row lookup/refresh while retaining its actual-SQL assertion; current identical owner responses take first-create then MATCH. No production lock-policy defect was established by this fixture failure.
- [ ] Investigate OracleWorkerIT fixed250ms productive timeout using retained20,003ms snapshot:10 warmup+84 measured completions/76 WAITING, running=true, physical/logical0. Root cause unestablished; do not assume lane loss, extend its bound or redesign pacing from this snapshot. Later phases NOT_RUN.
- [ ] Obtain passing integrated named-target evidence after resolving the current failed requirements. Preserve this failed attempt and every prior scoped milestone. Unrecorded-response windows, uncertainty, receipt retention, security/operations and all incomplete parent gates remain open; production NO-GO.

''';p.write_bytes(prefix.encode('utf-8')+original)
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'entries':len(files),'sha256':digest,'root_qm_prefix_bytes':len(summary.encode('utf-8')),'overall_full':'FAILED'}))
