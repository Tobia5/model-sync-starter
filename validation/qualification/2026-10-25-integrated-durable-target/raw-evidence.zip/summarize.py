﻿from pathlib import Path
import sys,json,collections,hashlib,xml.etree.ElementTree as ET,importlib.util,datetime
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]/'model-sync-starter'
sys.path.insert(0,str(ROOT/'scripts'))
from run_evidence import current
from queue_evidence import optimization,check as queue_check,worker
from cooldown_evidence import qualify as cooldown
from failure_evidence import qualify as faults
from lock_policy_evidence import qualify as lock_policy
from quota_evidence import qualify as quota
from creation_evidence import qualify as creation
from qualification_target import qualify as target
from gatling_evidence import measured
context=current(ROOT)
def read(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
spec=importlib.util.spec_from_file_location('full_check',ROOT/'scripts/check-full-reports.py')
full=importlib.util.module_from_spec(spec);spec.loader.exec_module(full)
scale=read('model-sync-persistence-jdbc/target/qm/oracle-scale.json')
load=read('model-sync-persistence-jdbc/target/qm/oracle-workload.json')
checks={}
for name,call in [('runtime_receipts',lambda:target(ROOT)),('point_jpa',lambda:lock_policy(ROOT)),('quota',lambda:quota(ROOT)),('first_creation',lambda:creation(ROOT)),('cooldown',lambda:cooldown(ROOT)),('PIT',lambda:full.pit_counts(ROOT)),('capacity_scale',lambda:queue_check(ROOT,scale,load)),('comparison',lambda:optimization(ROOT)),('faults',lambda:faults(ROOT)),('actual_worker',lambda:worker(ROOT))]:
 try:
  call();checks[name]={'status':'PASS','exit':0}
 except Exception as error:
  checks[name]={'status':'FAILED','exit':1,'reason':str(error)[:800]}
for mode in sorted(full.SIMULATIONS):
 r=measured(ROOT,mode)
 checks['gatling_'+mode]={'status':r['status'],'exit':0 if r['status']=='PASS' else 1}
manifest=read('docs/quality/qualification-target.json')
inventory=[]
for module,suites in manifest['mandatory'].items():
 for name,expected in suites.items():
  path=ROOT/module/'target/failsafe-reports'/('TEST-'+('io.modelsync.jdbc.' if module.endswith('jdbc') else 'io.modelsync.sample.')+name+'.xml')
  xml=ET.parse(path).getroot();actual=[c.get('name').removesuffix('()') for c in xml.findall('testcase')]
  assert sorted(actual)==sorted(expected),(module,name,actual,expected)
  inventory.append({'module':module,'suite':name,**{k:int(xml.get(k,'0')) for k in ['tests','failures','errors','skipped']},'seconds':float(xml.get('time'))})
d=read('model-sync-persistence-jdbc/target/qm/oracle-optimization.json')
keys=['ledger_attempts','quota_grants','quota_denials','quota_failures','quota_refusals','measured_owner_calls','measured_completed_syncs','cooldown_attempts','cooldown_published','cooldown_pending','cooldown_durable','cooldown_failures','lanes_finished_normally']
totals={k:sum(r.get(k,0) for r in d['results']) for k in keys}
for key in d['results'][0]['accounting']['quota_boundary']:
 totals['boundary_'+key]=sum(r['accounting']['quota_boundary'][key] for r in d['results'])
publication={k:sum(r['publication_transactions']['delta'][k] for r in d['results']) for k in d['results'][0]['publication_transactions']['delta']}
variants=[{k:r[k] for k in ['round','variant','status','measurement_ms','ledger_attempts','quota_grants','quota_denials','quota_refusals','measured_owner_calls','measured_completed_syncs','cooldown_attempts','cooldown_failures','logical_gets_per_completed','claimed_run_one_latency_ms']} for r in d['results']]
summary={**context,'generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'read-only partial-report validation; overall full remains FAILED','overall_full':'FAILED','checks':checks,'inventory':inventory,'oracle_totals':{k:sum(r[k] for r in inventory) for k in ['tests','failures','errors','skipped']},'comparison_totals':totals,'publication_transactions':publication,'variants':variants,'runtime_receipt_roles':dict(collections.Counter(r['role'] for r in read('target/qm/evidence.json')['evidence']['qualification_target']['receipts']))}
(BASE/'measured-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert current(ROOT)==context
print(json.dumps({'overall_full':summary['overall_full'],'checks':checks,'oracle_totals':summary['oracle_totals'],'comparison_totals':totals,'publication_transactions':publication}))
