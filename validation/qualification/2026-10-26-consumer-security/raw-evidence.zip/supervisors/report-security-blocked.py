from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,zipfile,xml.etree.ElementTree as ET
root=Path.cwd();base=root.parent/'qualification-evidence/security-consumers-20261026-r1'
w=base/'final-consumers-r3';out=root/'validation/qualification/2026-10-26-consumer-security'
sys.path.insert(0,str(root/'scripts'));import consumer_security as s;import consumer_artifacts as c
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
m=json.loads((w/'artifact-manifest.json').read_text());s.validate_inputs(root,w)
source=m['fixture_source']['source_sha'];tree=m['fixture_source']['source_tree']
default=json.loads((base/'default-r3/raw/target/qm/evidence.json').read_text())
default_id=default['evidence']['attribution'];assert default['runs']['default']['qualification_exit']==0
count=sum(v['surefire'].get('tests',0) for v in default['evidence']['modules'].values());assert count==222
sup=json.loads((base/'security-r3-supervision-result.json').read_text());infra=json.loads((base/'security-r3-infrastructure.json').read_text())
admission=json.loads(next(w.glob('admission-*.json')).read_text());cleanup=json.loads((base/'security-r3-independent-cleanup.json').read_text())
assert infra['status']=='BLOCKED' and not infra['container_created'] and infra['maven_exit'] is None
assert sup['original_wrapper_exit']==2 and sup['source_after']==m['fixture_source']
assert not list(w.glob('consumer-run-*.json')) and cleanup['attempt_id']==infra['attempt_id']
assert all(v['exit']==0 and v['owned_resources']==[] for v in cleanup['checks'].values())
cheap={}
for mode in c.MODES:
 suites=[ET.parse(p).getroot() for p in (w/mode/'target/surefire-reports').glob('TEST-*.xml')]
 assert len(suites)==1 and all(int(v.get(k,0))==0 for v in suites for k in ('failures','errors','skipped'))
 cheap[mode]=sum(int(v.get('tests')) for v in suites)
 assert cheap[mode]==(5 if mode=='mvc' else 6) and m['consumers'][mode]['prepare_exit']==0
history=[]
for directory,prefix in [('final-consumers','security'),('final-consumers-r2','security-r2')]:
 run=json.loads(next((base/directory).glob('consumer-run-*.json')).read_text())
 assert run['exit']==1 and run['modes']['mvc']['original_exit']==1 and run['modes']['webflux']['original_exit']==0
 prior_manifest=json.loads((base/directory/'artifact-manifest.json').read_text())
 s.check_receipt(run['modes']['webflux']['receipt'],run['run_id'],prior_manifest,'webflux',c.digest(base/directory/'artifact-manifest.json'))
 for mode,v in run['modes'].items():
  for case in v['receipt']['negative_cases']:
   assert case['before']==case['after'] and case['side_effects_unchanged'] is True
 supervision=json.loads((base/(prefix+'-supervision-result.json')).read_text())
 assert all(v['absent'] for v in supervision['independent_cleanup'].values()) and all(v['absent'] for v in supervision['consumer_jvms'])
 history.append({'execution':run,'supervision':supervision})
prior=json.loads((base/'preserved-baselines.json').read_text())
assert all(c.digest(root/p)==h for p,h in prior['archives'].items())
assert c.digest(root/'QM.md')==prior['qm_sha256']
out.mkdir(exist_ok=False)
c.write(out/'results.json',{'fixture_source':m['fixture_source'],'artifact_source':m['producer'],
 'default':default['runs'],'default_run':default_id,'default_counts':{'junit':count,'xml':41,'python':116},
 'cheap_security':cheap,'current_oracle':{'status':'NOT_RUN','maven_exit':None},
 'admission':admission,'infrastructure':infra,'supervision':sup,'independent_cleanup':cleanup,
 'historical_attempts':history,'collection_exit':0,'evidence_validation_exit':0,
 'full':'NOT_RUN','production':'NO_GO','prior_archives_unchanged':len(prior['archives'])})
shutil.copy2(w/'artifact-manifest.json',out/'artifact-manifest.json')
report=f'''# Independent consumer authorization and tenant isolation — 2026-10-26

**Current default/cheap security PASS; Oracle admission BLOCKED; current Oracle journeys NOT_RUN.**
The earlier WebFlux journeys passed, within two overall FAILED attempts. Final-source
Oracle verification of both stacks remains open. Production remains **NO-GO**.

## Source and artifact identity

| Item | Identity and result |
|---|---|
| Frozen security fixture | `{source}`, tree `{tree}`, clean before/after |
| Matching default run | `{default_id}`; 222 JUnit tests / 41 XML files, 116 Python checks; build/qualification/collection exits 0 |
| Independent cheap consumers | MVC 5, WebFlux 6 JUnit methods; no failures/errors/skips; both preparation exits 0 |
| Final infrastructure attempt | `{infra['attempt_id']}`; wrapper exit **2**, resource admission BLOCKED |
| Admission receipt | `{admission['attempt_id']}`; host 9.458–9.699 GiB against unchanged **12 GiB** |
| Final consumer Oracle runs | **NOT_RUN**; Maven exits absent, no runtime run ID or receipts created |
| Artifact producer | `551427bed4d021339fcc32fef8f633232ff8deb8`, tree `892daec99e12738607a9bfe736d8e98ee8218d0c` |
| Original packaging run | `b3db2e0f-e56a-420f-b379-0d1e73f15eb0`; original manifest SHA-256 `{s.BASE_MANIFEST}` |

All **39 staged artifacts** retain their original hashes. The artifact manifest lists
coordinates, attachment hashes, standalone source hashes, commands and dependency
trees/classpath hashes. Model Sync runtime/library/platform source is unchanged from
551427b, checked before staging and execution. Consumer dependency resolution uses
separate task-owned repositories outside the producer reactor. Runtime CodeSource
and JAR-hash receipts exist for the two earlier executed attempts. No producer
classes/source directories, systemPath, IDE resolution or sample internals substitute
for the staged artifacts. Public dependency cache copies are recorded separately.

The accepted full baseline a0f46d7/report 8d07aa7, independent consumer baseline
551427b/report 50c9370 and all 22 prior raw archives remain unchanged. R10.1, R10.2
and R13.2 remain completed within their existing scopes. No packaging qualification,
producer full, PIT, Gatling, million-row seed, merge or publication was repeated.

## Commands, exits and environment

Approved project settings: `.mvn/qualification-central.settings.xml`, SHA-256
`ef6dc911e57f86840ab529882c579e4128e9dc05ba6077640b622b852b726940`.
The user's settings/cache were not changed. Exact command arrays, working directories
and start/end times are in [results](results.json) and the raw archive.

1. Producer `mvnw.cmd -B -ntp -s <approved-settings> -Dmaven.repo.local=<task-owned-m2> clean verify`:
   exit 0; independent QM qualification/collection exits 0. Core/trigger contracts
   (86/43 assertions), architecture/docs checks and default execution audit passed.
   Assertion counts are separate from JUnit counts.
2. `python scripts/consumer_security.py stage <workspace> --artifacts <original-staged-workspace>`
   then `prepare <workspace>`: two separate Maven `clean test` invocations with dependency
   tree/classpath capture and public dependency/plugin resolution; exits 0/0.
   A separate `-Psecurity-oracle dependency:go-offline` resolves Failsafe without
   running Oracle. Five MVC / six WebFlux cheap tests passed on the frozen source.
3. Invocation-only disposable acknowledgments and approved settings, then
   `python scripts/full-oracle-container.py --consumer-diagnostic <workspace>`:
   original exit **2**. The intended separate offline `-Psecurity-oracle verify`
   invocations were **not started**. No prior runtime reports were attributed to it.

Java 21.0.12.1, Maven 3.9.9, Boot 4.1.1 and BOM-resolved Spring Security **7.1.1**.
Earlier runtime receipts verify Oracle/JDBC 23.26.3 and Hibernate 7.4.5.Final.
Pinned image:
`ghcr.io/gvenzl/oracle-free:23.26.3-slim@sha256:6d61d267a3b978c24c5ac1790e62e927416a0aec446bd86e4b3a1527562757bd`.
The existing 6 GiB / 4 CPU Oracle cap, loopback ports, generated credentials,
separate runtime/migration schemas and 512 MiB heap / 128 MiB direct-memory JVM
caps remain unchanged. Each enabled consumer uses pool 4, two worker/persistence/
owner threads, bounded queues and the previous pacing/timeouts. Full budget stays 18 GiB.

## Application-owned security boundary

The standalone applications use Spring Security's actual MVC/WebFlux filter chains,
HTTP Basic authentication, method authorization and CSRF protection. Test-only
in-memory identities receive generated per-JVM passwords; no real identities,
external provider, custom token protocol or core security dependency was added.
CSRF, BREACH handling and security headers remain enabled. Live clients use the
framework token/session; cheap tests use Spring Security's MockMvc/WebTestClient support.

The application policy checks exact operation/tenant/binding/subject authority
before calling the gateway or publishing an event. Read, refresh and event grants
are separate; unknown scope and missing authority fail closed. Policy lookup does
not read protected model payloads. A proxied facade also protects direct service
and event-ingress calls. Raw `SyncGateway`, internal adapter and event publisher
remain **trusted in-process capabilities**; these tests do not sandbox hostile
code with those references. External ingress must use the authorized facade.

The reactive facade checks Reactor SecurityContext and carries only a detached
principal name into blocking work on `modelSyncPersistenceScheduler`. The durable
worker has an explicit known-ID service scope for alpha/beta and item; it checks
that no request principal was inherited. Queuing does not carry a live request
SecurityContext or grant. Revoking already accepted intent is not qualified here.

## Executed Oracle evidence — preserve each attempt's status

| Source / run | Overall; original wrapper/MVC/WebFlux exits | MVC observed scope | WebFlux observed scope |
|---|---|---|---|
| f206718 / `2b8e502f-31ca-4ded-bccb-93911f17bb11` | **FAILED**; 1/1/0 | Two initial committed outcomes; one completed negative case; failed expected 403 versus actual 401 for anonymous POST; later phases NOT_RUN | **PASS**: 30 negative cases, four owner calls / four committed reconciliations, 32 concurrent HTTP identity checks |
| 8e36028 / `143adeff-77ef-4864-ad9c-23ab46534c6c` | **FAILED**; 1/1/0 | Two initial committed outcomes; three captured negative snapshots with unchanged side effects; failed expected 403 versus actual 401 for missing CSRF; later phases NOT_RUN | **PASS**: all 30 negatives, four owner calls / four committed reconciliations, 32 concurrent HTTP identity checks |
| 8df8c94 / current attempt | **BLOCKED**; 2/absent/absent | NOT_RUN | NOT_RUN |

Both executed WebFlux hosts committed alpha-A/beta-A for the same subject `shared`
at revision 0 / generation 1, then event-alpha-B and refresh-beta-B at revision 1 /
generation 2. Fresh connections confirmed paired projection/state, matching
validators, APPLIED outcomes and IDLE work. Facade counters were 35 reads, three
refresh enqueues and one event; one actual event publication, four physical owner
HTTP calls and four committed reconciliations were counted separately.

Each of the 30 negative cases compared before/after protected gateway reads,
JPA mapping reads, enqueue calls, actual event publication, physical owner calls
and committed projection/state/work rows (including generations and freshness
fields). All captured pairs in the executed attempts are unchanged. Policy lookup
and idle selector activity are separate from protected model-payload access.

The complete WebFlux matrix covers unauthenticated requests, missing CSRF,
cross-tenant/unknown-tenant/wrong-binding/wrong-subject access for all three
operations, missing grants, read-only versus refresh/event permissions, unknown
operation, and direct anonymous/insufficient/cross-tenant facade calls. All run
against fresh protected values. Its 32 concurrent HTTP reads returned the right
tenant's B value across the real persistence scheduler, without owner/enqueue/
event/state changes. Qualified mapping/effective policies, five auto-configurations,
DatabaseClock replacement, datasource/JpaTransactionManager enlistment, trusted raw
JPA/JDBC rollback, disabled mode, pools and physical shutdown checks passed.
The rollback control does not claim cross-thread caller-transaction propagation.

## Fixture corrections and remaining execution gap

Initial cheap dirty-source probes rooted at 50c9370 failed one method in each
stack because the expected missing-context exception was too narrow. The corrected
helper accepts only Spring Security denial types or the bounded MVC SpEL cause
chain containing AuthenticationCredentialsNotFoundException. Unrelated errors fail.
The next cheap attempt passed both stacks.

The first live servlet run returned 401 for anonymous POST where MockMvc had
returned 403. A retained cheap probe rooted at f206718 failed when it incorrectly
applied the live 401 to MockMvc. The second live run then exposed the same 401/403
expectation mismatch for missing CSRF. These are measured response differences;
their framework dispatch cause was not diagnosed. No authorization bypass or
runtime-library defect was observed, and no security protection was disabled.

Current source 8df8c94 records expected/actual status and authentication-challenge
presence and collects the complete HTTP status matrix before aggregate status
assertions. It still fails immediately on protected side effects. Live MVC expects
401 for the observed anonymous/CSRF cases; WebFlux and MockMvc retain their own
measured expectations. This correction is **cheap-test verified, not yet Oracle
verified**. Both final-source Oracle journeys remain required; prior WebFlux PASS
is not substituted for current execution. Failed attempts and partial phases
remain immutable in the raw archive, including dirty-source identities.

## Resource admission and owned cleanup

Final host samples: **9.699, 9.458, 9.656 GiB**, below 12 GiB. Docker capacity:
19.517 GiB available / 8 CPUs; free disks C/D: 62.914 / 1066.880 GiB. Only the
host-memory criterion failed. No bounded-admission retry, global configuration
change or interference with unrelated workloads followed.

The final attempt created no container, volume or consumer JVM. Independent
Docker queries for its exact ownership label confirmed no resources. Earlier owned
containers `msq-c4a7d351f68c`, `msq-bbec4ca1a2c5` and their `-data` volumes are absent;
both attempts' consumer JVMs are absent. WebFlux pools/threads/physical operations
and fixture cleanup passed; MVC finally-cleanup and process/container absence are
recorded separately from its unexecuted normal shutdown assertions. Evidence,
staged artifacts and dedicated local caches intentionally remain.

## Acceptance and limits

R06.1/R06.3 close only the demonstrated cheap facade/filter-chain checks and the
source-bound earlier WebFlux scenarios. Final two-stack Oracle security verification
is **open, blocked on at least 12 GiB available host memory**. This is not a complete
security audit. Real identity-provider integration, policy/revocation/tenant lifecycle,
other APIs/visits/replay, provider TLS/SSRF/secrets, retention, uncertain outcomes,
operations, capacity and remote distribution remain separate open requirements.
Historical independent cancellation remains FAILED; its current characterization
and producer full are NOT_RUN. No production acceptance is implied.

Raw artifacts: [archive](raw-evidence.zip), [file inventory](raw-manifest.json),
[checksums](SHA256SUMS.txt), [artifact provenance](artifact-manifest.json),
[machine-readable results](results.json). Run-scoped copies are retained under
`target/qm/consumer-security/{infra['attempt_id']}/`.
'''
(out/'README.md').write_text(report,encoding='utf-8')
matrix=root/'docs/quality/ACCEPTANCE-MATRIX.md';text=matrix.read_text(encoding='utf-8')
assert '- **H** —' in text
text=text.replace('- **H** —',f'''- **S** — consumer security fixture `{source}`, tree `{tree}`:
  default `{default_id}` (222 JUnit / 116 Python) and 5 MVC / 6 WebFlux
  cheap security methods PASS. Current Oracle attempt `{infra['attempt_id']}`
  BLOCKED at host-memory admission, journeys NOT_RUN. Earlier source 8e36028/run
  `143adeff-77ef-4864-ad9c-23ab46534c6c`: overall FAILED, WebFlux PASS
  (30 denials/four outcomes/32 concurrent identities), MVC fixture assertion FAILED.
  [Exact scope, earlier attempts and raw evidence](../../validation/qualification/2026-10-26-consumer-security/README.md).
- **H** —''')
old='| R06.1 | Tenant/binding/subject authority | F tenant-scoped core/store contracts | OPEN: application authorization before requests/events/visits/replay, negative cross-tenant threat-model tests; qualifiers are not permissions |'
assert old in text
text=text.replace(old,'| R06.1 | Tenant/binding/subject authority | F library contracts; S actual filter-chain/method checks and earlier Oracle WebFlux scoped read/refresh/event journeys | DONE for S cheap checks and source-bound WebFlux scenarios. OPEN: final-source two-stack Oracle verification (memory BLOCKED), real identity-provider/policy/revocation/tenant lifecycle, other APIs/visits/replay and broader threat model. Raw gateway/event publisher are trusted in-process capabilities; qualifiers are not permissions |')
old='| R06.3 | Invalid identity/schema/authority fails closed | F default contracts and schema checks | DONE for tested library checks; OPEN: end-to-end host authorization/cache-isolation/security acceptance |'
assert old in text
text=text.replace(old,'| R06.3 | Invalid identity/schema/authority fails closed | F library/schema checks; S missing grants/unknown scope/fresh-cache denials; earlier WebFlux 30 negative cases with unchanged protected side effects | DONE for declared F and executed S checks. OPEN: final-source two-stack Oracle verification, production identity/host integration, arbitrary identifiers/mappings and complete security acceptance |')
matrix.write_text(text,encoding='utf-8')
handbook=f'''## Secured application boundary — consumer evidence, 2026-10-26

Security fixture `{source[:7]}` uses unchanged staged 551427b JARs. Its default
and cheap security tests passed (MVC 5 / WebFlux 6). Final Oracle execution was
blocked by host-memory admission. Earlier source 8e36028's WebFlux journey passed
30 denial cases, four committed reconciliations and 32 concurrent HTTP identities;
MVC stopped on a response-status fixture assertion. [Exact results and limits](../validation/qualification/2026-10-26-consumer-security/README.md).

Use application-owned Spring Security filter chains **and method authorization**
before calling Model Sync. The executable
[MVC configuration](../validation/consumer-security/mvc/src/main/java/example/consumer/SecurityConfiguration.java)
and [reactive facade](../validation/consumer-security/webflux/src/main/java/example/consumer/ConsumerFacade.java)
use BOM-pinned Spring Security 7.1.1. Exact read/refresh/event permissions include
tenant, binding and subject. Unknown scope or missing authority has no default
tenant fallback. Policy lookup does not read protected model payloads.

Raw `SyncGateway`, internal model access and event publisher are trusted in-process
capabilities. External HTTP/service/event ingress must use the proxied authorized
facade. This is not a sandbox against application code holding raw references.
No broker delivery or DEAD replay was implemented. Generated in-memory accounts
and loopback HTTP Basic are test-only; production identity integration is open.
CSRF remains enabled: real clients obtain the framework token/session at `/csrf`;
cheap tests use Spring Security's test support.

WebFlux authorizes with Reactor SecurityContext, then schedules blocking model
access on `modelSyncPersistenceScheduler`, carrying a detached principal name.
Durable background work uses an explicit known-ID service scope; it must not rely
on the originating request SecurityContext. This fixture does not cancel accepted
intent after later grant revocation. Existing mapping/enlistment, raw mixed-transaction
rollback, auto-configuration, disabled mode and shutdown checks remain in the journeys.

[Fixture commands and boundary](../validation/consumer-security/README.md) describe
standalone staging/cheap tests and explicit small Oracle execution. Core/library
dependencies are unchanged. The [acceptance matrix](quality/ACCEPTANCE-MATRIX.md)
closes only demonstrated R06.1/R06.3 leaves. Final Oracle rerun requires resource
admission and fresh matching default evidence. Production NO-GO; real identity,
TLS/SSRF/secrets, retention, uncertainty, operations and distribution remain open.

---

'''
p=root/'docs/USER-HANDBOOK.md';p.write_bytes(handbook.encode()+p.read_bytes())
p=root/'TODO.md';text=p.read_text(encoding='utf-8');assert '## Still-open production subcriteria' in text
text=text.replace('## Still-open production subcriteria',f'''- [x] R06.1/R06.3 scoped security implementation and cheap checks: `{source[:7]}`,
  MVC 5 / WebFlux 6 methods. Earlier 8e36028 WebFlux Oracle journey passed 30 denials,
  four committed outcomes and 32 concurrent identities; its overall attempt remains FAILED.
- [ ] Final-source MVC/WebFlux Oracle security journeys: attempt `{infra['attempt_id']}`
  BLOCKED at 9.458–9.699 GiB host availability versus 12 GiB; both NOT_RUN. Prior MVC
  response-status assertion failures are preserved; correction awaits Oracle execution.
  [Scoped evidence](validation/qualification/2026-10-26-consumer-security/README.md).
  Real identity-provider/production authorization and broader R06 gates remain open.

## Still-open production subcriteria''');p.write_text(text,encoding='utf-8')
qm=f'''## Consumer authorization qualification — 2026-10-26

**Default and cheap security PASS; final Oracle admission BLOCKED; final Oracle
journeys NOT_RUN; producer full NOT_RUN; production NO-GO.**

Tested fixture `{source}`, tree `{tree}`, clean before/after.
Artifacts remain the unchanged 39-file set from 551427b. Accepted full
a0f46d7/report 8d07aa7 and consumers 551427b/report 50c9370 remain unchanged.

- Default `{default_id}`: approved project settings/task-owned repository,
  `clean verify`, build/qualification/collection exits **0/0/0**;
  **222 JUnit / 41 XML / 116 Python**. Core/trigger and execution audits passed.
- Standalone consumers: **5 MVC / 6 WebFlux cheap methods PASS**, both preparation
  exits 0. Current wrapper attempt `{infra['attempt_id']}` exited **2**:
  host samples **9.699, 9.458, 9.656 GiB**, below unchanged 12 GiB. Docker/disk
  checks passed. No current Oracle Maven execution or runtime receipt exists.
- Prior f206718/run `2b8e502f-31ca-4ded-bccb-93911f17bb11` and 8e36028/run
  `143adeff-77ef-4864-ad9c-23ab46534c6c`: **overall FAILED**, original
  wrapper/MVC/WebFlux exits **1/1/0**. Each WebFlux journey passed all 30 denial
  cases with unchanged protected side effects, four calls/four committed outcomes
  and 32 concurrent HTTP identities. MVC stopped after two initial outcomes on
  live 401 versus expected 403 assertions; later phases NOT_RUN. Failed cheap
  probes and partial evidence are retained. Current status-fixture correction
  is cheap-test verified; its Oracle execution remains open.
- No resources created by the blocked attempt; exact-label container/volume
  checks confirm absence. Both earlier attempts' owned containers, volumes and
  consumer JVMs were independently confirmed absent. No unrelated work stopped.

[Detailed evidence and raw archive](validation/qualification/2026-10-26-consumer-security/README.md),
[artifact hashes](validation/qualification/2026-10-26-consumer-security/artifact-manifest.json),
[acceptance matrix](docs/quality/ACCEPTANCE-MATRIX.md), [secured boundary](docs/USER-HANDBOOK.md).
Only demonstrated R06.1/R06.3 leaves close; final two-stack Oracle security remains
blocked. Real identity-provider/policy/revocation, TLS/SSRF/secrets, retention,
uncertainty, operations, capacity and distribution remain separate. Not a complete
security audit. No packaging/full/PIT/Gatling repeat, merge or publication.

---

'''
p=root/'QM.md';p.write_bytes(qm.encode()+p.read_bytes());assert p.read_bytes().endswith((base/'QM.original.md').read_bytes())
checks=[]
for name,cmd in [('docs',[sys.executable,'scripts/check-docs.py']),('architecture',[sys.executable,'scripts/check-architecture.py']),('diff',['git','diff','--check'])]:
 with (base/f'report-{name}.log').open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 checks.append({'command':cmd,'exit':code});assert code==0
c.write(base/'report-checks.json',checks)
files={};excluded={'m2-mvc','m2-webflux','staged','classes','test-classes','__pycache__','.git'}
allowed={'.md','.json','.xml','.txt','.log','.java','.py','.properties'}
for directory,dirs,names in os.walk(base):
 dirs[:]=[d for d in dirs if d not in excluded]
 for name in names:
  p=Path(directory)/name
  if p.suffix in allowed:files['attempts/'+p.relative_to(base).as_posix()]=p
for pattern in ['*security-r*.py','*security-final*.py','*security-consumers*.py','security-contracts*.py','security-status-regression.py','report-security-blocked.py']:
 for p in root.parent.glob(pattern):files['supervisors/'+p.name]=p
for p in [out/'README.md',out/'results.json',out/'artifact-manifest.json',root/'.mvn/qualification-central.settings.xml']:
 files['current/'+p.name]=p
entries=[];patterns=[rb'(?<![0-9a-fA-F])[0-9a-fA-F]{48}(?![0-9a-fA-F])',rb'Authorization[^\r\n]{0,30}Basic [A-Za-z0-9+/=]{16,}',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{30,}']
for name,p in sorted(files.items()):
 data=p.read_bytes();assert not any(re.search(pattern,data) for pattern in patterns),'Credential pattern in '+name
 entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
c.write(out/'raw-manifest.json',{'files':entries,'credential_pattern_scan':'PASS','prior_archive_hashes_verified':prior['archives'],'excluded':'Caches, staged binaries, classes; immutable original artifacts remain local'})
archive=out/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):z.write(p,name)
 z.write(out/'raw-manifest.json','raw-manifest.json')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for e in entries:assert hashlib.sha256(z.read(e['path'])).hexdigest()==e['sha256']
(out/'SHA256SUMS.txt').write_text(''.join(f'{c.digest(out/n)}  {n}\n' for n in ['raw-evidence.zip','raw-manifest.json','results.json','artifact-manifest.json']))
scoped=root/'target/qm/consumer-security'/infra['attempt_id'];scoped.mkdir(parents=True,exist_ok=False)
for n in ['README.md','results.json','artifact-manifest.json','raw-manifest.json','raw-evidence.zip','SHA256SUMS.txt']:
 shutil.copy2(out/n,scoped/('QM.md' if n=='README.md' else n))
print(json.dumps({'source':source,'tree':tree,'attempt':infra['attempt_id'],'status':'BLOCKED','original_wrapper_exit':2,'collection_exit':0,'evidence_validation_exit':0,'zip_bytes':archive.stat().st_size,'zip_entries':len(entries)+1,'sha256':c.digest(archive),'prior_archives_unchanged':len(prior['archives'])}))
