﻿from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd();base=root.parent/'qualification-evidence/security-consumers-20261026-r1';base.mkdir(exist_ok=False)
prior={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'archives':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('validation/qualification').glob('*/raw-evidence.zip')},'qm_sha256':hashlib.sha256(Path('QM.md').read_bytes()).hexdigest()}
(base/'preserved-baselines.json').write_text(json.dumps(prior,indent=2));(base/'QM.original.md').write_bytes(Path('QM.md').read_bytes())
workspace=base/'attempt-1';workspace.mkdir()
sys.path.insert(0,str(root/'scripts'));import consumer_security as s
s.stage(root,workspace,root.parent/'qualification-evidence/independent-consumers-20261026-r1/execution-r3')
raise SystemExit(s.prepare(root,workspace))
