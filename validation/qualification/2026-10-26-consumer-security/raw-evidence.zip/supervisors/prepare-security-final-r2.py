﻿import sys,shutil,json,time,subprocess
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import consumer_security as s;import consumer_artifacts as c
b=root.parent/'qualification-evidence/security-consumers-20261026-r1';w=b/'final-consumers-r2';w.mkdir(exist_ok=False)
s.stage(root,w,root.parent/'qualification-evidence/independent-consumers-20261026-r1/execution-r3')
m=json.loads((w/'artifact-manifest.json').read_text());results=[]
for mode in c.MODES:
 # Dedicated caches already seeded. Copy only prior public dependencies, preserving the immutable Model Sync bytes.
 previous=b/'final-consumers'/('m2-'+mode);cache=w/('m2-'+mode)
 for p in previous.iterdir():
  if p.name=='io':
   for child in p.iterdir():
    if child.name!='modelsync':shutil.copytree(child,cache/'io'/child.name,dirs_exist_ok=True)
  elif p.is_dir():shutil.copytree(p,cache/p.name,dirs_exist_ok=True)
c.write(w/'public-cache-source.json',{'source':'task-owned final-consumers public caches','modelsync_overwritten':False})
raise SystemExit(s.prepare(root,w))
