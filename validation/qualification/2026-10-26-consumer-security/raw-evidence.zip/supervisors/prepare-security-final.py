﻿import sys
from pathlib import Path
root=Path.cwd();sys.path.insert(0,str(root/'scripts'));import consumer_security as s
base=root.parent/'qualification-evidence/security-consumers-20261026-r1';w=base/'final-consumers';w.mkdir(exist_ok=False)
s.stage(root,w,root.parent/'qualification-evidence/independent-consumers-20261026-r1/execution-r3')
raise SystemExit(s.prepare(root,w))
