# Oracle observations: failed full attempt on 95f975f

Source `95f975fb60e29c45ab8cede1e9f725cbb189a17f`, tree `353dba3703288cd0ab827e35fbd26d794cf8d122`; run `f09fde00-1dc7-42f1-b2ce-a188401e6ee1`, attempt `9db520ad-05ac-4533-b6a8-e032e9c945be`. Overall **FAILED**, Maven/wrapper 1, 4483.02 seconds. These successful partial workload measurements are not a full qualification. OracleScaleIT failed because the plan collector did not recognize a reloaded cursor. Oracle JPA atomicity and Gatling did not execute in this attempt. Cleanup of both owned resources was verified.

## Million-row workload

One million seeds: 100k due, 900k future, four workers, pool eight, same 6 GiB / 4 CPU container, 20 ms quota spacing, 5/25 ms synthetic latency, failure every 17th/29th owner entry. Oracle Free itself reports two CPUs, SGA maximum 1.5 GiB and PGA target 512 MiB. These are not additional runner resources.

| Phase | Wall time | Key observations |
|---|---:|---|
| Seed | 1,860,099 ms | 500 commits; 2,257,658,812 redo bytes; aggregated checkpoint-incomplete wait 1,768.085 s |
| Warmup | 3,125 ms | 10 owner entries / 10 completed syncs |
| Measurement | 42,472 ms | 338 ledger attempts, 221 quota grants, 117 denials; 221 owner entries, 201 completed syncs |
| Cleanup | 1,990,721 ms | zero fixture rows remaining; 1,595,539,268 redo bytes; aggregated checkpoint-incomplete wait 1,659.200 s |

Total including warmup: 231 owner entries, 211 persisted projections/state, 13 synthetic 429s and seven timeouts. The measured completed-sync rate is 4.732530/s, not HTTP acceptance throughput. One million rows were seeded; one million reconciliations were not completed.

Measurement separate session counters: 34,328,646 consistent gets, 17,956 db block gets, nine physical reads, 4,708 executions, 5,311 parses, 2,677,784 redo bytes, 1,365 commits. The legacy sum (which includes physical reads as a separate term) is 34,346,574: 101,617.083 per ledger attempt; 155,414.362 per owner entry; 170,878.478 per completed sync. These denominators have different meanings.

V$SQL claim-selector delta: 913 executions, 338 rows returned, 34,321,607 buffer gets, zero disk reads; cumulative CPU 83.752106 s and elapsed 146.543446 s across concurrent executions. About 99.93% of runtime logical gets were attributable to the selector. SQL elapsed and session waits are aggregated and overlap; they are not the 42.472 s wall duration. The 117 quota denials (34.62% of attempts) repeated a claim before being denied. This does not assign per-denial CPU by trace. Quota SQL itself used relatively few gets. Lease-update elapsed in this window was only 83,013 microseconds, unlike the interrupted earlier attempt's checkpoint debt.

Actual claim plan `1899688225`, SQL `9pa35qd17fnm3`: OR concatenation through existing ready index, batched rowid access, then sort; about 99,789 eligible rows consumed to return one lease, roughly 101k buffers. Actual A-Rows are retained. No index, query or policy changed.

Run-one latency p50/p95/p99: 299/865/1,136 ms. Reconciliation lag: 1,888,729/1,907,787/1,910,256 ms, including the long seed; these are not visit latencies or an agreed production SLO. JVM end-used 319,685,120 bytes is not a measured memory peak.

## 100k fixture after million-row cleanup

The old fixture extents/history remain after delete. Seed: 122,078 ms. First committed lease: 7,446 legacy block-work units, 269 ms including lease assertions/commit (243 ms claim only). This cannot be called an optimization relative to the 4f44080 baseline's 132,950 / 7,411 ms: that baseline captured no actual plan and used different connection lifetimes.

Before gathered statistics, all-due/due-future/expired-future/mixed/all-future used bitmap OR/conversion of the existing lease index, plan `2044803774`. Warmed consistent gets were about 6.5k for due and 7.4k for expired/mixed/future. Even an all-future empty claim did work. After DBMS_STATS, the child execution counter reset from 15 to 1/2/3 and the plan hash changed. This attempt did not retain that new actual plan; its shape must not be inferred.

## Interpretation

The measured dominant steady-state cost is selecting/ordering eligible rows before admission. Quota-denial churn multiplies that cost. Seed and cleanup are dominated by redo/checkpoint-related work and must be accounted separately. Same declared workload and limits do not erase instrumentation, cache, statistics or table-layout differences. Production SQL/index optimization is deferred until a bounded selection change can also preserve skip-locked correctness, recovery fairness, provider limits and starvation protection. This investigation does not justify increasing resources, weakening the workload or claiming sustainable production capacity.
