"""Update the existing authorized PR description with measured results, never merge."""
import json
from pathlib import Path
import subprocess

base=Path(__file__).resolve().parent
root=base.parents[1]/'model-sync-starter'
repo='Tobia5/model-sync-starter'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
state=json.loads(subprocess.check_output(['gh','pr','view','1','--repo',repo,
    '--json','body,headRefName,headRefOid,state,mergedAt,url']))
assert state['state']=='OPEN' and state['mergedAt'] is None
assert state['headRefName']=='review/layered-refactor-qm-20261020' and state['headRefOid']==head
prior=base/'pr-description-before-final-update.md'
assert not prior.exists()
prior.write_text(state['body'],encoding='utf-8')
description=f'''## Shutdown / waits / process-recovery qualification

**Default PASS · Completed full FAILED · Final-source full BLOCKED · Production NO-GO**

- Final code [`8830c3f`](https://github.com/{repo}/commit/8830c3f6d2ac8483c35309e747e896131c64fcea), tree `10cb9835a8f925f9e45a2a437d9f637ee5668ca2`: local default exit0/88.439s, **117 JUnit /61 Python**, zero failures/errors/skips. Recorded102 goals contain no PIT/Gatling/Failsafe. [Default CI39761845131](https://github.com/{repo}/actions/runs/39761845131) passed on the identical tree.
- Completed full tested [`3564410`](https://github.com/{repo}/commit/3564410ad8e884509cecb0e530a8e3c16473eb29), tree `d0af02e4117463eae97a25108b537eb9650fd577`, run `d0500d1e-030b-425e-9b49-a35e214f7598`: **FAILED**, Maven/wrapper exit1, collector0;119 Surefire/45 Oracle tests, **two Oracle failures**, zero errors/skips. `-fae` collected independent suites while preserving failure. PIT160/162=98.765432% against unchanged85% gate; six semantic Gatling simulations/367 requests/zero HTTP errors. All seven accepted atomicity cases passed again.
- **Six independent-JVM crash cases passed** at acknowledged durable claim, owner response, real projection flush and committed completion, plus newer-generation/local-revision cases. Fresh connections/processes verified complete committed pairs, lease recovery and obsolete-token rejection. Five crashed reads plus five recovery reads are distinct from six final subject rows/five recovery applications; setup reads excluded.
- **Eleven of twelve I/O cases passed**, including bounded graceful/late-owner/locked-JPA shutdown, acquisition/read/owner/transaction controls and uncertain-COMMIT request/ack outcomes. Late stop correctly reported logical0 but physical1/owner1, then drained after controlled release with no late application. **Independent statement cancellation FAILED:** effective2s timeout, still in physical Oracle socket read after5001ms against unchanged5s/ORA-01013 gate. Passing network timeout does not substitute for this failure.
- Existing actual-worker160-row backlog20s gate failed in full after ten successful warmup completions. The later scoped worker diagnostic passed all ten phases (fixed160 completions16490ms; bounded9275ms). Commit8830c3f only adds failure endpoints, retaining the gate and original failure; no SQL/pacing redesign or speedup claim. Diagnostic is not full qualification.
- Final-source full rerun **BLOCKED before provisioning**: four host-memory samples17.49–17.85GiB, final read-only recheck16.644GiB, below unchanged6GiB Oracle +8GiB build +4GiB reserve. Wrapper/Maven and full suites NOT_RUN for that attempt; no borrowed reports. Docker had zero running containers. No resources were increased or unrelated workloads stopped.
- Approved local route retained the digest-pinned Oracle image,6GiB/4CPU caps, loopback ports, generated credentials/separate schemas, synthetic data and explicit project Central settings. All **seven** session-owned containers/volumes were independently confirmed absent. One million seeded intents produced **200 measured reconciliations/210 with warmup**, not one million completed syncs.

### Evidence and remaining gates

[Reviewed QM at report commit{head[:7]}](https://github.com/{repo}/blob/{head}/QM.md) · [raw evidence/index](https://github.com/{repo}/blob/{head}/validation/qualification/2026-10-22-shutdown-recovery/README.md) · [failure contract](https://github.com/{repo}/blob/{head}/docs/quality/FAILURE-CONTRACT.md).

Raw ZIP SHA256 `8c236668f6456fec19c919791c970ab292abe493f9172fd6724bd5f9462db49c`;1,479 files retain original full/diagnostic/default identities, exits, XML/HTML/JSON, partial failed evidence, resource refusal, cleanup and earlier failed attempts. Final report is a documentation/evidence commit, not a newly full-tested source.

Accepted full-tested [`fad6874`](https://github.com/{repo}/commit/fad6874c9fa0e0a16ed7d542cace11ea89a991e1) and [pinned Q4 QM](https://github.com/{repo}/blob/0f04ff91b7aaa0c72c54c42bd169ca5a6f061ef9/QM.md) remain unchanged; prior root report retained verbatim and all four earlier evidence ZIPs hash-verified. Parent gates remain OPEN: independent statement bound, final-source full rerun, saturated-worker/shared-host recovery, multi-process contention, real provider budgets, operational/security and consumer/supply-chain criteria. Headless coordinator crash tests are not continuous-worker pod-crash qualification. First scope stays known-ID owner-to-Oracle/JPA. No broad refactor, bulk-owner/vendor/inventory feature, main change, merge, workflow bootstrap/dispatch or package publication.
'''
body=base/'pr-description-final.md'
body.write_text(description,encoding='utf-8')
subprocess.run(['gh','pr','edit','1','--repo',repo,'--body-file',str(body)],check=True)
verified=json.loads(subprocess.check_output(['gh','pr','view','1','--repo',repo,
    '--json','headRefOid,state,mergedAt,body,url']))
assert verified['headRefOid']==head and verified['state']=='OPEN' and verified['mergedAt'] is None
assert verified['body'].replace('\r','').rstrip()==description.replace('\r','').rstrip()
print(json.dumps({k:v for k,v in verified.items() if k!='body'}))
