"""Read-only admission check using this session's unchanged 6+8+4 GiB budget."""
import json
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
root = base.parents[1] / 'model-sync-starter'
record = {'observed_utc':datetime.now(timezone.utc).isoformat(),
          'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
          'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),
          'oracle_budget_gib':6,'build_budget_gib':8,'reserve_gib':4,
          'required_host_available_gib':18,'samples':[],
          'resource_change':'NONE; no unrelated process/container changes; no Docker global settings changes'}
for attempt in range(4):
    sample = json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',
        "$m=Get-CimInstance Win32_OperatingSystem; [ordered]@{observed_utc=(Get-Date).ToUniversalTime().ToString('o'); host_available_gib=[math]::Round($m.FreePhysicalMemory/1MB,3)} | ConvertTo-Json -Compress"],text=True))
    record['samples'].append(sample)
    if sample['host_available_gib'] >= 18: break
    if attempt != 3: time.sleep(15)
record['docker'] = json.loads(subprocess.check_output(['docker','info','--format',
    '{"server":"{{.ServerVersion}}","cpu":{{.NCPU}},"memory_bytes":{{.MemTotal}},"running_containers":{{.ContainersRunning}}}'],text=True,timeout=15))
record['disk_free_gib'] = json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',
    "Get-PSDrive -Name C,D | ForEach-Object { [ordered]@{drive=$_.Name;free_gib=[math]::Round($_.Free/1GB,3)} } | ConvertTo-Json -Compress"],text=True))
record['status'] = 'PASS' if record['samples'][-1]['host_available_gib'] >= 18 else 'BLOCKED'
record['reason'] = 'Existing session memory budget satisfied' if record['status']=='PASS' else 'Available host memory below unchanged 18 GiB session planning budget; no Oracle provisioning attempted'
target = base / ('capacity-before-full-' + record['source_sha'][:7] + '.json')
with target.open('x',encoding='utf-8') as output: output.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(0 if record['status']=='PASS' else 2)
