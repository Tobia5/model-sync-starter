"""Whole-owned-container resource snapshots; never database/session work counters."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

base=Path(__file__).resolve().parent
root=base.parents[1]/'model-sync-starter'
sys.path.insert(0,str(root/'scripts'))
from run_evidence import current
context=current(root)
assert context['run_id']=='e88fc1de-755e-470c-a7f7-15c3c7a4f13d'
path=base/'resources-resume-08bd190.json'
record=json.loads(path.read_text()) if path.exists() else {**context,
    'scope':'WHOLE_CONTAINER_SNAPSHOTS_NOT_SELECTOR_SESSION_OR_CURSOR_DELTAS','samples':[]}
assert record['run_id']==context['run_id']
sample={'observed_utc':datetime.now(timezone.utc).isoformat(),
    'container':json.loads(subprocess.check_output(['docker','stats','--no-stream','--format','{{json .}}','msq-3de5da8e40a9'],timeout=15)),
    'host_available_gib':float(subprocess.check_output(['powershell.exe','-NoProfile','-Command',
        '[math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory/1MB,3)'],text=True).strip().replace(',','.')),
    'disk_free_gib':json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',
        "Get-PSDrive -Name C,D | ForEach-Object { [ordered]@{drive=$_.Name;free_gib=[math]::Round($_.Free/1GB,3)} } | ConvertTo-Json -Compress"],text=True))}
record['samples'].append(sample)
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(sample))
