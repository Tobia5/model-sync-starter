"""Retain only the current source's read-only default-QM CI artifact."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

base=Path(__file__).resolve().parent
repo='Tobia5/model-sync-starter'
run=39761845131
artifact=12418985741
def api(path): return json.loads(subprocess.check_output(['gh','api',path]))
metadata=api(f'repos/{repo}/actions/runs/{run}')
assert metadata['conclusion']=='success' and metadata['head_sha']=='8830c3f6d2ac8483c35309e747e896131c64fcea'
raw=subprocess.check_output(['gh','api',f'repos/{repo}/actions/artifacts/{artifact}/zip'])
destination=base/f'ci-default-{run}'
destination.mkdir(exist_ok=False)
files={}
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    assert archive.testzip() is None
    for name in archive.namelist():
        relative=Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts
        if name.endswith('/'): continue
        target=destination/relative; target.parent.mkdir(parents=True,exist_ok=True)
        data=archive.read(name); target.write_bytes(data)
        files[relative.as_posix()]=hashlib.sha256(data).hexdigest()
evidence=list(destination.rglob('evidence.json'))
assert len(evidence)==1
document=json.loads(evidence[0].read_text())
commit=api(f'repos/{repo}/commits/{document["source_sha"]}')
assert commit['commit']['tree']['sha']==document['source_tree']=='10cb9835a8f925f9e45a2a437d9f637ee5668ca2'
assert any(p['sha']==metadata['head_sha'] for p in commit['parents'])
assert document['runs']['default']['status']=='PASS'
manifest={'source_sha':document['source_sha'],'source_tree':document['source_tree'],
    'run_id':document['evidence']['attribution'],'scope':'CI-default',
    'command_exit':0,'qualification':'DEFAULT_PASS_ONLY','head_sha':metadata['head_sha'],
    'url':metadata['html_url'],'artifact_id':artifact,'artifact_zip_sha256':hashlib.sha256(raw).hexdigest(),
    'artifact_bytes':len(raw),'files_sha256':files}
(destination/'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files_sha256'}))
