# Model Sync PR #1: shutdown / waits / process crash session

Only Model Sync. Existing review branch `review/layered-refactor-qm-20261020`.
Started clean at report head 0f04ff9; immutable full-tested fad6874/tree a530a2
and ZIP af3434238eafdd9f3064012a5d41bf7012c19499e02146fadff7072129afe7aa
remain untouched. No merge/main/package publication; local Docker route already authorized.
No agents or other-project instructions used.

Contract committed BEFORE implementation: ebeb615, docs/quality/FAILURE-CONTRACT.md.
Worker changes 7761ce7 and d57b1ac: bounded stop, distinct physical/logical
tracking, cancellation fence, uncancelled async-stage lifetime, physical owner
capacity, truthful DRAINED/TIMED_OUT and refusal to restart unresolved work.
Added shutdown-timeout 5s (positive/max5min), preserves pacing/SQL/core policies.

Test/tooling 4b537bf: six real independent JVM crash cases, twelve Oracle I/O
cases, full-only; --recovery-diagnostic selects eighteen tests, no big seed.
Fresh source/run-bound partial JSON + gate, default cheap guards/config tests.

Observed failed diagnostic d57b1ac run3ec2f027... (folder6cd9bfbc...):
1/6 crash PASS, five failures + cleanup error, I/O NOT_RUN. Actual demo YAML
overrode builder default ddl-auto/lease settings, recreating fixture table.
0add491 fixes precedence using command-line settings, refuses non-validate
DDL BEFORE JPA and adds a real-YAML default regression. b05c195 verifies
checkpoint work ID and cleans only own rows after each case; scopes lock wait
to active blocking sessions. Subsequent diagnostic b05c195 runf3c28d49...:
all SIX process cases PASS, seven I/O PASS/five FAILED: relay rejected actual
@host URL and JDBC statement cancellation exceeded 5s observation bound.
Both attempts retain immutable raw data and independent cleanup receipts.

98bed98 fixes approved URL forms with negative parsing tests, uses only owned
RST listener for unavailable connection, and fixture-only oracle.net.disableOob
true for in-band cancellation (TCP relay cannot carry OOB). Budgets unchanged.
98a811f injects coordinator Clock into auto-configured physical-capacity retry,
tests fixed-clock due time and avoids DB-clock reads under lifecycle monitor.
Latest clean source SHA98a811fce4036da462cbdbd9774362135949bad4,
tree77982a13587030bd3b39339cbfe3921d234913d1.

Latest DEFAULT PASS: default-be9032f0-f10a-41b9-b5dd-4c1ba1763a62,
run d6d46277-c86f-4935-88e2-758493d76f50, exit0, 58.264s.
Prior clean default PASS b05c195/0add491/d57b1ac/4b537bf retained separately.
Development Python import/compiler errors retained, not qualification.

CURRENT third diagnostic: diagnostic-5e30c250-63c2-4905-b5b2-623e0ea76a8b,
source98a811f, started2026-10-22T07:39:45Z, exec session90540 still running
at this note. Use write_stdin; monitor bounded JSON and log lines only.
Do not change source while this attempt is running/being archived.

External session.py is copied/reviewed from prior SAME Model Sync session,
selects --recovery-diagnostic; approved Maven Central settings used in nested
wrapper. mode default/diagnostic/full, bounded600/1200/10800s. Fresh raw archives
and source/run digests, preserves original exit. No active full run yet.
verify_cleanup.py only independently checks recorded OWNED container/volume
absence, never deletes. Both failed diagnostic resources independently absent.
Capacity check before Oracle: Docker29.8.2/8CPU/~23.47GiB; host24.4GiB free;
C133GiB,D1070GiB free, zero running containers, unchanged6GiB/4CPU caps.

NEXT: finish diagnostic, inspect actual failures and fix narrowly if needed.
After all final code edits: clean default PASS then full via session.py full.
Do not claim diagnostic as full. Keep existing7 atomicity/selection/quota/PIT85%
scope/Gatling/million workload unchanged. Full historically takes~130min,
mostly million-row seeding; do not restart it per fault edit or count seed as
completed syncs. Preserve source until all evidence/provenance is archived.
Then offline bash scripts/test-triggers.sh sequentially; source-bound package
new raw ZIP, exact QM+TODO leaves and parent gates OPEN/production NO-GO.
Preserve old QM verbatim under historical heading. Push focused commits only
to existing branch after checks; update PR DESCRIPTION with exact code/report
identities and links, verify remote/CI. Nothing new pushed as of this note.

## Later progress (supersedes CURRENT above)

Third diagnostic source98a811f run9e759cad-b9ba-441e-81c6-8cfc36a901cb,
folder5e30c250..., exit1/168.973s: SIX crash PASS, ELEVEN of12 I/O PASS.
Both actual uncertain-COMMIT transport cases passed (old complete state before
forwarded commit, new complete state after ack loss). Network read2017ms,
commit loss2019/2049ms, owner socket257ms, transaction2121ms; bounded physical
late owner/JPA shutdown and graceful drain passed. Sole remaining failure:
JDBC statement timeout2s under locked DML did not finish within5s Future.get.
Changing fixture-only disableOob did not fix it; keep FAILED, do NOT substitute
read timeout for independent statement-cancel proof or weaken time/error gate.

Committed631c22a49cba27e7d3cdcbfedc69942f67a6c8b0,
treea3c3ac8f36c28536a47521c2b66506b001a0fa1b: instrumentation ONLY for failing
statement case, same SQL/2s timeout/5s bound/requiredORA1013; records actual
statement.getQueryTimeout and bounded stack frames of ONLY owned executor and
OracleTimeout thread in raw JSON before cleanup. Root default PASS, run
916ceb52-407d-4838-8ff5-afefdde99657,59.543s, folderdefault-5e9fd20c....
FOURTH diagnostic currently running exec session6087,
folderdiagnostic-cedf3d61-f869-47c8-bf61-f9a3ec4a04ad,
source631c22a clean, started2026-10-22T07:46:29Z. As of07:47:37Z no I/O JSON
yet (setup+six crash cases). Do not edit source until archived.

Official pinned Oracle API/bytecode confirms query timeout is cancellation
attempt, not unconditional operation termination. javapOracleStatement shows
queryTimeout*1000 registered in OracleTimeout; query timeout callback diagnostic
will distinguish ignored setting from blocked driver cancellation. Need inspect
actual captured stack before deciding a repair. Never weaken gate to pass.
All previous owned diagnostic containers/volumes independently absent, including
msq-753693ab1903. Baseline archives still untouched. No full run started yet.

## FINAL CODE AND ACTIVE FULL (supersedes all above current-state lines)

Fourth diagnostic source631c22a run16aaa297-87bd-4811-b017-b788e04e7a2c
FAILED: same6 crash/11 I/O PASS; actual effectivequerytimeout2, elapsed5002ms,
owned executor stack inOracleNIO socket read while OracleTimeoutPollingThread
sleeping. Actualdriver property verified via pinned JAR/public Oracle docs;
disableOob did not resolve. Cleanupmsq-474ac6d264ba independently absent.
226e4eb makes failed DML probe rollback-only instead of autocommit: always
rolls back even when observation deadline fails, sameSQL/2s/5s/error1013.
Fifth diagnostic run87839e65-110e-4086-9aa4-269ed8c1146f folder2dd51ef6...
FAILED168.975s,6crash+11I/O PASS/1FAIL: effective2s/stillreading5003ms in explicit
local transaction. Do not relabel this failure as network/owner timeout PASS.

FINAL code/source (pushed and remote confirmed):
3564410ad8e884509cecb0e530a8e3c16473eb29
tree d0af02e4117463eae97a25108b537eb9650fd577, clean digest e3b0c442...b855.
Adds full Maven-fail-at-end(-fae) so independent suites still execute on fail,
preserves failing exit/all gates. Strengthens actual owned worker-thread
termination and uncertainCOMMIT persisted status/outcome checks. Cheap async
test advancesproviderclock2ms to expose physicalcapacity (not quota denial).
Failure contract records unresolved gate; never lowered2s/5s/1013 or workloads.

FINAL DEFAULT PASS: run7d71b163-e3f8-4a92-a5da-99ae126c7a96,
folderdefault-23cbacc6-43f5-4d0d-993a-11d68d3cb423, exit0/62.11s.
Recorded default audit102goals/noneexpensive. Likely117JUnit/61Python; derive
actual counts from raw evidence, don't assume. Code CI PASS confirmed:
https://github.com/Tobia5/model-sync-starter/actions/runs/39744413739
head3564410; download only qm/raw report artifact if needed, no binary upload.

ACTUAL FULL NOW RUNNING:
exec session69794 (use write_stdin, not functions.wait)
folderfull-40ae3c64-186c-4716-ab1f-06558fc705c7
started2026-10-22T07:59:54.346368Z,10800s bound. Commandpython -u
scripts/full-oracle-container.py; reviewedCentral settings and approved ACKs
invocation-only, externalOraclecredentials cleared. Wrapper now invokes
mvnw.cmd -B -ntp -s <reviewedsettings> -fae -Pfull clean verify.
Resourcepreflight capacity-before-full-3564410.json:24.465GiBfreehost,
Docker8CPU/25201700864B, C127.575,D1070.096GiB free,0runningcontainers,
6GiBOracle+8GiBbuild+4GiBreserve, caps unchanged. No source edits until
full evidence and provenance collected. OracleCapacityIT active as of
2026-10-22T08:02:15Z; this suite seeds1million, historically100min+.
No actual new full result yet; statement gate may still FAIL. Must report it
truthfully, with passing independent suites and raw counts retained.

PR DESCRIPTION updated and independently verified normalized body equals
pr-description-current.md (removeCR; Windows duplicatesCRinJSON), status
DefaultPASS/newFullRUNNING/productionNO-GO. Previous whole body saved separately
pr-description-before-shutdown.md/json. update_pr.py originally asserted falsely
due CRnormalization; actual edit succeeded, bounded compareprovedequal3234chars.
Remote remainsOPEN/unmerged; no main/merge/packages/dispatch.

External collect_provenance.py written to accept exact completed PASS/FAILED
attempt, required --run-id and --attempt, binds source/context/report/infra/
archive, records artifact hashes only and NOT_BUILT instead of staleJAR.
Do NOT use old worker-pacing collect-build-provenance.py (requiresPASS) or old
packager (alsoPASSonly). Write a new failure-aware packager after full.

NEXT: monitor full every~45s, keep commentary at least every60s. Don't run
SQLfullrowcount progress queries or add load; use bounded log/JSON/ownDockerstats.
After completed wrapper: independentcleanup via verify_cleanup.py (fifth still
needs receipt), collectexactprovenance, offlinebashtriggers sequentially,
archivefreshpartialevenifFAILED. Then rootQMprefixnew +oldQMverbatim; TODO
completed scoped leaves only, parentgates OPEN, statementdeadline OPEN/FAILED
unless actual full suppliesPASS(repeated diagnostic failures still retained).
Package raw artifacts source-bound; secret-pattern/integrity scans; docschecks;
report-onlycommit push existing branch, PR description finalactualresults,
verify remoteCI/OPEN/unmerged. FullGitHubworkflow stillNOT_RUN/unregistered.
No current docs/QM/TODO edits yet after356 source. No baseline evidence changed.

## Live full details / prepared delivery tools

Current full run ID d0500d1e-030b-425e-9b49-a35e214f7598,
started_ns1792656062575868700; source3564410/tree d0af02... frozen/clean.
Container msq-1b7391d4318b, own label attempt90354641-cbe9-4750-abd3-1022c9816ce4,
volume expected msq-1b7391d4318b-data. Narrow observation confirmed pinned image,
memory6442450944, nanoCPUs4000000000, loopback127.0.0.1:59262->1521.
full-container-observation-verified.json is correct. Initial observation.json
retains a failed PowerShellGo-template key lookup (attempt{}); do not use that
field as evidence. No environment/credentials inspected or printed.

As of2026-10-22T08:35:18Z full is STILL OracleCapacityIT SEEDING500000/1000000.
These are setup rows, NOT completed syncs. No source edits, resource changes or
SQLprogresscount queries. Same approved bounds10800s/6GiB4CPU. Progress after
300k slows, prior same workload seed~100min. Poll exec69794 and bounded own log,
send commentary <=60s (avoid long thinking gaps); no need repeat tests now.

CURRENT full PIT independently checked fresh/source-bound via pit_counts:
160KILLED/1SURVIVED/1NO_COVERAGE =98.76543209876543%, otherstatuses0, gatePASS.
Saved pit-current-full-partial.json, explicitly PARTIAL_NOT_FULL.

Final local DEFAULT actual117JUnit/25XML/0failerrorSkip,61Python guards;
default-final-summary.json binds source356/run7d71... . Code CI39744413739
PASS; downloaded ONLY QM artifact12411485728 (139308B), neverJARartifact.
ci-default-39744413739/archive-manifest.json current receipt has run
b358c2bf-515f-47da-b825-bf05bfabaa90, actualmergeSHA
bce795e8d79866b47e7e5e840149a3819201f68b, exactsame tree d0af02... . GitHubAPI
verifiedparentsa555+356.117JUnit0bad,58rawfiles.

verify_cleanup.py now uses narrow Docker --formatId/Name even if resource
unexpectedly exists. Fifth failed attempt also independently absent:
msq-317f14d26e37 +volume at08:12:33Z. All5 prior diagnostic cleanupPASS.

Prepared external helpers (do NOT run until full wrapper/supervisor finishes):
- collect_provenance.py --run-id d050... --attempt <exact full40ae...absolute>;
  unlike OLD worker-pacing helper acceptsFAILED, requires source/run/exitmatch,
  records11libraryJARhashes iffresh(no binaries), effectivePOMs, config/toolversions.
- extract_results.py same --attempt/--run-id; derives exactcurrent119?Surefire/
  45?Oraclecounts fromactualXML; do not assume. Reads current archived faults,
  workload/worker/Gatling, infrastructure and independentcleanup. Produces
  reviewed-summary-d050....json, preservesFAILED and rawcounts.
- package_evidence.py --run-id/--full-attempt; checks archivedmanifest hashes,
  packages eachattempt separately +CImetadata/provenance/helpers, needs final
  independentcleanupreceipt. Failure-aware, neverpromotesfailedtoreleasePASS.
  Secret scans48hex generatedcreds/passwordXML/sensitiveXMLproperty names and
  values; fails private review if matched(no secret values printed). No nested
  ZIP/JAR/class/pyc allowed. Outputs publication-d050... artifact-index/json/zip.
  It includes unqualified initial red/focused logs explicitly marked dirtydigest
  NOT_CAPTURED; never counts them as qualification. Preserve oldbaselineZIPs.

update_pr.py old verification assertion false dueCR handling; actual edit
independently matched3234normalized chars. Fixed compare removesCR entirely.
PRcurrentlyDefaultPASS/newFullRUNNING/prodNO-GO, code356 pushed. Don't rerun
progress helper after final. Create final updater with actualresults after
report-onlycommit pushed; body must distinguish codeSHA vs reportcommit.

Important scope in finalQM: crash JVM is HEADLESS public coordinator
claim/prepare/fetch/finish using real starter JpaTransactionManager/JPA/JDBC;
it is not a continuousReactor-child crash. LiveI/O tests instantiate the real
Reactor worker class with1lane/1+1schedulers against that configuredcoordinator;
accepted Q4 autoConfigured4lane probe repeats in full separately. Pool case
proves fixture-owned Hikari acquisition and reuse (not saturated-worker e2e).
Document these limits; do not overclaim arbitraryhost/physicalHTTP clients.
UncertainCOMMIT tests supply a detached response, use real TCP stalls and fresh
status/outcome reads; not an ownerHTTPthroughput claim.

NEXT afterfull: verifyowncleanup, collectexactprovenance BEFORE any tracked
edits, offlinebashtriggerssequentially(receipt), extractcounts, packagefiles,
new validation/qualification/2026-10-22-shutdown-recovery directory, rootQM
currentprefix+old0fQMverbatim, TODO completed SCOPED leaves only/allparentsOPEN.
Likely fullFAILED(statement gate) but use actualresult. No gate weakening,
no extra source implementation after full unless concrete requiredrepair.
Default/docchecks on report edits then focusedreportcommit push, PRfinalbody,
verifyremotehead/open/unmerged and report-head defaultCI. No merge/packages.
