"""Bounded, nonsecret progress for this one owned full attempt."""
import json
from pathlib import Path
import time

base=Path(__file__).resolve().parent
attempt=base/'full-e7a832ce-9b6e-481d-8c94-d01aee836ffe'
launch=json.loads((attempt/'launch.json').read_text())
raw=(attempt/'build.log').read_bytes()
try: log=raw.decode('utf-8')
except UnicodeDecodeError: log=raw.decode('cp1252')
interesting=[line[:260] for line in log.splitlines() if any(word in line for word in
    ('Running io.', 'Tests run:', 'BUILD SUCCESS','BUILD FAILURE','Blocked','BLOCKED','Completed full',
     'Generated 162','Starting Oracle','Total time:','Model Sync infrastructure error',
     'Oracle capacity fixture seeded'))]
value={'elapsed_minutes':round((time.time_ns()-launch['supervisor_launch_ns'])/60e9,2),
       'log_bytes':len(raw),'recent':interesting[-1:]}
result=attempt/'result.json'
if result.is_file(): value['result']=json.loads(result.read_text())['exit']
print(json.dumps(value))
