"""Read-only independent absence checks, limited to this session's recorded resources."""
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
for attempt in sorted(base.iterdir()):
    evidence = attempt / 'target/qm/oracle-container.json'
    receipt = attempt / 'independent-cleanup.json'
    if not evidence.is_file() or receipt.exists():
        continue
    record = json.loads(evidence.read_text())
    container, volume = record['container_name'], record['volume_name']
    assert container.startswith('msq-') and volume == container + '-data'
    result = {'attempt_id': record['attempt_id'], 'run_id': record['run_id'],
              'source_sha': record['source_sha'], 'observed_utc': datetime.now(timezone.utc).isoformat()}
    for kind, name, absence in [('container', container, ('no such object', 'no such container')),
                                ('volume', volume, ('no such volume',))]:
        checked = subprocess.run(['docker', *(['volume'] if kind == 'volume' else []), 'inspect',
                                  '--format', '{{.Name}}' if kind == 'volume' else '{{.Id}}', name],
                                 capture_output=True, text=True)
        absent = checked.returncode != 0 and any(term in checked.stderr.lower() for term in absence)
        result[kind] = {'name': name, 'inspect_exit': checked.returncode, 'absent': absent}
    result['status'] = 'PASS' if all(result[k]['absent'] for k in ('container', 'volume')) else 'RESIDUAL'
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    assert result['status'] == 'PASS', 'Session-owned resource remains; no deletion attempted by this checker'
