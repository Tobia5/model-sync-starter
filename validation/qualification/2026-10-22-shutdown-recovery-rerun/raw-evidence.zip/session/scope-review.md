# Scope review for source 3564410

This is a source/responsibility review, not an independent approval or a test
result. Runtime outcomes must come from the exact run's reports.

- `ReactorSyncWorker` retains the existing claim -> prepare -> owner -> finish
  order and lane pacing. Shutdown closes new claim admission, allows bounded
  drain, then cancels subscriptions. `WorkerExecution` fences callbacks that
  would start after their subscription closed; the operations monitor does not
  cover database calls. A separately injected clock supplies capacity deferrals.
- Blocking call lifetime and uncancelled async-stage lifetime are tracked apart
  from reactive in-flight accounting. Physical owner capacity is held until the
  callable/stage completes. An arbitrary third-party future is not a socket
  lifecycle contract: deployments must qualify their owner transports. DRAINED
  describes the tracked work; TIMED_OUT retains unresolved counts and blocks
  restart until quiescent. Global schedulers/datasources are not reconfigured.
- Process-crash tests use independent headless JVMs through the actual starter's
  configured coordinator, JPA projection, JDBC ledger and JpaTransactionManager.
  They explicitly call claim/prepare/fetch/finish and wait at acknowledged
  checkpoints. They are not a continuous Reactor child-process crash test.
- Live shutdown tests use the real Reactor worker class, one lane and explicit
  one-thread schedulers with the configured coordinator, against real Oracle.
  Controlled TCP owner endpoints verify callable/client/server cleanup. The
  accepted four-lane auto-configured worker benchmark repeats separately in full.
- The pool probe establishes fixture-owned Hikari acquisition timeout/reuse;
  it does not prove every saturated-worker deployment or an exhausted application
  pool's end-to-end recovery. Transaction timeout is a cooperative deadline.
  Independent query cancellation is a separate gate; a passing network timeout
  must not be substituted for it. Uncertain COMMIT probes supply a detached
  response and use real network stalls plus fresh persisted-state observations.
- Only owned child processes, sockets, tables/rows, schedulers and pools are
  created/stopped. Queue SQL, lease/generation/local-revision logic and provider
  admission are unchanged. Test helpers remain outside published consumer
  dependencies. All handwritten Java types have separate files.

Keep parent release gates open for unsupported host configurations, arbitrary
HTTP future implementations, database statement cancellation until it passes,
racing inserts, multi-process contention/multi-pod SLOs, real provider retry and
fanout budgets, operational/security controls and consumers/supply chain.
