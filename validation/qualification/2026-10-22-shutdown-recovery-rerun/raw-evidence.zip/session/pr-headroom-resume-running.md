## Headroom restored: new full verification RUNNING

Current exact tested source `08bd1906e54d6a182a1a7d2c9473fc255f7038fa`, tree `a5f5e717c9fcd3331c139558508c312aff901d60`, clean change digest. Fresh local default PASS: run `2bb7a10f-29a9-4b30-9313-48aa2d1960d9`, exit0/65.559s,117 JUnit tests; required guards/lifecycle checks retained.

User reported restored headroom; read-only admission found21.648GiB versus the unchanged18GiB planning budget. The approved `scripts/full-oracle-container.py` full route is running from12:09:37UTC with the same pinned image,6GiB/4CPU caps,loopback port,generated credentials,separate schemas and explicit project Central settings. Attempt `3dabb75d-761d-427a-88f7-5126042f4b90`. No gates/workloads/production code were changed. No new full outcome or production readiness is claimed. Original failure and resource-blocked attempts below remain historical and unchanged; final fresh reports/cleanup will be linked when collected.

---

## Preserved previous qualification status

## Shutdown / waits / process-recovery qualification

**Default PASS · Completed full FAILED · Final-source full BLOCKED · Production NO-GO**

- Final code [`8830c3f`](https://github.com/Tobia5/model-sync-starter/commit/8830c3f6d2ac8483c35309e747e896131c64fcea), tree `10cb9835a8f925f9e45a2a437d9f637ee5668ca2`: local default exit0/88.439s, **117 JUnit /61 Python**, zero failures/errors/skips. Recorded102 goals contain no PIT/Gatling/Failsafe. [Default CI39761845131](https://github.com/Tobia5/model-sync-starter/actions/runs/39761845131) passed on the identical tree.
- Completed full tested [`3564410`](https://github.com/Tobia5/model-sync-starter/commit/3564410ad8e884509cecb0e530a8e3c16473eb29), tree `d0af02e4117463eae97a25108b537eb9650fd577`, run `d0500d1e-030b-425e-9b49-a35e214f7598`: **FAILED**, Maven/wrapper exit1, collector0;119 Surefire/45 Oracle tests, **two Oracle failures**, zero errors/skips. `-fae` collected independent suites while preserving failure. PIT160/162=98.765432% against unchanged85% gate; six semantic Gatling simulations/367 requests/zero HTTP errors. All seven accepted atomicity cases passed again.
- **Six independent-JVM crash cases passed** at acknowledged durable claim, owner response, real projection flush and committed completion, plus newer-generation/local-revision cases. Fresh connections/processes verified complete committed pairs, lease recovery and obsolete-token rejection. Five crashed reads plus five recovery reads are distinct from six final subject rows/five recovery applications; setup reads excluded.
- **Eleven of twelve I/O cases passed**, including bounded graceful/late-owner/locked-JPA shutdown, acquisition/read/owner/transaction controls and uncertain-COMMIT request/ack outcomes. Late stop correctly reported logical0 but physical1/owner1, then drained after controlled release with no late application. **Independent statement cancellation FAILED:** effective2s timeout, still in physical Oracle socket read after5001ms against unchanged5s/ORA-01013 gate. Passing network timeout does not substitute for this failure.
- Existing actual-worker160-row backlog20s gate failed in full after ten successful warmup completions. The later scoped worker diagnostic passed all ten phases (fixed160 completions16490ms; bounded9275ms). Commit8830c3f only adds failure endpoints, retaining the gate and original failure; no SQL/pacing redesign or speedup claim. Diagnostic is not full qualification.
- Final-source full rerun **BLOCKED before provisioning**: four host-memory samples17.49–17.85GiB, final read-only recheck16.644GiB, below unchanged6GiB Oracle +8GiB build +4GiB reserve. Wrapper/Maven and full suites NOT_RUN for that attempt; no borrowed reports. Docker had zero running containers. No resources were increased or unrelated workloads stopped.
- Approved local route retained the digest-pinned Oracle image,6GiB/4CPU caps, loopback ports, generated credentials/separate schemas, synthetic data and explicit project Central settings. All **seven** session-owned containers/volumes were independently confirmed absent. One million seeded intents produced **200 measured reconciliations/210 with warmup**, not one million completed syncs.

Report/evidence commit08bd190 also passed [default CI39763458161](https://github.com/Tobia5/model-sync-starter/actions/runs/39763458161). This is default verification only.

### Evidence and remaining gates

[Reviewed QM at report commit08bd190](https://github.com/Tobia5/model-sync-starter/blob/08bd1906e54d6a182a1a7d2c9473fc255f7038fa/QM.md) · [raw evidence/index](https://github.com/Tobia5/model-sync-starter/blob/08bd1906e54d6a182a1a7d2c9473fc255f7038fa/validation/qualification/2026-10-22-shutdown-recovery/README.md) · [failure contract](https://github.com/Tobia5/model-sync-starter/blob/08bd1906e54d6a182a1a7d2c9473fc255f7038fa/docs/quality/FAILURE-CONTRACT.md).

Raw ZIP SHA256 `8c236668f6456fec19c919791c970ab292abe493f9172fd6724bd5f9462db49c`;1,479 files retain original full/diagnostic/default identities, exits, XML/HTML/JSON, partial failed evidence, resource refusal, cleanup and earlier failed attempts. Final report is a documentation/evidence commit, not a newly full-tested source.

Accepted full-tested [`fad6874`](https://github.com/Tobia5/model-sync-starter/commit/fad6874c9fa0e0a16ed7d542cace11ea89a991e1) and [pinned Q4 QM](https://github.com/Tobia5/model-sync-starter/blob/0f04ff91b7aaa0c72c54c42bd169ca5a6f061ef9/QM.md) remain unchanged; prior root report retained verbatim and all four earlier evidence ZIPs hash-verified. Parent gates remain OPEN: independent statement bound, final-source full rerun, saturated-worker/shared-host recovery, multi-process contention, real provider budgets, operational/security and consumer/supply-chain criteria. Headless coordinator crash tests are not continuous-worker pod-crash qualification. First scope stays known-ID owner-to-Oracle/JPA. No broad refactor, bulk-owner/vendor/inventory feature, main change, merge, workflow bootstrap/dispatch or package publication.
