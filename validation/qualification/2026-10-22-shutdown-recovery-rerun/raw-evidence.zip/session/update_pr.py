"""Update only authorized PR #1 description; never merge, dispatch or publish."""
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
repo = 'Tobia5/model-sync-starter'
state = json.loads(subprocess.check_output(['gh', 'pr', 'view', '1', '--repo', repo,
    '--json', 'body,headRefName,headRefOid,state,mergedAt,url'], text=True))
assert state['state'] == 'OPEN' and state['mergedAt'] is None
assert state['headRefName'] == 'review/layered-refactor-qm-20261020'
before = base / 'pr-description-before-shutdown.md'
if not before.exists():
    before.write_text(state['body'], encoding='utf-8')
    (base / 'pr-description-before-shutdown.json').write_text(json.dumps({k:v for k,v in state.items() if k != 'body'}
        | {'observed_utc':datetime.now(timezone.utc).isoformat()}, indent=2) + '\n')
description = '''## Current shutdown / waits / process recovery qualification

**Default PASS · New full RUNNING · Production NO-GO**

Current code [`3564410`](https://github.com/Tobia5/model-sync-starter/commit/3564410ad8e884509cecb0e530a8e3c16473eb29), tree `d0af02e4117463eae97a25108b537eb9650fd577`.

- Failure contract committed before implementation. Worker closes new claim admission, performs bounded drain, distinguishes logical cancellation from tracked physical completion, retains physical owner capacity through late completion and refuses unsafe restart. Pacing, queue SQL and core policies were not reopened.
- Clean local default passed: run `7d71b163-e3f8-4a92-a5da-99ae126c7a96`, exit0/62.11s; 102 recorded goals with no PIT/Gatling/Failsafe. Default tests include physical/async shutdown, custom clock, actual demo-YAML precedence and evidence-admission regressions.
- Latest targeted Oracle diagnostic (`226e4eb`, run `87839e65-110e-4086-9aa4-269ed8c1146f`) is **FAILED**, not a full result: six independent-JVM crash cases and eleven of twelve I/O cases passed. JDBC locked-DML cancellation remained active after5003ms despite effective2s query timeout, in an explicit rollback-only transaction. Same2s/5s/ORA-01013 gate retained; passing socket-read timeout is not substituted for independent statement cancellation.
- Real transport acknowledgement-loss cases observed the old complete projection/evidence before COMMIT and the new complete pair after acknowledgement loss. Crash tests forcibly terminate only owned worker JVMs; fresh processes reclaim expired leases and reject obsolete tokens, with newer generations/local revisions preserved. Owner reads are recorded separately from persisted outcomes.
- Full approved local container entry point is running against this exact clean code with unchanged6GiB/4CPU caps, generated credentials/separate schemas and synthetic data. `-fae -Pfull clean verify` retains all prior gates and collects independent modules after failure; a failed Maven exit stays failed. No full result is claimed yet.

### Immutable accepted baseline

[`fad6874`](https://github.com/Tobia5/model-sync-starter/commit/fad6874c9fa0e0a16ed7d542cace11ea89a991e1), tree `a530a260738510da84ed7f68fd26a8a75b803d67`, full run `1afffb7d-52ca-4d4a-8857-23c3cefb8f4c` remains unchanged and PASS in its tested scope. [Pinned baseline QM](https://github.com/Tobia5/model-sync-starter/blob/0f04ff91b7aaa0c72c54c42bd169ca5a6f061ef9/QM.md) and [raw evidence](https://github.com/Tobia5/model-sync-starter/blob/0f04ff91b7aaa0c72c54c42bd169ca5a6f061ef9/validation/qualification/2026-10-22-worker-pacing/README.md) preserve earlier source-bound passes, failures and cursor corrections. Baseline raw ZIP SHA256 `af3434238eafdd9f3064012a5d41bf7012c19499e02146fadff7072129afe7aa` verified unchanged.

All parent release gates remain open. Known-ID owner-to-Oracle/JPA only; no broad refactor, bulk owner, vendor/inventory feature, main change, merge or package publication. Full GitHub CI remains NOT_RUN/unregistered; the approved local disposable route supplies this attempt. Exact final results, raw artifacts and cleanup will be linked after collection. The previous PR description is retained in this session's evidence.
'''
(base / 'pr-description-current.md').write_text(description, encoding='utf-8')
subprocess.run(['gh', 'pr', 'edit', '1', '--repo', repo, '--body-file', str(base / 'pr-description-current.md')], check=True)
verified = json.loads(subprocess.check_output(['gh', 'pr', 'view', '1', '--repo', repo,
    '--json', 'headRefOid,state,mergedAt,body,url'], text=True))
assert verified['body'].replace('\r','').rstrip() == description.replace('\r','').rstrip()
print(json.dumps({k:v for k,v in verified.items() if k != 'body'}))
