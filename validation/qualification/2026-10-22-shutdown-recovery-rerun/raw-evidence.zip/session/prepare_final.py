"""Keep final-source default results and unexecuted full preflight distinct."""
import hashlib
import json
from pathlib import Path
import subprocess
import uuid
from datetime import datetime, timezone

base=Path(__file__).resolve().parent
root=base.parents[1]/'model-sync-starter'
default=base/'default-895a915d-0c43-42a0-b217-b9f7c2426d2a'
report=json.loads((default/'target/qm/evidence.json').read_text())
manifest=json.loads((default/'archive-manifest.json').read_text())
assert report['evidence']['attribution']==manifest['run_id']=='47311f17-5b2c-409b-ab19-8b9340fc8af5'
assert report['source_sha']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
suites=[module['surefire'] for module in report['evidence']['modules'].values()]
summary={key:sum(suite.get(key,0) for suite in suites) for key in ('tests','files','failures','errors','skipped')}
assert summary=={'tests':117,'files':25,'failures':0,'errors':0,'skipped':0}
summary.update(source_sha=report['source_sha'],source_tree=report['source_tree'],run_id=manifest['run_id'],
    command=report['runs']['default']['command'],exit=0,
    python_guards=61,recorded_goals=102,expensive_goals=[],
    elapsed_seconds=json.loads((default/'result.json').read_text())['elapsed_seconds'])
(base/'default-8830c3f-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
capacity=json.loads((base/'capacity-before-full-8830c3f.json').read_text())
assert capacity['status']=='BLOCKED'
blocked={'source_sha':report['source_sha'],'source_tree':report['source_tree'],
    'source_change_digest':hashlib.sha256(b'').hexdigest(),
    'attempt_id':str(uuid.uuid4()),'run_id':None,'observed_utc':datetime.now(timezone.utc).isoformat(),
    'status':'BLOCKED','full_execution':'NOT_RUN','maven_exit':None,'wrapper_exit':None,
    'intended_command':'python -u scripts/full-oracle-container.py',
    'intended_environment':{'MODELSYNC_MAVEN_SETTINGS':'.mvn/qualification-central.settings.xml',
        'MODELSYNC_ORACLE_CONTAINER':'EXPLICIT_DISPOSABLE','MODELSYNC_FULL_ENV_ACK':'DISPOSABLE_NONPRODUCTION'},
    'executed_preflight_command':'python ../qualification-evidence/shutdown-recovery/capacity_gate.py',
    'observed_shell_exit':1,'native_script_exit_definition':2,
    'reason':capacity['reason'],'capacity_evidence':'capacity-before-full-8830c3f.json',
    'container_created':False,'volume_created':False,'resources':'NONE_CREATED',
    'suite_evidence':'NONE: do not attribute any earlier JUnit/PIT/Oracle/Gatling reports to this unexecuted attempt',
    'earlier_full':{'source_sha':'3564410ad8e884509cecb0e530a8e3c16473eb29',
        'run_id':'d0500d1e-030b-425e-9b49-a35e214f7598','status':'FAILED','maven_exit':1}}
(base/'final-full-blocked.json').write_text(json.dumps(blocked,indent=2)+'\n')
print(json.dumps({'default':summary,'final_full_preflight':blocked}))
