"""Summarize only the explicitly named archived full run; never aggregate attempts."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--attempt', required=True)
parser.add_argument('--run-id', required=True)
args = parser.parse_args()
base = Path(__file__).resolve().parent
attempt = Path(args.attempt).resolve()
assert attempt.is_relative_to(base.resolve())
record = json.loads((attempt / 'target/qm/evidence.json').read_text())
context = json.loads((attempt / 'archive-manifest.json').read_text())
assert context['run_id'] == record['evidence']['attribution'] == args.run_id
evidence = record['evidence']
summary = {key:context[key] for key in ('run_id','source_sha','source_tree','source_change_digest')}
summary.update(runs=record['runs'], environment=record['environment'], rejected=evidence['rejected'])
for runner in ('surefire','failsafe'):
    summary[runner] = {key:sum(module[runner].get(key,0) for module in evidence['modules'].values())
                       for key in ('tests','files','failures','errors','skipped')}
    summary[runner]['suites'] = [{'module':name, **suite} for name,module in evidence['modules'].items()
                                for suite in module[runner].get('suites',[])]
summary['mutation'] = evidence['mutation']
summary['gatling'] = evidence['gatling']
for name in ('oracle-recovery','oracle-io'):
    path = attempt / f'model-sync-sample/target/qm/{name}.json'
    if path.exists():
        value = json.loads(path.read_text())
        assert value['run_id'] == args.run_id and value['source_sha'] == context['source_sha']
        summary[name] = value
    else: summary[name] = {'status':'NOT_RUN'}
for name in ('oracle_workload','oracle_scale','oracle_worker','oracle_optimization'):
    value = evidence.get(name)
    summary[name] = {key:item for key,item in value.items() if key not in ('distributions','seed_work','cleanup_work',
        'phase_diagnostics','table_statistics','index_statistics')} if isinstance(value,dict) else None
summary['infrastructure'] = json.loads((attempt / 'target/qm/oracle-container.json').read_text())
summary['independent_cleanup'] = json.loads((attempt / 'independent-cleanup.json').read_text())
destination = base / ('reviewed-summary-' + args.run_id + '.json')
destination.write_text(json.dumps(summary,indent=2) + '\n')
print(json.dumps({'path':str(destination),'run_id':args.run_id,'status':record['runs']['full']['status'],
    'surefire':{k:v for k,v in summary['surefire'].items() if k!='suites'},
    'failsafe':{k:v for k,v in summary['failsafe'].items() if k!='suites'},
    'mutation':summary['mutation']}))
