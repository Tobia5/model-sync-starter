# Model Sync headroom resume — launch record, not a result

User: "headroom free". Existing explicit local disposable-host authorization
persists; no generic approval re-request. Only Model Sync PR1, same review branch.

- Source/head `08bd1906e54d6a182a1a7d2c9473fc255f7038fa`, tree
  `a5f5e717c9fcd3331c139558508c312aff901d60`; clean empty change digest.
- Repository/AGENTS/PR head re-read; OPEN/unmerged. No production code edits.
- Memory admission PASS21.648GiB versus unchanged6+8+4GiB budget; resource gate
  `capacity-before-full-08bd190.json`. Disk C123.364/D1070.053GiB; Docker29.8.2.
- Fresh default PASS65.559s, run `2bb7a10f-29a9-4b30-9313-48aa2d1960d9`,
  directory `default-f42cd241-725a-4499-a348-e90d25af74fd`,117 JUnit.
- Full started12:09:37.298735UTC via same `session.py full`; approved wrapper,
  public project settings and explicit nonproduction ACKs; source stays frozen
  until original exit and raw archive collection finish.
- Full run `e88fc1de-755e-470c-a7f7-15c3c7a4f13d`, attempt
  `3dabb75d-761d-427a-88f7-5126042f4b90`, directory
  `full-e7a832ce-9b6e-481d-8c94-d01aee836ffe`.
- Owned container `msq-3de5da8e40a9`, volume same name plus `-data`,
  loopback port56068, pinned image unchanged,6GiB/4CPU caps independently recorded
  in `full-container-observation-08bd190.json`. No unrelated resources changed.
- Supervisor process session87691,10800s bound. `monitor_resume.py` reads bounded
  progress. `sample_resume_resource.py` records whole-container snapshots only;
  these are not selector/session/cursor work deltas. No extra schema queries.
- PR description updated with RUNNING state and preserved older statuses; verified
  with byte-normalized CR stripping after a text-normalization assertion failed.
- Prior root QM Git blob preserved as `baseline-QM-08bd190.md`, SHA256
  `498310ada2c648c804998424673f1618d9818cdc0632e71a1342725b5cdbabff`,60187bytes;
  five earlier ZIP hashes in `preservation-before-headroom-resume.json`.

After completion: preserve original exit, independently inspect only owned
container/volume absence; run `collect_provenance.py` and `extract_results.py`
with this exact run/attempt BEFORE tracked edits. Keep source-bound partial failed
results; no gate changes. Run offline triggers after Maven. Package with
`package_evidence_v2.py` (handles generated ICO bytes narrowly), unique new run
destination. Prepend actual results to QM and retain old08bd190 report verbatim;
use a new validation/qualification subdirectory, keeping all previous ZIPs intact.
Update scoped TODO/readiness criteria, report-only commit/push to existing PR,
update PR DESCRIPTION with exact source/report links and verified outcomes.
No merge/main/package publication. Production NO-GO remains until applicable
parent gates pass. Current RUNNING note above is historical launch state only.
