"""Package completed attempts without promoting failed/blocked/old evidence to PASS."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--run-id', required=True)
parser.add_argument('--full-attempt', required=True)
args = parser.parse_args()
full = Path(args.full_attempt).resolve()
assert full.is_relative_to(base.resolve()) and full.name.startswith('full-')
context = json.loads((full / 'archive-manifest.json').read_text())
result = json.loads((full / 'result.json').read_text())
assert context['run_id'] == args.run_id and result['source_sha'] == context['source_sha']
assert result['source_change_digest'] == hashlib.sha256(b'').hexdigest()
full_report = json.loads((full / 'target/qm/evidence.json').read_text())
infrastructure = json.loads((full / 'target/qm/oracle-container.json').read_text())
assert full_report['evidence']['attribution'] == infrastructure['run_id'] == args.run_id
assert full_report['runs']['full']['exit'] == result['exit'] == infrastructure['wrapper_exit']
assert (full / 'independent-cleanup.json').is_file(), 'Retain an independent cleanup receipt even on failure'
destination = base / ('publication-' + args.run_id + '-r3')
destination.mkdir(exist_ok=False)
files = {}; components = []
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
for directory in sorted(base.iterdir()):
    manifest_file = directory / 'archive-manifest.json'
    if not manifest_file.is_file():
        continue
    manifest = json.loads(manifest_file.read_text())
    for relative, expected in manifest.get('files_sha256', {}).items():
        stored = directory / relative
        assert stored.is_file() and digest(stored) == expected, f'Archived evidence integrity changed: {stored}'
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            assert path.suffix.lower() not in {'.jar', '.class', '.pyc'}, 'No binaries in review evidence'
            files['attempts/' + directory.name + '/' + path.relative_to(directory).as_posix()] = path
    components.append({key: manifest.get(key) for key in ('source_sha', 'source_tree', 'source_change_digest',
        'run_id', 'scope', 'command_exit', 'qualification', 'status')} | {'component':directory.name})
for path in sorted(base.glob('*')):
    if path.is_file() and path.suffix in {'.py', '.json', '.md', '.log'}:
        files['session/' + path.name] = path
root_parent = base.parents[0]
for name in ('shutdown-contract-red.log', 'shutdown-focused-01.log'):
    path = root_parent / name
    if path.is_file(): files['development-unqualified/' + name] = path

# Scan only the selected reports/helpers, never host settings/environments or credentials.
patterns = [re.compile(r'(?<![0-9a-f])[0-9a-f]{48}(?![0-9a-f])', re.I),
            re.compile(r'<(?:password|passphrase)>\s*[^<\s]+\s*</', re.I)]
scanned = 0
binary_icons = 0
binary_simulation_logs = 0
for name, path in files.items():
    raw = path.read_bytes()
    if path.suffix == '.zip':
        raise AssertionError('Unexpected nested ZIP; review explicitly before publication')
    encoding = 'utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8'
    if path.suffix == '.ico':
        assert raw.startswith(b'\x00\x00\x01\x00'), 'Unexpected binary icon format'
        text = raw.decode('latin1')  # lossless bytes; run the same ASCII secret patterns
        binary_icons += 1
    elif path.name == 'simulation.log' and path.parent.parent.name == 'gatling':
        assert raw.startswith(b'\x00\x00\x00\x00\x063.13.1'), 'Unexpected pinned Gatling binary log format'
        text = raw.decode('latin1')  # preserve and scan every original byte; do not parse as text
        binary_simulation_logs += 1
    else:
        try: text = raw.decode(encoding)
        except UnicodeDecodeError: text = raw.decode('cp1252')
    for pattern in patterns:
        assert not pattern.search(text), f'Potential secret in selected evidence: {name}'
    if path.suffix == '.xml':
        document = ET.fromstring(text.lstrip('\ufeff'))
        for element in document.iter():
            key = element.get('name', element.tag.rsplit('}', 1)[-1])
            value = element.get('value', element.text or '').strip()
            if re.search(r'password|passphrase|secret|access.?token|auth.?token', key, re.I):
                assert not value or value.startswith('${'), f'Sensitive XML property requires private review: {name}: {key}'
    scanned += 1
index = {**{key:context[key] for key in ('source_sha','source_tree','source_change_digest','run_id')},
    'full_status':full_report['runs']['full']['status'], 'full_command_exit':result['exit'],
    'generated_utc':datetime.now(timezone.utc).isoformat(), 'components':components,
    'scope_note':'Each attempt retains its own identity/status; do not add historical counts to the current run.',
    'development_note':'Unqualified initial direct logs retain their original bytes; their dirty source digest was not captured.',
    'files_sha256':{name:digest(path) for name,path in sorted(files.items())}}
(destination / 'artifact-index.json').write_text(json.dumps(index, indent=2) + '\n')
zip_path = destination / 'raw-evidence.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name,path in sorted(files.items()): archive.write(path, name)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files)
receipt = {**{key:context[key] for key in ('source_sha','source_tree','source_change_digest','run_id')},
    'full_status':full_report['runs']['full']['status'], 'full_command_exit':result['exit'],
    'sha256':digest(zip_path), 'bytes':zip_path.stat().st_size, 'files':len(files), 'components':len(components),
    'bounded_secret_scan':{'inputs':scanned,'findings':0,'patterns':'48-hex generated credentials; password XML; sensitive XML property names/values'},
    'binary_icons_ascii_scanned':binary_icons, 'binary_simulation_logs_ascii_scanned':binary_simulation_logs, 'zip_crc':'PASS', 'binary_policy':'No JAR/class outputs; library artifacts hashed only'}
(destination / 'artifact.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'destination':str(destination), **receipt}))
