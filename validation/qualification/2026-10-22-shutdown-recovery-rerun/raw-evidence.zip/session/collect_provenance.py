"""Metadata for an exact completed full attempt, preserving its PASS or FAILED status."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
root = base.parents[1] / 'model-sync-starter'
sys.path.insert(0, str(root / 'scripts'))
from run_evidence import current, fresh, reactor_modules

parser = argparse.ArgumentParser()
parser.add_argument('--run-id', required=True)
parser.add_argument('--attempt', required=True)
args = parser.parse_args()
attempt = Path(args.attempt).resolve()
assert attempt.is_relative_to(base.resolve()) and attempt.name.startswith('full-')
context = current(root)
assert context['run_id'] == args.run_id
report = json.loads((root / 'target/qm/evidence.json').read_text(encoding='utf-8'))
infrastructure = json.loads((root / 'target/qm/oracle-container.json').read_text())
launch = json.loads((attempt / 'result.json').read_text())
archive = json.loads((attempt / 'archive-manifest.json').read_text())
assert report['evidence']['attribution'] == infrastructure['run_id'] == archive['run_id'] == args.run_id
assert launch['source_sha'] == context['source_sha'] and launch['source_tree'] == context['source_tree']
assert report['runs']['full']['exit'] == launch['exit'] == infrastructure['wrapper_exit']
destination = base / ('build-provenance-' + args.run_id)
destination.mkdir(exist_ok=False)
files, sources = {}, {}
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(path, relative):
    assert path.resolve().is_relative_to(root.resolve())
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    files[relative] = digest(target)

for path in [root / name for name in ('pom.xml', 'mvnw', 'mvnw.cmd', '.mvn/wrapper/maven-wrapper.properties',
    '.mvn/qualification-central.settings.xml', '.github/workflows/model-sync-verify.yml', '.github/workflows/model-sync-full-verify.yml')]:
    relative = path.relative_to(root).as_posix(); copy(path, 'source/' + relative); sources[relative] = digest(path)
for module in reactor_modules(root, True):
    relative = (module / 'pom.xml').relative_to(root).as_posix()
    copy(module / 'pom.xml', 'source/' + relative); sources[relative] = digest(module / 'pom.xml')
for folder in (root / 'scripts', root / 'model-sync-persistence-jdbc/src/main/resources/model-sync/schema',
               root / 'model-sync-persistence-jdbc/src/main/resources/model-sync/migration'):
    for path in sorted(folder.glob('*')):
        if path.suffix in ('.py', '.sql'):
            relative = path.relative_to(root).as_posix(); copy(path, 'source/' + relative); sources[relative] = digest(path)
assert digest(root / '.mvn/qualification-central.settings.xml') == infrastructure['maven_settings_sha256']
for name in ('effective-default.xml', 'effective-full.xml', 'effective-full-sample.xml'):
    path = root / 'target/qm' / name
    assert path.stat().st_mtime_ns >= launch['supervisor_launch_ns']
    copy(path, 'effective/' + name)
ns = {'m': 'http://maven.apache.org/POM/4.0.0'}
version = ET.parse(root / 'pom.xml').find('m:version', ns).text
excluded = {'model-sync-testkit', 'model-sync-sample', 'model-sync-architecture-tests', 'model-sync-performance'}
outputs = {}; versions = set(); runtime = {}
for module in reactor_modules(root, True):
    if module.name not in excluded:
        artifact = ET.parse(module / 'pom.xml').find('m:artifactId', ns).text
        jar = module / 'target' / (artifact + '-' + version + '.jar')
        key = jar.relative_to(root).as_posix()
        try:
            fresh(jar, root); outputs[key] = {'status': 'BUILT', 'sha256': digest(jar), 'bytes': jar.stat().st_size}
        except ValueError as error:
            outputs[key] = {'status': 'NOT_BUILT_THIS_RUN', 'reason': str(error)}
    for runner in ('surefire-reports', 'failsafe-reports'):
        for xml in (module / 'target' / runner).glob('TEST-*.xml'):
            try: fresh(xml, root)
            except ValueError: continue
            props = {p.get('name'):p.get('value') for p in ET.parse(xml).getroot().findall('properties/property')}
            for name in ('java.runtime.version', 'java.vendor', 'os.name', 'os.arch'):
                if name in props: runtime.setdefault(name, set()).add(props[name])
            for entry in props.get('java.class.path', '').split(';'):
                name = Path(entry).name
                if name.endswith('.jar') and name.startswith(('spring-boot-', 'spring-core-', 'hibernate-core-', 'junit-', 'archunit-', 'ojdbc11-', 'h2-', 'reactor-core-')):
                    versions.add(name)
metadata = {**context, 'scope':'BUILD_CONFIGURATION_AND_HASHES_NOT_NEW_TEST_EXECUTION',
    'full_status':report['runs']['full']['status'], 'maven_exit':infrastructure['maven_exit'],
    'wrapper_exit':infrastructure['wrapper_exit'], 'environment':report['environment'],
    'runtime_properties':{key:sorted(values) for key,values in runtime.items()},
    'resolved_test_classpath_artifacts':sorted(versions), 'source_configuration_sha256':sources,
    'library_build_outputs':outputs, 'binary_policy':'Hashes only; no JARs published or copied'}
(destination / 'provenance.json').write_text(json.dumps(metadata, indent=2) + '\n')
files['provenance.json'] = digest(destination / 'provenance.json')
(destination / 'archive-manifest.json').write_text(json.dumps({**context, 'scope':'build-provenance',
    'qualification':'METADATA_NOT_NEW_TEST_EXECUTION', 'status':'OBSERVED', 'files_sha256':files}, indent=2) + '\n')
print(json.dumps({'path':str(destination), 'run_id':args.run_id, 'full_status':metadata['full_status'],
    'configuration_files':len(files), 'built_libraries':sum(item['status']=='BUILT' for item in outputs.values())}))
