import json
from pathlib import Path
import subprocess
base=Path(__file__).resolve().parent
repo='Tobia5/model-sync-starter'
state=json.loads(subprocess.check_output(['gh','pr','view','1','--repo',repo,
    '--json','body,headRefOid,headRefName,state,mergedAt']))
assert state['state']=='OPEN' and state['mergedAt'] is None
assert state['headRefOid']=='08bd1906e54d6a182a1a7d2c9473fc255f7038fa'
assert state['headRefName']=='review/layered-refactor-qm-20261020'
prior=base/'pr-before-headroom-resume.md'
with prior.open('x',encoding='utf-8') as output: output.write(state['body'])
report=json.loads((base/'default-f42cd241-725a-4499-a348-e90d25af74fd/target/qm/evidence.json').read_text())
assert report['evidence']['attribution']=='2bb7a10f-29a9-4b30-9313-48aa2d1960d9'
assert sum(m['surefire'].get('tests',0) for m in report['evidence']['modules'].values())==117
prefix='''## Headroom restored: new full verification RUNNING

Current exact tested source `08bd1906e54d6a182a1a7d2c9473fc255f7038fa`, tree `a5f5e717c9fcd3331c139558508c312aff901d60`, clean change digest. Fresh local default PASS: run `2bb7a10f-29a9-4b30-9313-48aa2d1960d9`, exit0/65.559s,117 JUnit tests; required guards/lifecycle checks retained.

User reported restored headroom; read-only admission found21.648GiB versus the unchanged18GiB planning budget. The approved `scripts/full-oracle-container.py` full route is running from12:09:37UTC with the same pinned image,6GiB/4CPU caps,loopback port,generated credentials,separate schemas and explicit project Central settings. Attempt `3dabb75d-761d-427a-88f7-5126042f4b90`. No gates/workloads/production code were changed. No new full outcome or production readiness is claimed. Original failure and resource-blocked attempts below remain historical and unchanged; final fresh reports/cleanup will be linked when collected.

---

## Preserved previous qualification status

'''
body=base/'pr-headroom-resume-running.md';body.write_text(prefix+state['body'],encoding='utf-8')
subprocess.run(['gh','pr','edit','1','--repo',repo,'--body-file',str(body)],check=True)
check=json.loads(subprocess.check_output(['gh','pr','view','1','--repo',repo,'--json','body']))
assert check['body'].replace('\r','').rstrip()==body.read_text().replace('\r','').rstrip()
print('PR #1 description reports resumed full RUNNING, preserving prior outcomes')
