from pathlib import Path
base=Path(__file__).resolve().parent
files=[p for d in base.iterdir() if (d/'archive-manifest.json').is_file() for p in d.rglob('*') if p.is_file()]
files += [p for p in base.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md','.log')]
files += [base.parent/n for n in ('shutdown-contract-red.log','shutdown-focused-01.log') if (base.parent/n).is_file()]
for path in files:
    raw=path.read_bytes()
    try: raw.decode('utf-16' if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else 'utf-8')
    except UnicodeDecodeError:
        try: raw.decode('cp1252')
        except UnicodeDecodeError:
            print(path.relative_to(base.parent),len(raw),raw[:8].hex())
