"""Inspect only nonsecret configuration of the new session-owned container."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess

base=Path(__file__).resolve().parent
name='msq-3de5da8e40a9'
template='{"name":{{json .Name}},"id":{{json .Id}},"image":{{json .Config.Image}},"memory":{{.HostConfig.Memory}},"nano_cpus":{{.HostConfig.NanoCpus}},"ports":{{json .NetworkSettings.Ports}},"labels":{{json .Config.Labels}}}'
record=json.loads(subprocess.check_output(['docker','inspect','--format',template,name]))
assert record['memory']==6*1024**3 and record['nano_cpus']==4*10**9
assert record['image'].endswith('@sha256:6d61d267a3b978c24c5ac1790e62e927416a0aec446bd86e4b3a1527562757bd')
assert record['labels']['io.modelsync.qualification.attempt']
assert record['ports']['1521/tcp'] and all(p['HostIp']=='127.0.0.1' for p in record['ports']['1521/tcp'])
record.update(observed_utc=datetime.now(timezone.utc).isoformat(),source_sha='08bd1906e54d6a182a1a7d2c9473fc255f7038fa')
target=base/'full-container-observation-08bd190.json'
with target.open('x',encoding='utf-8') as output: output.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
