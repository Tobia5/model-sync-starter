import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1] / 'model-sync-starter'
SOURCE = '4057535359400242c3a20d69f7ad06197caee5e6'
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT)
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain').strip()
sys.path.insert(0, str(ROOT/'scripts'))
from quota_evidence import qualify
data = qualify(ROOT)
default = next(BASE.glob('default-*/archive-manifest.json')).parent
diagnostic = next(BASE.glob('diagnostic-*/archive-manifest.json')).parent
infra = json.loads((diagnostic/'target/qm/oracle-container.json').read_text())
cleanup = {k: infra[k] for k in ('run_id','attempt_id','source_sha','source_tree','container_name','volume_name')}
for kind, name in (('container', infra['container_name']), ('volume', infra['volume_name'])):
    command = ['docker', 'inspect', '--format', '{{.Id}}', name] if kind == 'container' else ['docker','volume','inspect','--format','{{.Name}}',name]
    checked = subprocess.run(command, capture_output=True, text=True)
    # Format only the owned identifier; never dump a container environment on an unexpected survivor.
    absent = checked.returncode != 0 and ('no such object' in checked.stderr.lower() or 'no such volume' in checked.stderr.lower())
    cleanup[kind] = {'command': command, 'exit': checked.returncode, 'absent': absent,
                     'stdout': checked.stdout.strip(), 'stderr': checked.stderr.strip()}
    assert absent, 'Owned resource still present or absence unverified'
cleanup['status'] = 'PASS'
(BASE/'independent-cleanup.json').write_text(json.dumps(cleanup, indent=2)+'\n')
preserved = {}
for name in git('ls-tree','-r','--name-only','74916ce','validation/qualification').decode().splitlines():
    if name.endswith('.zip'):
        before = hashlib.sha256(git('show','74916ce:'+name)).hexdigest()
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == before
        preserved[name] = before
for name in ('OracleIoIT.java','OracleCancellationDiagnostic.java','OracleNowaitDiagnostic.java','OracleLockPolicyIT.java','OracleAtomicityIT.java'):
    path = 'model-sync-sample/src/test/java/io/modelsync/sample/'+name
    assert not git('diff','74916ce','--',path).strip()
    preserved[path] = hashlib.sha256(git('show','74916ce:'+path)).hexdigest()
(BASE/'baseline-preservation.json').write_text(json.dumps(preserved, indent=2)+'\n')
strict = {'status':'PASS','scope':'DIAGNOSTIC_ONLY','full':'NOT_RUN', **{k:data[k] for k in ('source_sha','source_tree','run_id','started_ns','source_change_digest')},'cases':len(data['cases'])}
(BASE/'strict-quota-validation.json').write_text(json.dumps(strict, indent=2)+'\n')
suites = [ET.parse(p).getroot() for p in default.rglob('surefire-reports/TEST-*.xml')]
analysis = {'scope':'shared-quota-contention','source_sha':SOURCE,'source_tree':data['source_tree'],
            'default':{'run_id':json.loads((default/'archive-manifest.json').read_text())['run_id'],
                       **json.loads((default/'result.json').read_text()),'xml_suites':len(suites),
                       'junit':{k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')},'python_guards':76},
            'diagnostic':{'run_id':data['run_id'],**json.loads((diagnostic/'result.json').read_text()),
                          'launcher':json.loads((diagnostic/'target/qm/oracle-diagnostic.json').read_text()),
                          'infrastructure':infra},'measurement':data,'cleanup':cleanup,
            'acceptance':'prior existing-work/JPA criterion accepted; quota evidence is scoped regression, not complete release acceptance',
            'full':'NOT_RUN: legitimate first-insert and other applicable failure gates remain unresolved; original UPDATE gate retained',
            'production':'NO-GO'}
destination=ROOT/'validation/qualification/2026-10-24-quota-contention'
destination.mkdir(exist_ok=False)
(destination/'execution-analysis.json').write_text(json.dumps(analysis, indent=2)+'\n',encoding='utf-8')
files = [p for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name != 'packaging-receipt.json']
archive=destination/'raw-evidence.zip'
manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as out:
    for path in sorted(files):
        name=path.relative_to(BASE).as_posix(); content=path.read_bytes()
        # Bounded disclosure checks supplement, not replace, source review.
        if path.suffix in {'.log','.json','.xml'}:
            assert not re.search(rb'(?<![0-9a-f])[0-9a-f]{48}(?![0-9a-f])',content), 'Possible generated credential: '+name
        if path.suffix == '.xml':
            for prop in ET.fromstring(content).findall('properties/property'):
                if 'password' in prop.get('name','').lower(): assert not prop.get('value','')
        manifest[name]=hashlib.sha256(content).hexdigest(); out.writestr(name,content)
    out.writestr('packaged-files-sha256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as opened:
    assert opened.testzip() is None
    for name,digest in manifest.items(): assert hashlib.sha256(opened.read(name)).hexdigest()==digest
receipt={'source_sha':SOURCE,'source_tree':data['source_tree'],'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
         'bytes':archive.stat().st_size,'files':len(manifest)+1,'crc_and_input_bytes_verified':True,
         'bounded_nonsecret_scans':'48-hex token / nonempty XML password property: zero findings; not a universal secret audit'}
(BASE/'packaging-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
