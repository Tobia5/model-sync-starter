# Qualification raw evidence

Each run directory retains its own source/run identity. The configured full PASS is source 4f440807f20c568a2240ed5ce32f1aab8e9558b0, run 3177a6c3-3b64-4e5b-b40b-dc18bf1c7884. Prior failed, interrupted and blocked attempts remain distinct. No JAR packages, database files, credentials, or Git metadata are included.

The a8ca interrupted run uses its explicitly recorded collector correction for failure classification; its abort event and collector identity are retained. The 2c191 failed Gatling run retains raw HTTP counts and its mislocated harness JSON as diagnostics. Neither is promoted to current-run success. Standalone host-burst diagnostics are pre-qualification regression evidence, not JUnit/Gatling qualification counts.

The INDEX binds every packaged file to its SHA-256. Canonical per-run raw manifests are retained. Synthetic ledger size is distinct from completed reconciliations. A configured full PASS is not production approval.
